#!/bin/bash
#systemctl: 2345 96 14
#########################################################################
# File Name: connect_loop.sh
# Author: Dong
# mail: wangyudong@buaa.edu.cn
# Created Time: 2022年01月17日 星期一 11时48分42秒
#########################################################################

while true
do
		/etc/buaa_connect/try-connect-v2.sh
		sleep 10
done

