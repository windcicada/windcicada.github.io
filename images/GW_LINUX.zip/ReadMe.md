# 北航自动网络认证（LINUX）

## 1. 新建system service

建立文件`/usr/lib/systemd/system/buaaConnect.service`

```service
[Unit]
Description=BUAA Connect Service
After=network.target syslog.target

[Service]
Type=idle
Restart=on-failure
RestartSec=5s
ExecStart=/etc/connect_loop.sh

[Install]
WantedBy=multi-user.target
```

## 2. 建立buaaConnect.service的执行目标

建立文件`/etc/connect_loop.sh`

```sh
#!/bin/bash
#systemctl: 2345 96 14
#########################################################################
# File Name: connect_loop.sh
# Author: Dong
# mail: wangyudong@buaa.edu.cn
# Created Time: 2022年01月17日 星期一 11时48分42秒
#########################################################################

while true
do
		/etc/buaa_connect/try-connect-v2.sh
		sleep 10
done
```

## 3. 建立单次执行目标

建立文件`/etc/buaa_connect/try-connect-v2.sh`

```sh
#!/bin/bash

online=$(curl -sS "https://gw.buaa.edu.cn/cgi-bin/rad_user_info")
grep "not_online_error" <<< $online > /dev/null
if [[ "$?" != "0" ]]; then
        echo online: $(cut -d, -f1 <<< $online)
        exit 1
fi

/etc/buaa_connect/login-v2.sh login

```

## 4. 修改/etc/buaa_connect/account为自己的账户

```account
USERNAME="sy2004511"
PASSWORD="PASSWORD"
```

## 5. 启动服务

```shell
$ sudo systemctl enable buaaConnect.service
$ sudo systemctl start buaaConnect.service
```

