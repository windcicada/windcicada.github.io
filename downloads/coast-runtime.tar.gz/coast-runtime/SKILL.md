---
name: coast-portable-runtime
description: Use when a RangeAI agent operates the packaged 本软件 portable runtime, installs it on a Linux server, starts the 图形辅助界面, edits case *.d files, launches bounded runs, or collects Visit outputs.
---

# 本软件 Portable Runtime Skill

This is the entry skill for the packaged 本软件 runtime. It is written for a
RangeAI-style agent that receives a portable directory rather than the full
development source tree.

## First Steps

1. Work inside the package root or the installed prefix. Do not search sibling
   development directories unless the user explicitly provides them.
2. Read `docs/USER_MANUAL.md`.
3. For install and run work, read
   `agent_skills/rangeai-coast-portable/SKILL.md`.
4. For case settings or boundary changes, read
   `agent_skills/rangeai-coast-case-boundary/SKILL.md`.
5. Report the detected package root, case directory, rank count, and whether
   this is `EXEC_TEMPLATE` or a copied working case.

## Package Layout

Expected portable layout:

```text
coast-runtime-<version>-linux-x86_64/
  SKILL.md
  bin/coast
  bin/coast_remap
  bin/coastctl
  bin/coast-ui
  env/coast-env.sh
  EXEC_TEMPLATE/
  ui/static/
  docs/USER_MANUAL.md
  agent_skills/
  manifest.json
  PACKAGE_AUDIT.json
  install.sh
```

## Safety Rules

- Do not edit `EXEC_TEMPLATE` for a production run. Copy it to a working case
  directory first.
- Do not delete `Restart`, `runtime_mesh`, `Decomp`, `Geometry`, or Visit
  output from a user case unless the user explicitly asks.
- Do not start an unbounded solver run. Set a step limit in `input.d` and use
  `coastctl run --preflight` before `--execute`.
- `coastctl run --preflight/--execute` defaults to C++ `coast_remap` for
  Restart remap. Python reference is explicit only with
  `--remap-backend python-reference`; if `coast_remap` is missing, treat the
  package as incomplete.
- Direct `mpirun` only consumes prepared `Restart`/`runtime_mesh` data and does
  not auto-remap rank mismatches.
- `boundary_conditions.d` is the supported user-facing boundary interface.
  Coordinate selectors are valid and must remain compatible with STL-only
  cases.
