const $ = (id) => document.getElementById(id);

let files = [];
let lastStatus = null;
let meshViz = null;
let settingsState = { files: {}, currentPath: "" };
let postState = { datasets: [] };

function log(message, payload) {
  const target = $("messages");
  if (!target) return;
  const stamp = new Date().toISOString().replace("T", " ").replace("Z", "");
  const detail = payload ? "\n" + JSON.stringify(payload, null, 2) : "";
  target.textContent = `[${stamp}] ${message}${detail}\n\n` + target.textContent;
}

function isDFile(path) {
  return /^[^/]+\.d$/.test(path);
}

function cleanCommentTitle(line) {
  const cleaned = line
    .replace(/^\s*[C!#]+\s?/i, "")
    .replace(/[-=]{3,}/g, " ")
    .trim();
  return /[A-Za-z\u4e00-\u9fa5]/.test(cleaned) ? cleaned : "";
}

function labelForFile(path) {
  const labels = {
    "input.d": "主控制 input.d",
    "ibm_mesh.d": "IBM/网格 ibm_mesh.d",
    "boundary_conditions.d": "边界 boundary_conditions.d",
    "vtk_output.d": "输出 vtk_output.d",
    "spray.d": "喷雾 spray.d",
    "spark.d": "点火 spark.d",
    "probe.d": "探针 probe.d",
    "heat_release.d": "热释放 heat_release.d",
  };
  return labels[path] || path;
}

function splitKeys(comment, count) {
  const clean = (comment || "")
    .replace(/true\/false/gi, "true false")
    .replace(/\([^)]*\)/g, "")
    .trim();
  let parts = clean
    .split(/[,;:，；]+/)
    .map((item) => item.trim())
    .filter(Boolean);
  if (parts.length < count) {
    parts = clean.split(/\s{2,}|\s+-\s+/).map((item) => item.trim()).filter(Boolean);
  }
  while (parts.length < count) parts.push(`${parts[0] || "参数"} ${parts.length + 1}`);
  return parts.slice(0, count);
}

function valueKind(value) {
  const lower = String(value).trim().toLowerCase();
  if (["true", "false", ".true.", ".false."].includes(lower)) return "boolean";
  if (/^[-+]?\d*\.?\d+(?:[Ee][-+]?\d+)?$/.test(String(value).trim())) return "number";
  return "text";
}

function boolValue(value) {
  return ["true", ".true.", "1", "yes"].includes(String(value).trim().toLowerCase());
}

function parseSettingLine(raw, lineIndex, category, patchName) {
  const trimmed = raw.trim();
  if (!trimmed || /^[C!#]/i.test(trimmed) || trimmed === "/" || trimmed === "{") return [];
  const indent = raw.match(/^\s*/)[0] || "";
  const categoryLabel = patchName ? `边界 patch：${patchName}` : category;

  const slashIndex = raw.indexOf("/");
  if (slashIndex > 0 && raw.slice(slashIndex + 1).trim()) {
    const before = raw.slice(0, slashIndex).trim();
    const comment = raw.slice(slashIndex + 1).trim();
    if (before && !before.startsWith("/") && /\S/.test(comment)) {
      const tokens = before.split(/\s+/).filter(Boolean);
      const keys = splitKeys(comment, tokens.length);
      return tokens.map((token, tokenIndex) => ({
        id: `${lineIndex}:${tokenIndex}`,
        lineIndex,
        tokenIndex,
        mode: "tokens",
        separator: "/",
        indent,
        comment,
        category: categoryLabel,
        key: keys[tokenIndex],
        original: token,
        current: token,
        kind: valueKind(token),
        lineText: trimmed,
      }));
    }
  }

  const bangIndex = raw.indexOf("!");
  if (bangIndex > 0 && raw.slice(bangIndex + 1).trim()) {
    const before = raw.slice(0, bangIndex).trim();
    const comment = raw.slice(bangIndex + 1).trim();
    const tokens = before.split(/\s+/).filter(Boolean);
    if (tokens.length) {
      const keys = splitKeys(comment, tokens.length);
      return tokens.map((token, tokenIndex) => ({
        id: `${lineIndex}:${tokenIndex}`,
        lineIndex,
        tokenIndex,
        mode: "tokens",
        separator: "!",
        indent,
        comment,
        category: categoryLabel,
        key: keys[tokenIndex],
        original: token,
        current: token,
        kind: valueKind(token),
        lineText: trimmed,
      }));
    }
  }

  const equals = raw.match(/^(\s*)([A-Za-z_][\w-]*)\s*=\s*([^!#,\n]+?)(\s*[!#].*)?$/);
  if (equals) {
    const value = equals[3].trim();
    return [{
      id: `${lineIndex}:0`,
      lineIndex,
      tokenIndex: 0,
      mode: "equals",
      indent: equals[1],
      key: equals[2],
      comment: (equals[4] || "").trim(),
      category: categoryLabel,
      original: value,
      current: value,
      kind: valueKind(value),
      lineText: trimmed,
    }];
  }

  const semicolon = raw.match(/^(\s*)([A-Za-z_][\w-]*)\s+([^;{}]+?)\s*;(\s*[!#].*)?$/);
  if (semicolon) {
    const value = semicolon[3].trim();
    return [{
      id: `${lineIndex}:0`,
      lineIndex,
      tokenIndex: 0,
      mode: "semicolon",
      indent: semicolon[1],
      key: semicolon[2],
      comment: (semicolon[4] || "").trim(),
      category: categoryLabel,
      original: value,
      current: value,
      kind: valueKind(value),
      lineText: trimmed,
    }];
  }

  return [];
}

function parseSettingsFile(path, text) {
  const lines = text.split(/\r?\n/);
  let category = labelForFile(path);
  let patchName = "";
  const settings = [];
  lines.forEach((line, index) => {
    const title = cleanCommentTitle(line);
    if (title) category = title;
    const patch = line.match(/^\s*patch\s+([A-Za-z0-9_./+-]+)/);
    if (patch) patchName = patch[1];
    if (/^\s*}\s*$/.test(line) && patchName && path === "boundary_conditions.d") patchName = "";
    const namelist = line.match(/^\s*&([A-Za-z_][\w-]*)/);
    if (namelist) category = `配置段 &${namelist[1]}`;
    settings.push(...parseSettingLine(line, index, category, patchName));
  });
  return { path, text, lines, settings };
}

function renderSettingsFileTabs() {
  const tabs = $("settingsFileTabs");
  if (!tabs) return;
  const previous = settingsState.currentPath;
  const paths = Object.keys(settingsState.files).sort();
  settingsState.currentPath = settingsState.files[previous] ? previous : paths[0] || "";
  tabs.innerHTML = "";
  paths.forEach((path) => {
    const file = settingsState.files[path];
    const button = document.createElement("button");
    button.type = "button";
    button.className = "file-tab" + (path === settingsState.currentPath ? " active" : "");
    button.textContent = `${labelForFile(path)} (${file.settings.length})`;
    button.addEventListener("click", () => {
      settingsState.currentPath = path;
      renderSettingsFileTabs();
      renderSettingsForm();
    });
    tabs.appendChild(button);
  });
}

async function loadSettings() {
  if (!files.length) await listFiles();
  const dFiles = files.filter((file) => isDFile(file.path)).map((file) => file.path).sort();
  settingsState = { files: {}, currentPath: settingsState.currentPath || dFiles[0] || "" };
  for (const path of dFiles) {
    const text = await textApi(`/api/file?path=${encodeURIComponent(path)}`);
    settingsState.files[path] = parseSettingsFile(path, text);
  }
  renderSettingsFileTabs();
  renderSettingsForm();
  $("settingsSummary").textContent = `已读取 ${dFiles.length} 个 .d 设置文件，共 ${Object.values(settingsState.files).reduce((sum, file) => sum + file.settings.length, 0)} 个可编辑设置。`;
  log("已读取全部设置文件");
}

function settingChanged(setting) {
  return String(setting.current) !== String(setting.original);
}

function shortComment(setting) {
  const comment = (setting.comment || "").replace(/^[!#]+\s*/, "").trim();
  if (!comment || comment === setting.key) return "";
  return comment;
}

function renderSettingsForm() {
  const path = settingsState.currentPath;
  settingsState.currentPath = path;
  const file = settingsState.files[path];
  const root = $("settingsForm");
  root.innerHTML = "";
  if (!file) {
    root.textContent = "尚未读取设置。";
    return;
  }
  const query = ($("settingsFilter").value || "").trim().toLowerCase();
  const groups = new Map();
  file.settings
    .filter((setting) => {
      if (!query) return true;
      return `${setting.key} ${setting.comment} ${setting.category}`.toLowerCase().includes(query);
    })
    .forEach((setting) => {
      if (!groups.has(setting.category)) groups.set(setting.category, []);
      groups.get(setting.category).push(setting);
    });
  if (!groups.size) {
    root.textContent = "没有匹配的设置。";
    return;
  }
  groups.forEach((settings, category) => {
    const group = document.createElement("section");
    group.className = "settings-group";
    const title = document.createElement("h3");
    title.textContent = category;
    group.appendChild(title);
    settings.forEach((setting) => {
      const row = document.createElement("div");
      row.className = "setting-row" + (settingChanged(setting) ? " changed" : "");
      const label = document.createElement("div");
      label.className = "setting-label";
      label.textContent = setting.key;
      const meta = document.createElement("div");
      meta.className = "setting-meta";
      meta.textContent = shortComment(setting);
      const controlWrap = document.createElement("div");
      controlWrap.className = "setting-control";
      let control;
      if (setting.kind === "boolean") {
        control = document.createElement("input");
        control.type = "checkbox";
        control.checked = boolValue(setting.current);
        control.addEventListener("change", () => {
          setting.current = control.checked ? (String(setting.original).startsWith(".") ? ".true." : "true") : (String(setting.original).startsWith(".") ? ".false." : "false");
          renderSettingsForm();
        });
        const switchLabel = document.createElement("label");
        switchLabel.className = "switch";
        switchLabel.appendChild(control);
        const slider = document.createElement("span");
        slider.className = "switch-slider";
        switchLabel.appendChild(slider);
        controlWrap.appendChild(switchLabel);
      } else {
        control = document.createElement("input");
        control.type = setting.kind === "number" ? "number" : "text";
        if (setting.kind === "number") control.step = "any";
        control.value = setting.current;
        control.addEventListener("input", () => {
          setting.current = control.value;
          row.classList.toggle("changed", settingChanged(setting));
        });
        controlWrap.appendChild(control);
      }
      row.appendChild(label);
      row.appendChild(controlWrap);
      row.appendChild(meta);
      group.appendChild(row);
    });
    root.appendChild(group);
  });
}

function rebuildSettingsText(file) {
  const lines = [...file.lines];
  const byLine = new Map();
  file.settings.forEach((setting) => {
    if (!byLine.has(setting.lineIndex)) byLine.set(setting.lineIndex, []);
    byLine.get(setting.lineIndex).push(setting);
  });
  byLine.forEach((settings, lineIndex) => {
    settings.sort((a, b) => a.tokenIndex - b.tokenIndex);
    const first = settings[0];
    if (first.mode === "tokens") {
      const values = settings.map((setting) => String(setting.current).trim() || setting.original);
      lines[lineIndex] = `${first.indent}${values.join(" ")} ${first.separator} ${first.comment}`;
    } else if (first.mode === "equals") {
      lines[lineIndex] = `${first.indent}${first.key} = ${String(first.current).trim()}${first.comment ? " " + first.comment : ""}`;
    } else if (first.mode === "semicolon") {
      lines[lineIndex] = `${first.indent}${first.key} ${String(first.current).trim()};${first.comment ? " " + first.comment : ""}`;
    }
  });
  return lines.join("\n");
}

async function saveCurrentSettings() {
  const path = settingsState.currentPath;
  const file = settingsState.files[path];
  if (!file) return;
  const text = rebuildSettingsText(file);
  const payload = await api("/api/file", {
    method: "POST",
    body: JSON.stringify({ path, content: text }),
  });
  settingsState.files[path] = parseSettingsFile(path, text);
  renderSettingsForm();
  await refreshStatus();
  log(`已保存 ${path}`, payload);
}

async function api(path, options = {}) {
  const response = await fetch(path, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...(options.headers || {}),
    },
  });
  const text = await response.text();
  let payload;
  try {
    payload = text ? JSON.parse(text) : {};
  } catch {
    payload = { text };
  }
  if (!response.ok) {
    throw new Error(payload.error || payload.text || response.statusText);
  }
  return payload;
}

async function textApi(path) {
  const response = await fetch(path);
  if (!response.ok) throw new Error(await response.text());
  return await response.text();
}

function setKv(container, items) {
  container.innerHTML = "";
  Object.entries(items).forEach(([key, value]) => {
    const dt = document.createElement("dt");
    const dd = document.createElement("dd");
    dt.textContent = key;
    dd.textContent = value == null ? "" : String(value);
    container.appendChild(dt);
    container.appendChild(dd);
  });
}

function setPill(ok, text) {
  const pill = $("caseState");
  pill.textContent = text;
  pill.className = "pill " + (ok ? "ok" : "bad");
}

async function refreshStatus() {
  const status = await api("/api/status");
  lastStatus = status;
  $("casePath").textContent = status.caseDir;
  const validate = status.caseValidate || {};
  const monitor = status.monitor || {};
  const mesh = (status.meshStatus || {}).activeRuntimeMesh || {};
  const errors = validate.errors || [];
  setPill(errors.length === 0, errors.length === 0 ? "通过" : `${errors.length} 个错误`);
  setKv($("statusList"), {
    工作目录: status.workspace,
    算例目录: status.caseDir,
    网格来源: mesh.meshSource,
    网格尺寸: mesh.grid,
    MPI进程数: mesh.ranks,
    边界数量: validate.patchCount,
    最新步数: monitor.lastStep,
    错误数量: (monitor.errorSummary || []).length,
  });
  setKv($("monitorList"), {
    最新步数: monitor.lastStep,
    stdout字节: monitor.stdoutBytes,
    stderr字节: monitor.stderrBytes,
    screen存在: monitor.screenExists,
    错误数量: (monitor.errorSummary || []).length,
  });
  log("状态已刷新");
}

async function listFiles() {
  const payload = await api("/api/files");
  files = payload.files || [];
  const select = $("fileSelect");
  if (select) {
    select.innerHTML = "";
    files.forEach((file) => {
      const option = document.createElement("option");
      option.value = file.path;
      option.textContent = `${file.path} (${file.sizeBytes} B)`;
      select.appendChild(option);
    });
  }
  renderDownloads();
  await renderVisitCollections();
  if (!settingsState.currentPath) {
    const firstD = files.find((file) => isDFile(file.path));
    if (firstD) settingsState.currentPath = firstD.path;
  }
}

function selectedFile() {
  const select = $("fileSelect");
  return (select && select.value) || (files[0] && files[0].path) || "";
}

async function loadSelectedFile() {
  const rel = selectedFile();
  if (!rel) return;
  const text = await textApi(`/api/file?path=${encodeURIComponent(rel)}`);
  if ($("editorTitle")) $("editorTitle").textContent = rel;
  if ($("fileEditor")) $("fileEditor").value = text;
  log(`已打开 ${rel}`);
}

async function saveSelectedFile() {
  const rel = selectedFile();
  if (!rel) return;
  const editor = $("fileEditor");
  if (!editor) return;
  const payload = await api("/api/file", {
    method: "POST",
    body: JSON.stringify({ path: rel, content: editor.value }),
  });
  log(`已保存 ${rel}`, payload);
  await refreshStatus();
}

async function meshPreview() {
  const payload = await api("/api/mesh/preview");
  setKv($("meshList"), {
    网格预览存在: payload.meshPreviewExists,
    网格VTK数量: payload.meshPreviewVtkCount,
    网格字段: (payload.meshPreviewFields || []).join(", "),
    候选预览存在: payload.candidatePreviewExists,
    候选VTK数量: payload.candidatePreviewVtkCount,
    候选字段: (payload.candidatePreviewFields || []).join(", "),
    写入文件: payload.written,
  });
  log("网格预览清单已生成", payload);
  return payload;
}

function numericTokens(text) {
  return (text.match(/[-+]?\d*\.?\d+(?:[Ee][-+]?\d+)?/g) || []).map(Number);
}

function parseVtkArray(lines, startIndex, count) {
  const values = [];
  let index = startIndex;
  while (index < lines.length && values.length < count) {
    const line = lines[index].trim();
    if (line && !/^(LOOKUP_TABLE|SCALARS|VECTORS|CELL_DATA|POINT_DATA)\b/i.test(line)) {
      values.push(...numericTokens(line));
    }
    index += 1;
  }
  return { values: values.slice(0, count), next: index };
}

function parseRectilinearVtk(text, relPath) {
  const lines = text.split(/\r?\n/);
  let dims = [0, 0, 0];
  let x = [];
  let y = [];
  let z = [];
  let cellCount = 0;
  const fields = {};
  for (let i = 0; i < lines.length; i += 1) {
    const line = lines[i].trim();
    if (line.startsWith("DIMENSIONS")) {
      dims = line.split(/\s+/).slice(1, 4).map(Number);
    } else if (line.startsWith("X_COORDINATES")) {
      const count = Number(line.split(/\s+/)[1]);
      const parsed = parseVtkArray(lines, i + 1, count);
      x = parsed.values;
      i = parsed.next - 1;
    } else if (line.startsWith("Y_COORDINATES")) {
      const count = Number(line.split(/\s+/)[1]);
      const parsed = parseVtkArray(lines, i + 1, count);
      y = parsed.values;
      i = parsed.next - 1;
    } else if (line.startsWith("Z_COORDINATES")) {
      const count = Number(line.split(/\s+/)[1]);
      const parsed = parseVtkArray(lines, i + 1, count);
      z = parsed.values;
      i = parsed.next - 1;
    } else if (line.startsWith("CELL_DATA")) {
      cellCount = Number(line.split(/\s+/)[1]);
    } else if (line.startsWith("SCALARS")) {
      const parts = line.split(/\s+/);
      const name = parts[1];
      let cursor = i + 1;
      if ((lines[cursor] || "").trim().startsWith("LOOKUP_TABLE")) cursor += 1;
      const parsed = parseVtkArray(lines, cursor, cellCount);
      fields[name] = parsed.values;
      i = parsed.next - 1;
    }
  }
  return {
    path: relPath,
    dims,
    x,
    y,
    z,
    fields,
    cellCount,
    bounds: {
      min: [x[0], y[0], z[0]],
      max: [x[x.length - 1], y[y.length - 1], z[z.length - 1]],
    },
  };
}

function visitFileList(text) {
  return text
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter((line) => line && !line.startsWith("!") && line.endsWith(".vtk"))
    .map((line) => `Visit/${line}`);
}

function updateMeshVizStatus(text) {
  $("meshVizStatus").textContent = text;
}

async function loadMeshVisualization() {
  const manifest = await meshPreview();
  const limit = Math.max(1, Number($("meshBlockLimit").value || 128));
  const visitText = await textApi("/api/file?path=Visit%2Fmesh_preview.visit");
  const vtkFiles = visitFileList(visitText).slice(0, limit);
  const blocks = [];
  updateMeshVizStatus(`正在加载 ${vtkFiles.length} 个 VTK 分块...`);
  for (let index = 0; index < vtkFiles.length; index += 1) {
    const rel = vtkFiles[index];
    const text = await textApi(`/api/file?path=${encodeURIComponent(rel)}`);
    blocks.push(parseRectilinearVtk(text, rel));
    if ((index + 1) % 8 === 0 || index + 1 === vtkFiles.length) {
      updateMeshVizStatus(`已加载 ${index + 1}/${vtkFiles.length} 个分块...`);
      await new Promise((resolve) => setTimeout(resolve, 0));
    }
  }
  meshViz = buildMeshVizDataset(blocks, manifest);
  renderMeshVisualization();
  log("网格可视化已加载", {
    分块数: blocks.length,
    字段: meshViz.fields,
    单元数: meshViz.cellCount,
  });
}

function buildMeshVizDataset(blocks, manifest) {
  const bounds = {
    min: [Infinity, Infinity, Infinity],
    max: [-Infinity, -Infinity, -Infinity],
  };
  let cellCount = 0;
  const fields = new Set();
  blocks.forEach((block) => {
    for (let axis = 0; axis < 3; axis += 1) {
      bounds.min[axis] = Math.min(bounds.min[axis], block.bounds.min[axis]);
      bounds.max[axis] = Math.max(bounds.max[axis], block.bounds.max[axis]);
    }
    cellCount += block.cellCount;
    Object.keys(block.fields).forEach((field) => fields.add(field));
  });
  return {
    blocks,
    bounds,
    fields: Array.from(fields).sort(),
    cellCount,
    manifest,
  };
}

function selectedMeshField() {
  const requested = $("meshFieldSelect").value;
  if (!meshViz) return requested;
  if (meshViz.fields.includes(requested)) return requested;
  return meshViz.fields.includes("IBM_marker") ? "IBM_marker" : meshViz.fields[0];
}

function cellValue(block, field, index) {
  const values = block.fields[field] || block.fields.IBM_marker || [];
  return values[index] == null ? 0 : values[index];
}

function markerColor(value, alpha = 1) {
  if (value < 0) return `rgba(164, 62, 54, ${alpha})`;
  if (value === 0) return `rgba(119, 132, 146, ${alpha})`;
  if (value === 1) return `rgba(31, 116, 142, ${alpha})`;
  if (value === 2) return `rgba(43, 132, 95, ${alpha})`;
  if (value > 10) return `rgba(191, 125, 42, ${alpha})`;
  return `rgba(82, 95, 168, ${alpha})`;
}

function cellCenter(coords, i) {
  return 0.5 * (coords[i] + coords[i + 1]);
}

function project3d(point, bounds, canvas) {
  const center = [
    0.5 * (bounds.min[0] + bounds.max[0]),
    0.5 * (bounds.min[1] + bounds.max[1]),
    0.5 * (bounds.min[2] + bounds.max[2]),
  ];
  const span = Math.max(
    bounds.max[0] - bounds.min[0],
    bounds.max[1] - bounds.min[1],
    bounds.max[2] - bounds.min[2],
    1e-9,
  );
  const x = (point[0] - center[0]) / span;
  const y = (point[1] - center[1]) / span;
  const z = (point[2] - center[2]) / span;
  const px = (x - z * 0.72) * canvas.width * 0.72 + canvas.width * 0.5;
  const py = (-y + (x + z) * 0.28) * canvas.height * 0.72 + canvas.height * 0.54;
  return [px, py];
}

function drawLine(ctx, a, b, style) {
  ctx.strokeStyle = style;
  ctx.beginPath();
  ctx.moveTo(a[0], a[1]);
  ctx.lineTo(b[0], b[1]);
  ctx.stroke();
}

function blockCorners(block) {
  const min = block.bounds.min;
  const max = block.bounds.max;
  return [
    [min[0], min[1], min[2]],
    [max[0], min[1], min[2]],
    [max[0], max[1], min[2]],
    [min[0], max[1], min[2]],
    [min[0], min[1], max[2]],
    [max[0], min[1], max[2]],
    [max[0], max[1], max[2]],
    [min[0], max[1], max[2]],
  ];
}

function drawBlockBox(ctx, block, bounds, canvas) {
  const pts = blockCorners(block).map((point) => project3d(point, bounds, canvas));
  const edges = [
    [0, 1], [1, 2], [2, 3], [3, 0],
    [4, 5], [5, 6], [6, 7], [7, 4],
    [0, 4], [1, 5], [2, 6], [3, 7],
  ];
  ctx.lineWidth = 0.7;
  edges.forEach(([a, b]) => drawLine(ctx, pts[a], pts[b], "rgba(55, 72, 88, 0.24)"));
}

function renderMesh3d() {
  const canvas = $("mesh3dCanvas");
  const ctx = canvas.getContext("2d");
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.fillStyle = "#f8fafc";
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  if (!meshViz) return;
  const field = selectedMeshField();
  meshViz.blocks.forEach((block) => drawBlockBox(ctx, block, meshViz.bounds, canvas));
  const maxPoints = 32000;
  const stride = Math.max(1, Math.ceil(meshViz.cellCount / maxPoints));
  let globalIndex = 0;
  ctx.lineWidth = 1;
  meshViz.blocks.forEach((block) => {
    const nx = block.x.length - 1;
    const ny = block.y.length - 1;
    const nz = block.z.length - 1;
    for (let k = 0; k < nz; k += 1) {
      for (let j = 0; j < ny; j += 1) {
        for (let i = 0; i < nx; i += 1) {
          const local = i + nx * (j + ny * k);
          if (globalIndex % stride === 0) {
            const p = [
              cellCenter(block.x, i),
              cellCenter(block.y, j),
              cellCenter(block.z, k),
            ];
            const projected = project3d(p, meshViz.bounds, canvas);
            const value = cellValue(block, field, local);
            ctx.fillStyle = markerColor(value, 0.62);
            ctx.fillRect(projected[0], projected[1], value === 0 ? 1.6 : 2.4, value === 0 ? 1.6 : 2.4);
          }
          globalIndex += 1;
        }
      }
    }
  });
  ctx.fillStyle = "#1f2a33";
  ctx.font = "12px ui-monospace, monospace";
  ctx.fillText(`${field} 采样单元，${meshViz.blocks.length} 个分块`, 12, 22);
}

function axisIndex(axis) {
  return axis === "x" ? 0 : axis === "y" ? 1 : 2;
}

function sliceCoordinates(block, axis, i, j, k) {
  if (axis === "x") return [cellCenter(block.y, j), cellCenter(block.z, k)];
  if (axis === "y") return [cellCenter(block.x, i), cellCenter(block.z, k)];
  return [cellCenter(block.x, i), cellCenter(block.y, j)];
}

function renderMeshSlice() {
  const canvas = $("meshSliceCanvas");
  const ctx = canvas.getContext("2d");
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.fillStyle = "#f8fafc";
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  if (!meshViz) return;
  const axis = $("sliceAxis").value;
  const field = selectedMeshField();
  const ai = axisIndex(axis);
  const center = 0.5 * (meshViz.bounds.min[ai] + meshViz.bounds.max[ai]);
  const planeBounds = { min: [Infinity, Infinity], max: [-Infinity, -Infinity] };
  const cells = [];
  meshViz.blocks.forEach((block) => {
    const nx = block.x.length - 1;
    const ny = block.y.length - 1;
    const nz = block.z.length - 1;
    const coords = axis === "x" ? block.x : axis === "y" ? block.y : block.z;
    const centers = coords.slice(0, -1).map((_, idx) => cellCenter(coords, idx));
    const nearest = centers.reduce(
      (best, value, idx) => (Math.abs(value - center) < best.dist ? { idx, dist: Math.abs(value - center) } : best),
      { idx: 0, dist: Infinity },
    ).idx;
    for (let k = 0; k < nz; k += 1) {
      for (let j = 0; j < ny; j += 1) {
        for (let i = 0; i < nx; i += 1) {
          if ((axis === "x" && i !== nearest) || (axis === "y" && j !== nearest) || (axis === "z" && k !== nearest)) {
            continue;
          }
          const local = i + nx * (j + ny * k);
          const uv = sliceCoordinates(block, axis, i, j, k);
          planeBounds.min[0] = Math.min(planeBounds.min[0], uv[0]);
          planeBounds.min[1] = Math.min(planeBounds.min[1], uv[1]);
          planeBounds.max[0] = Math.max(planeBounds.max[0], uv[0]);
          planeBounds.max[1] = Math.max(planeBounds.max[1], uv[1]);
          cells.push({ uv, value: cellValue(block, field, local) });
        }
      }
    }
  });
  const pad = 28;
  const sx = (canvas.width - pad * 2) / Math.max(planeBounds.max[0] - planeBounds.min[0], 1e-9);
  const sy = (canvas.height - pad * 2) / Math.max(planeBounds.max[1] - planeBounds.min[1], 1e-9);
  const scale = Math.min(sx, sy);
  const radius = Math.max(1, Math.min(3, scale * 0.00065));
  cells.forEach((cell) => {
    const x = pad + (cell.uv[0] - planeBounds.min[0]) * scale;
    const y = canvas.height - pad - (cell.uv[1] - planeBounds.min[1]) * scale;
    ctx.fillStyle = markerColor(cell.value, 0.86);
    ctx.fillRect(x, y, radius, radius);
  });
  ctx.strokeStyle = "rgba(55, 72, 88, 0.35)";
  ctx.strokeRect(
    pad,
    canvas.height - pad - (planeBounds.max[1] - planeBounds.min[1]) * scale,
    (planeBounds.max[0] - planeBounds.min[0]) * scale,
    (planeBounds.max[1] - planeBounds.min[1]) * scale,
  );
  ctx.fillStyle = "#1f2a33";
  ctx.font = "12px ui-monospace, monospace";
  ctx.fillText(`${field} ${axis.toUpperCase()} 中央截面，${cells.length} 个单元`, 12, 22);
}

function renderMeshVisualization() {
  if (!meshViz) return;
  const select = $("meshFieldSelect");
  const current = select.value;
  select.innerHTML = "";
  meshViz.fields.forEach((field) => {
    const option = document.createElement("option");
    option.value = field;
    option.textContent = field;
    select.appendChild(option);
  });
  select.value = meshViz.fields.includes(current) ? current : selectedMeshField();
  renderMesh3d();
  renderMeshSlice();
  updateMeshVizStatus(
    `已加载 ${meshViz.blocks.length} 个分块，${meshViz.cellCount.toLocaleString()} 个单元。范围 x=${meshViz.bounds.min[0].toExponential(2)}..${meshViz.bounds.max[0].toExponential(2)}, y=${meshViz.bounds.min[1].toExponential(2)}..${meshViz.bounds.max[1].toExponential(2)}, z=${meshViz.bounds.min[2].toExponential(2)}..${meshViz.bounds.max[2].toExponential(2)}。`,
  );
}

function renderBoundaryTable(payload) {
  const patches = payload.patches || [];
  const rows = patches
    .map((patch) => {
      const selector = patch.selector || {};
      const normal = patch.averageNormal ? patch.averageNormal.join(", ") : "";
      const area = patch.area == null ? "" : Number(patch.area).toExponential(4);
      return `<tr>
        <td>${patch.name}</td>
        <td>${patch.kind}</td>
        <td>${patch.type}</td>
        <td>${patch.matchedFaces ?? ""}</td>
        <td>${area}</td>
        <td>${normal}</td>
        <td>${selector.source || ""}</td>
        <td>${selector.region || ""}</td>
        <td>${selector.uses_patch_stl ? "是" : "否"}</td>
      </tr>`;
    })
    .join("");
  $("boundaryTable").innerHTML = `<table>
    <thead><tr><th>名称</th><th>类别</th><th>类型</th><th>面数</th><th>面积</th><th>法向</th><th>来源</th><th>区域</th><th>Patch STL</th></tr></thead>
    <tbody>${rows}</tbody>
  </table>`;
}

async function boundaryPreview() {
  const payload = await api("/api/boundary/preview");
  renderBoundaryTable(payload);
  log("边界预览已生成", payload);
}

async function boundarySidecar() {
  const payload = await api("/api/boundary/sidecar", { method: "POST", body: "{}" });
  if ($("boundaryOutput")) $("boundaryOutput").textContent = JSON.stringify(payload, null, 2);
  log("边界 sidecar 已生成", payload);
  await listFiles();
}

async function boundaryStlLabels() {
  const payload = await api("/api/boundary/stl-labels");
  if ($("boundaryOutput")) $("boundaryOutput").textContent = JSON.stringify(payload, null, 2);
  log("边界 STL 标签已生成", payload);
  await listFiles();
}

async function boundaryWriteDsl(apply) {
  const payload = await api("/api/boundary/write-dsl", {
    method: "POST",
    body: JSON.stringify({ apply }),
  });
  if ($("boundaryOutput")) $("boundaryOutput").textContent = JSON.stringify(payload, null, 2);
  log(apply ? "边界 DSL 已备份并应用" : "边界 DSL 草稿已写入", payload);
  await listFiles();
  await refreshStatus();
}

async function runPlan() {
  const ranks = $("ranksInput").value ? Number($("ranksInput").value) : null;
  const payload = await api("/api/run/plan", {
    method: "POST",
    body: JSON.stringify({ ranks }),
  });
  log("运行计划已生成", payload);
}

async function runStart() {
  const ranks = $("ranksInput").value ? Number($("ranksInput").value) : null;
  const payload = await api("/api/run/start", {
    method: "POST",
    body: JSON.stringify({ ranks }),
  });
  log("已请求启动计算", payload);
}

async function runStop() {
  const payload = await api("/api/stop", {
    method: "POST",
    body: JSON.stringify({ dryRun: false }),
  });
  log("已请求停止计算", payload);
}

async function loadScreen() {
  try {
    const text = await textApi("/api/file?path=screen");
    $("screenTail").textContent = text.split("\n").slice(-160).join("\n");
  } catch (error) {
    $("screenTail").textContent = String(error);
  }
}

async function writeReport(packArchive) {
  const payload = await api("/api/archive", {
    method: "POST",
    body: JSON.stringify({ archive: packArchive }),
  });
  setKv($("archiveList"), {
    写入文件: payload.written,
    归档文件: payload.archive || "",
    归档SHA256: payload.archiveSha256 || "",
    文件数量: (payload.files || []).length,
    Visit集合: (payload.visitCollections || []).length,
  });
  log(packArchive ? "小归档已写入" : "运行报告已写入", payload);
  await listFiles();
}

function renderDownloads() {
  const list = $("downloadList");
  if (!list) return;
  list.innerHTML = "";
  files.forEach((file) => {
    const li = document.createElement("li");
    const link = document.createElement("a");
    link.href = `/api/file?path=${encodeURIComponent(file.path)}`;
    link.textContent = file.path;
    link.target = "_blank";
    li.appendChild(link);
    const size = document.createElement("span");
    size.textContent = `${file.sizeBytes} B`;
    li.appendChild(size);
    list.appendChild(li);
  });
}

function formatBytes(bytes) {
  const value = Number(bytes || 0);
  if (value >= 1024 * 1024 * 1024) return `${(value / 1024 / 1024 / 1024).toFixed(2)} GB`;
  if (value >= 1024 * 1024) return `${(value / 1024 / 1024).toFixed(1)} MB`;
  if (value >= 1024) return `${(value / 1024).toFixed(1)} KB`;
  return `${value} B`;
}

async function renderVisitCollections() {
  const list = $("visitList");
  if (!list) return;
  const summary = $("visitSummary");
  list.innerHTML = "";
  const payload = await api("/api/visit/summary");
  const groups = payload.groups || [];
  if (summary) {
    summary.textContent = groups.length
      ? `共 ${groups.length} 个集合，${payload.manifestCount || 0} 个 .visit，${payload.vtkCount || 0} 个 .vtk，约 ${formatBytes(payload.totalBytes)}。`
      : "尚未发现 Visit 输出文件。";
  }
  if (!groups.length) {
    return;
  }
  groups.forEach((group) => {
    const card = document.createElement("section");
    card.className = "visit-group";
    const head = document.createElement("div");
    head.className = "visit-group-head";
    const title = document.createElement("div");
    title.className = "visit-group-title";
    title.textContent = group.key;
    const actions = document.createElement("div");
    actions.className = "row-actions";
    const manifest = (group.manifests || [])[0];
    if (manifest) {
      const open = document.createElement("a");
      open.className = "button-link";
      open.href = `/api/file?path=${encodeURIComponent(manifest.path)}`;
      open.target = "_blank";
      open.textContent = "打开 .visit";
      actions.appendChild(open);
    }
    const pack = document.createElement("a");
    pack.className = "button-link primary";
    pack.href = `/api/visit/package?group=${encodeURIComponent(group.key)}`;
    pack.textContent = "打包下载";
    actions.appendChild(pack);
    head.appendChild(title);
    head.appendChild(actions);
    const meta = document.createElement("div");
    meta.className = "visit-group-meta";
    meta.textContent = `${group.manifestCount} 个 .visit，${group.vtkCount} 个 .vtk，${formatBytes(group.totalBytes)}`;
    const sample = document.createElement("div");
    sample.className = "visit-sample";
    const sampleFiles = [...(group.manifests || []), ...(group.vtks || [])].slice(0, 8);
    sampleFiles.forEach((file) => {
      const link = document.createElement("a");
      link.href = `/api/file?path=${encodeURIComponent(file.path)}`;
      link.target = "_blank";
      link.textContent = file.path;
      sample.appendChild(link);
    });
    const size = document.createElement("span");
    size.textContent = sampleFiles.length < group.manifestCount + group.vtkCount ? "..." : "";
    if (size.textContent) sample.appendChild(size);
    card.appendChild(head);
    card.appendChild(meta);
    card.appendChild(sample);
    list.appendChild(card);
  });
}

function currentPostDataset() {
  const datasetKey = $("postDataset") ? $("postDataset").value : "";
  return postState.datasets.find((dataset) => dataset.key === datasetKey) || postState.datasets[0];
}

function updatePostFields() {
  const fieldSelect = $("postField");
  const plotType = $("postPlotType") ? $("postPlotType").value : "Pseudocolor";
  if (!fieldSelect) return;
  const dataset = currentPostDataset();
  const previous = fieldSelect.value;
  fieldSelect.innerHTML = "";
  const fields = dataset ? (plotType === "Vector" ? dataset.vectors || [] : dataset.scalars || []) : [];
  fields.forEach((field) => {
    const option = document.createElement("option");
    option.value = field;
    option.textContent = field;
    fieldSelect.appendChild(option);
  });
  if (fields.includes(previous)) {
    fieldSelect.value = previous;
  } else if (plotType !== "Vector") {
    const preferred = ["02_Temperature", "02_Static_pressure", "04_Heat_release_rate", "01_Mach_number"].find((field) => fields.includes(field));
    fieldSelect.value = preferred || fields[0] || "";
  } else {
    fieldSelect.value = fields.includes("COAST_velocity") ? "COAST_velocity" : fields[0] || "";
  }
}

async function loadPostprocessSummary() {
  const payload = await api("/api/postprocess/summary");
  postState = { datasets: payload.datasets || [] };
  const datasetSelect = $("postDataset");
  if (datasetSelect) {
    const previous = datasetSelect.value;
    datasetSelect.innerHTML = "";
    postState.datasets.forEach((dataset) => {
      const option = document.createElement("option");
      option.value = dataset.key;
      option.textContent = `${dataset.key} (${dataset.vtkCount} VTK)`;
      datasetSelect.appendChild(option);
    });
    const solution = postState.datasets.find((dataset) => dataset.key.startsWith("solution."));
    datasetSelect.value = postState.datasets.some((dataset) => dataset.key === previous)
      ? previous
      : (solution || postState.datasets[0] || {}).key || "";
  }
  updatePostFields();
  const status = $("postStatus");
  if (status) {
    status.textContent = payload.visitAvailable
      ? `VisIt: ${payload.visitBin}。已发现 ${postState.datasets.length} 个可绘图数据集合。`
      : "未找到 VisIt 可执行程序，请设置 COAST_VISIT_BIN。";
  }
  log("后处理字段已刷新", payload);
}

async function renderPostprocessPlot() {
  const dataset = currentPostDataset();
  if (!dataset) return;
  const body = {
    dataset: dataset.key,
    plotType: $("postPlotType").value,
    field: $("postField").value,
    mode: $("postMode").value,
  };
  const status = $("postStatus");
  if (status) status.textContent = "正在调用 VisIt 生成图片...";
  const payload = await api("/api/postprocess/plot", {
    method: "POST",
    body: JSON.stringify(body),
  });
  const image = $("postImage");
  const download = $("postImageDownload");
  const logBox = $("postLog");
  const imageUrl = `${payload.url}&t=${Date.now()}`;
  if (image) {
    image.src = imageUrl;
    image.hidden = false;
  }
  if (download) {
    download.href = payload.url;
    download.hidden = false;
  }
  if (logBox) {
    logBox.textContent = `状态: PNG 已生成\n数据: ${payload.dataset}\n类型: ${payload.plotType}\n字段: ${payload.field}\n视图: ${payload.mode}\n文件: ${payload.path}\nVisIt 返回码: ${payload.returncode}\n\n${payload.stdoutTail || ""}\n${payload.stderrTail || ""}`;
  }
  if (status) status.textContent = `已生成 ${payload.plotType} / ${payload.field} / ${payload.mode}`;
  log("后处理图片已生成", payload);
}

function activateTab(name) {
  document.querySelectorAll(".tab").forEach((button) => {
    button.classList.toggle("active", button.dataset.tab === name);
  });
  document.querySelectorAll(".view").forEach((view) => {
    view.classList.toggle("active", view.id === name);
  });
}

function bind(id, fn) {
  const element = $(id);
  if (!element) return;
  element.addEventListener("click", async () => {
    try {
      await fn();
    } catch (error) {
      log("操作失败", { error: String(error) });
    }
  });
}

document.querySelectorAll(".tab").forEach((button) => {
  button.addEventListener("click", () => activateTab(button.dataset.tab));
});

bind("refreshAll", async () => {
  await refreshStatus();
  await listFiles();
});
bind("validateCase", refreshStatus);
bind("loadFiles", listFiles);
bind("loadFile", loadSelectedFile);
bind("saveFile", saveSelectedFile);
bind("loadSettings", loadSettings);
bind("saveSettings", saveCurrentSettings);
bind("meshPreview", meshPreview);
bind("loadMeshViz", loadMeshVisualization);
bind("boundaryPreview", boundaryPreview);
bind("boundarySidecar", boundarySidecar);
bind("boundaryStlLabels", boundaryStlLabels);
bind("boundaryWriteDsl", () => boundaryWriteDsl(false));
bind("boundaryApplyDsl", () => boundaryWriteDsl(true));
bind("runPlan", runPlan);
bind("runStart", runStart);
bind("runStop", runStop);
bind("loadScreen", loadScreen);
bind("archiveSummary", async () => {
  await listFiles();
});
bind("writeReport", () => writeReport(false));
bind("writeArchive", () => writeReport(true));
bind("refreshDownloads", listFiles);
bind("loadPostprocess", loadPostprocessSummary);
bind("renderPostprocess", renderPostprocessPlot);
if ($("settingsFilter")) $("settingsFilter").addEventListener("input", renderSettingsForm);
if ($("meshFieldSelect")) $("meshFieldSelect").addEventListener("change", renderMeshVisualization);
if ($("sliceAxis")) $("sliceAxis").addEventListener("change", renderMeshVisualization);
if ($("postDataset")) $("postDataset").addEventListener("change", updatePostFields);
if ($("postPlotType")) $("postPlotType").addEventListener("change", updatePostFields);

refreshStatus()
  .then(listFiles)
  .then(loadSettings)
  .then(loadPostprocessSummary)
  .then(boundaryPreview)
  .catch((error) => log("初始加载失败", { error: String(error) }));
