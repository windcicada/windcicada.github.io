export COAST_HOME=${COAST_HOME:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}
export PATH="$COAST_HOME/bin:$PATH"
export LD_LIBRARY_PATH="$COAST_HOME/lib:${LD_LIBRARY_PATH:-}"
