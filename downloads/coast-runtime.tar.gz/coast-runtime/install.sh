#!/usr/bin/env bash
set -euo pipefail
package_dir=$(cd "$(dirname "$0")" && pwd)
prefix=${1:-${COAST_PREFIX:-$HOME/.local/coast}}
mkdir -p "$prefix"
items=(bin env EXEC_TEMPLATE manifest.json PACKAGE_AUDIT.json)
for optional in ui docs agent_skills SKILL.md; do
  if [ -e "$package_dir/$optional" ]; then items+=("$optional"); fi
done
cp -a "${items[@]/#/$package_dir/}" "$prefix"/
echo "installed runtime to $prefix"
echo "source $prefix/env/coast-env.sh"
