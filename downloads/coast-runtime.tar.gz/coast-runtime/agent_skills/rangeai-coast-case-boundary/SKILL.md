---
name: rangeai-coast-case-boundary
description: Modify packaged 本软件 case settings and boundary-condition *.d files using supported direct input files and coordinate-compatible boundary selectors.
---

# RangeAI 本软件 Case And Boundary Editing

Use this skill when changing a packaged 本软件 case without editing Fortran or
C++ source.

## Editable Files

For a packaged working case such as `EXEC.demo`, edit only these files unless
the user explicitly asks for a deeper change:

```text
EXEC.demo/input.d
EXEC.demo/ibm_mesh.d
EXEC.demo/boundary_conditions.d
EXEC.demo/vtk_output.d
EXEC.demo/spray.d
EXEC.demo/spark.d
EXEC.demo/probe.d
EXEC.demo/heat_release.d
EXEC.demo/mesh5_auto_refine.d
```

Do not edit `Restart`, `runtime_mesh`, `Decomp`, `Geometry`, `Fuels`, or Visit
output as a substitute for a settings change.

## Main Settings

- `input.d`: restart flags, `lstep`, output cadence, PDF flags, solver and
  combustion controls.
- `ibm_mesh.d`: geometry source, mesh generator settings, IBM marker scanning,
  Mesh-4 preview controls, and static mesh controls.
- `vtk_output.d`: fields written to Visit.
- `mesh5_auto_refine.d`: optional automatic local-refinement candidate scoring
  using normalized geometry, vorticity, reaction-rate, configured focus-region,
  and configured centerline indicators. Keep case-specific refinement settings
  here, not in source code. Important keys include `enabled`, `on_restart`,
  `candidate_generation`, `split_candidate`, `focus_region_*`,
  `centerline_*`, `target_min_spacing`,
  `target_fluid_cells_per_rank_min/max`, `partition_alignment`, and
  `field_sample_stride`. Candidate generation is not the same as active solver
  mesh promotion.

After editing:

```bash
bin/coastctl case validate --case-dir EXEC.demo --json
bin/coastctl mesh status --case-dir EXEC.demo --json
```

## Boundary Conditions

`boundary_conditions.d` is the supported boundary authoring file. It must remain
compatible with cases that do not have patch STL labels. Coordinate selectors
are valid.

Patch structure:

```text
patch patch_name
{
  kind inlet;
  type fixedVelocityInlet;
  enabled true;
  priority 10;
  selector
  {
    source externalBoundary;
    side left;
    marker -1;
    region cylinderRing;
    axis y;
    center (0 0);
    radiusRange (0.0 0.03);
    axialCoordinate y;
    axialRange (-1.0e30 1.0e30);
  }
  targetMarker -1;
  U fixedValue (0 8.0 0);
  T fixedValue 295;
  p fixedValue 100000;
  composition volumeFraction
  {
    O2 0.21;
    N2 0.79;
    normalize true;
  }
}
```

Rules:

- Use `source externalBoundary` for domain faces and `source ibmSurface` for
  IBM-adjacent surfaces that already exist as fluid-connected faces.
- Do not use a boundary selector to turn solid cells into fluid. Mesh topology
  changes belong in `ibm_mesh.d` and runtime mesh generation.
- Use `patchGeometry`, `patchTriangles`, or `cadFaceIds` only when the package
  or user supplies reliable labels. Otherwise use `side`, `region`, coordinate
  ranges, and marker lists.
- Keep species names exactly as the chemistry mechanism expects, for example
  `CH4`, `O2`, `N2`, `CO2`, `CO`, `H2O`, `H2`, `OH`, `O`, and `H`.
- Prefer SI units: m, s, kg, K, Pa, m/s, and kg/s.

Validate boundary edits:

```bash
bin/coastctl boundary preview --case-dir EXEC.demo --write --json
bin/coastctl case validate --case-dir EXEC.demo --json
```

If a selector is empty, first check side, marker, coordinate range, and whether
the mesh actually exposes the intended fluid face. Do not paper over an empty
inlet by changing all markers to `any` unless the coordinate bounds are tight
and the physical reason is clear.
