---
name: rangeai-coast-portable
description: Install, run, monitor, and collect outputs from the packaged 本软件 portable runtime without using the full development source tree.
---

# RangeAI 本软件 Portable Install And Run

Use this skill when operating a packaged 本软件 runtime directory.

## Identify The Package

From the package root:

```bash
pwd
ls bin/coast bin/coast_remap bin/coastctl bin/coast-ui EXEC_TEMPLATE manifest.json
cat manifest.json
```

If the package is not installed yet:

```bash
bash install.sh "$HOME/.local/coast"
source "$HOME/.local/coast/env/coast-env.sh"
coastctl doctor --case-dir "$HOME/.local/coast/EXEC_TEMPLATE" --json
```

If running directly from the unpacked package, use:

```bash
source env/coast-env.sh
bin/coastctl doctor --case-dir EXEC_TEMPLATE --json
```

## Create A Working Case

Do not run in `EXEC_TEMPLATE`. Create a writable case:

```bash
cp -a EXEC_TEMPLATE EXEC.demo
```

Then validate:

```bash
bin/coastctl case validate --case-dir EXEC.demo --json
bin/coastctl mesh status --case-dir EXEC.demo --json
```

## Start The Chinese 图形辅助界面

On the server:

```bash
bin/coast-ui --workspace "$PWD" --case-dir "$PWD/EXEC.demo" --host 127.0.0.1 --port 18765
```

From Windows PowerShell, forward the port:

```powershell
ssh -N -L 18765:127.0.0.1:18765 user@server
```

Open `http://127.0.0.1:18765` in the Windows browser.

Use `--host 0.0.0.0` only on a trusted private network or behind a firewall.

## Bounded Run Flow

1. Edit `EXEC.demo/input.d` so `lstep`, `stepsave`, and `stepplot` match the
   requested bounded test.
2. Validate the case and mesh.
3. Dry-plan the launch:

```bash
bin/coastctl run --case-dir EXEC.demo --ranks 128 --preflight --json
```

`coastctl run --preflight/--execute` uses the C++ `coast_remap` backend by
default when Restart must be prepared for a target runtime mesh. Use Python only
when explicitly diagnosing with `--remap-backend python-reference`; missing
`coast_remap` is a package/runtime error, not a silent fallback.

4. Start only when authorized:

```bash
bin/coastctl run --case-dir EXEC.demo --ranks 128 --execute --write --json
```

Direct `mpirun` is only for a case whose `Restart/`, `Restart/runtime_mesh/`,
and `runtime_mesh/` are already prepared and rank-matched. It does not perform
automatic remap.

5. Monitor:

```bash
bin/coastctl monitor --case-dir EXEC.demo --json
tail -80 EXEC.demo/screen
```

6. Stop gently:

```bash
bin/coastctl stop --case-dir EXEC.demo --json
```

## Outputs To Return

For a successful short run, report:

- run status from `coastctl monitor`;
- latest `Visit/solution.visit`;
- count of matching `Visit/solution.*.vtk` files;
- latest `Restart/restart.*` and `Restart/restart_pdf.*` counts when restart
  output is enabled;
- any lines in `stderr.log`, `stdout.log`, or `screen` that indicate a stop,
  numerical guard, or solver failure.
