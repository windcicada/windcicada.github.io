&spray_control
  ! COAST 喷雾设置。注意：本文件第一行必须是 &spray_control。
  ! 常用设置：
  ! spray 为喷雾总开关；当前为 .false.。
  ! mass_coup / mom_coup / vaporize 控制质量、动量、蒸发耦合。
  ! read_spray_pdf / write_spray_pdf 控制喷雾 PDF 重启动读写。
  ! spray_vtk_summary / spray_particle_snapshot 控制喷雾后处理输出。
  ! spray_max_particles 等容量参数控制并行粒子负载上限。
  ! TCR_MULTI_INJECT 后面的数据块按旧喷雾读入顺序解析，不要随意重排。
  spraydir = '/SPRAYs/'
  spray = .false.
  spray_liquid_fuel = 'methane'
  c0 = 1.21
  reflective_boundary = .true.
  mass_coup = .false.
  mom_coup = .false.
  vaporize = .false.
  stochavapo = .false.
  cv = 1
  breakup = .false.
  stochabreak = .false.
  csb = 2
  debug = .false.
  snapshot = 0
  read_spray_pdf = .false.
  write_spray_pdf = .false.
  part_stat = .false.
  restart_stat_spray = .false.
  spray_vtk_summary = .false.
  spray_particle_snapshot = .false.
  spray_max_particles = 200000
  spray_work_capacity = 20000
  spray_max_added = 20000
  spray_cross_packet = 4096
/

!=======================================================================
! 喷雾注入几何
!-----------------------------------------------------------------------
! spray = .true. 时，INJ_def 会从同一文件读取下面的 TCR_MULTI_INJECT 数据块。
! 标记后必须紧跟数据行：
! 1 环形喷嘴标志
! 2 空心锥标志
! 3 喷嘴数量
! 4 直径分箱数量
! 5 每次注入的 parcel 数量
! 6 直径分布参数 q_d 和 SMD
! 7 是否从 EXEC/injector/ 读取缓存喷嘴位置
! 8 液滴注入温度 [K]
! 每个喷嘴后续六行依次为：
! 中心 x y z [m]、半径 [m]、方向 sx sy sz、
! 锥角和扩散角 [deg]、粒子率、注入速度 [m/s]。
!=======================================================================
TCR_MULTI_INJECT
true
true
1
100
20
2.5 20
false
340
-0.0084375 -0.0016875 -0.0013
0.0075
0 0 1
0 62
0.003
50
