C=======================================================================
C   COAST IBM 与网格生成设置
C-----------------------------------------------------------------------
C   DIRECT MESH COMMON TUNING PARAMETERS
C      重点区域：Y < 0.04 m。
C      重点区域：-0.03 < X < 0.03 m。
C      重点区域：-0.03 < Z < 0.03 m。
C      中轴线：X=0 且 Z=0 附近需要加密；权重/半径见 mesh5_auto_refine.d。
C      最小网格尺度：0.25~0.5 mm；直接建网格优先搜索 0.45~0.50 mm。
C      每块流体网格：3~4 万，尽量接近 3 万；同时限制每块总数组规模。
C      分块边界：production 只允许当前 solver 支持的全局 X/Y/Z 对齐切面；
C                非对齐/非匹配 halo 必须 fail-closed，不推广 active。
C      Restart 策略：direct mesh 不运行 restart_remap_staging，不要求旧 Restart 可续算。
C-----------------------------------------------------------------------
C   常用设置索引：
C   1) &mesh_control
C      enabled            = 是否启动时生成网格/分块。
C      overwrite_decomp   = 是否覆盖 EXEC/Decomp。
C      write_preview      = 是否输出网格预览。
C   2) &mesh_runtime
C      mesh_source        = 当前网格权威来源；正式运行保持 runtime_conformal。
C      allow_run_from_decomp = 是否允许直接用旧 Decomp，正式运行保持 false。
C   3) Mesh-4/Mesh-5 相关控制
C      只允许通过已推广的 runtime_mesh/Restart 闭环进入求解器；
C      单块分裂算法当前关闭，自动重划分由 mesh5_auto_refine.d 控制。
C   4) IBM/壁面
C      write_preview_diagnostics 调试时才打开，正式算例保持 false。
C
C   本文件保留 namelist 顺序，方便 Fortran 读取；不要把这些开关移到 input.d。
C=======================================================================

C=======================================================================
C   MESH CONTROL
C-----------------------------------------------------------------------
C   enabled:
C       true  = generate EXEC/Decomp before solver startup.
C       false = use existing EXEC/Decomp files.
C   mode:
C       generate_on_start is the initial supported integrated mode.
C   overwrite_decomp:
C       true allows generated output to replace existing EXEC/Decomp files.
C   write_compat_decomp:
C       true writes legacy Decomp/config and grid_vv.* for the current solver.
C   write_preview/write_preview_diagnostics/write_report:
C       Write lightweight mesh review outputs for debugging and case review.
C       write_preview writes only the core review fields by default:
C       Mesh_block_id, IBM_marker, and refinement_level.
C       write_preview_diagnostics additionally writes raw CAD/ray diagnostic
C       fields such as IBM_ray_candidate and IBM_scan_ambiguous.  Keep it
C       false for normal review because those fields are not solver markers
C       and can contain scan-line artifacts by design.
C=======================================================================
&mesh_control
  enabled = .false.
  mode = 'generate_on_start'
  overwrite_decomp = .false.
  write_compat_decomp = .true.
  write_preview = .true.
  write_preview_diagnostics = .false.
  write_report = .true.
/


C=======================================================================
C   MESH RUNTIME AUTHORITY
C-----------------------------------------------------------------------
C   mesh_source:
C       legacy_decomp      = use a manually prepared Decomp as the mesh
C                            authority. This is only allowed when
C                            allow_run_from_decomp is true.
C       generated_decomp   = generate Decomp and intentionally use it as
C                            the current solver mesh source.
C       runtime_conformal  = runtime mesh is the authority; Decomp is only
C                            a generated compatibility bridge while old
C                            initialization code is being migrated.
C       runtime_amr        = reserved for true non-matching block AMR. This
C                            mode must not fall back to Decomp.
C   export_decomp:
C       true writes Decomp/config and grid_vv.* as compatibility/debug output.
C   allow_run_from_decomp:
C       false prevents accidental manual-Decomp debugging in new mesh modes.
C   validate_decomp_export:
C       true validates generated Decomp counts before legacy readers open it.
C   require_mesh_manifest_match:
C       true requires Decomp/mesh_generator_manifest.json to match the active
C       mesh source and MPI rank count.
C=======================================================================
&mesh_runtime
  mesh_source = 'runtime_conformal'
  export_decomp = .true.
  allow_run_from_decomp = .false.
  validate_decomp_export = .true.
  require_mesh_manifest_match = .true.
/

C=======================================================================
C   MESH-4 DYNAMIC REGRID CONTROL
C-----------------------------------------------------------------------
C   enabled:
C       true  = build runtime tag fields and load-balance diagnostics.
C       false = keep Mesh-3 behavior with no regrid metadata.
C   mode:
C       off       = no tag or regrid action.
C       tag_only  = write Regrid_tag, runtime_mesh/regrid_tags_*.dat, and
C                   runtime_mesh/regrid_report.dat.  This is the current safe
C                   Mesh-4.0 mode; it does not move mesh or fields.
C       conservative_transfer = reserved for future conservative field
C                   transfer after a new conformal mesh is generated.
C       dynamic   = reserved for future runtime redistribution/regrid.
C   interval_steps:
C       Intended future regrid-check interval in solver steps.  In tag_only
C       mode this is documented in reports but no mesh motion is performed.
C   warmup_steps:
C       Future guard interval before regrid checks are allowed after startup.
C   wall_tag_distance:
C       Fluid cells within this signed-distance band are tagged as near-wall
C       regrid candidates.  Use 0.0 to derive it from wall_refine_distance and
C       interface_band_cells.
C   interface_tag_level/wall_tag_level:
C       Integer tag values written to Visit/runtime_mesh.  Larger values mean
C       stronger refinement/regrid priority.
C   load_imbalance_threshold:
C       If max(block_weight)/avg(block_weight) exceeds this value, the report
C       marks trigger_regrid=true.  tag_only still reports only; it does not
C       redistribute fields.
C   write_tag_field/write_report:
C       Control runtime_mesh/regrid_tags_*.dat and regrid_report.dat output.
C   write_proposal:
C       true writes Mesh-4.1 runtime_mesh/regrid_proposal.dat.  The proposal
C       estimates a new conformal grid and block-load balance from Regrid_tag
C       but does not change the active solver mesh.
C   write_candidate_preview:
C       true writes Mesh-4.2 Visit/mesh_regrid_candidate_preview.visit.  This
C       is a visualization-only candidate grid and does not replace the active
C       solver grid.
C   proposal_refine_tag_level:
C       Minimum Regrid_tag value projected to candidate refined axes.
C       Use 2 by default so only strong interface/cut-cell tags drive the
C       Mesh-4.1 local conformal-grid proposal.  Tag 1 remains useful for
C       load statistics and near-wall diagnostics, but projecting all tag-1
C       cells can expand the proposal to the full domain.
C   proposal_axis_min_relative_density:
C       For each x/y/z axis, count strong-tag cells on every grid plane and
C       keep only planes whose count is at least this fraction of that axis'
C       maximum count.  This prevents a single cut cell from refining an
C       entire structured coordinate direction.
C   proposal_axis_max_marked_fraction:
C       If an axis would still keep more than this fraction of its cells, that
C       axis is treated as globally tagged and is left at the active grid
C       coordinates.  Use 1.0 to disable this locality filter.
C   proposal_preview_split_factor:
C       Visualization/proposal split factor for selected candidate cells.  The
C       default value 2 makes the candidate preview visibly refine tagged local
C       intervals even when the active grid is already at min_dx/min_dy/min_dz.
C       This does not alter the active solver mesh.
C   preview_surface_flow_strategy:
C       true enables Mesh-4.3 candidate-preview scoring from surface proximity,
C       configured flow direction and configured refinement/coarsening regions.
C       This is preview-only and does not alter the active solver mesh.
C   preview_region_axis:
C       Coordinate axis used for the case-level refinement/coarsening regions.
C       Current swirler case uses 'y'.  Change this for other geometries.
C   preview_flow_axis/preview_flow_direction:
C       Estimated main-flow axis and sign.  Current case uses +Y.  These values
C       are written to diagnostics and used for Flow_corridor_score.
C   preview_surface_distance:
C       Wall/surface distance band used for Surface_refine_score.
C   preview_high_region_min/max:
C       High-priority refinement interval on preview_region_axis.  Current
C       default covers the swirler body and swirler outlet neighborhood.
C   preview_medium_region_min/max:
C       Medium-priority refinement interval downstream of the high region.
C   preview_coarsen_region_min/max:
C       Region where candidate preview should not add new refinement.  Current
C       default protects the far outlet region near Y > 0.10 from extra
C       preview refinement.
C   proposal_axis_padding_cells:
C       Number of current-grid cells added around tagged axis intervals before
C       building the conformal candidate grid.
C   proposal_max_cell_growth:
C       Upper bound for candidate total cell count divided by current cell
C       count.  If an axis projection would exceed this budget, that axis falls
C       back to the active coordinates and the proposal is marked capped.
C   allow_runtime_redistribution:
C       Must remain false until Mesh-4 conservative field transfer and pressure
C       compatibility are implemented and tested.
C=======================================================================
&mesh_regrid
  enabled = .true.
  mode = 'tag_only'
  interval_steps = 200
  warmup_steps = 500
  wall_tag_distance = 0.0
  interface_tag_level = 2
  wall_tag_level = 1
  load_imbalance_threshold = 1.35
  write_tag_field = .true.
  write_report = .true.
  write_proposal = .true.
  write_candidate_preview = .true.
  preview_surface_flow_strategy = .true.
  proposal_refine_tag_level = 2
  proposal_axis_min_relative_density = 0.20
  proposal_axis_max_marked_fraction = 0.75
  proposal_preview_split_factor = 2
  proposal_axis_padding_cells = 2
  proposal_max_cell_growth = 2.00
  preview_region_axis = 'y'
  preview_flow_axis = 'y'
  preview_flow_direction = 1.0
  preview_surface_distance = 0.004
  preview_high_region_min = -0.050
  preview_high_region_max = 0.035
  preview_medium_region_min = 0.035
  preview_medium_region_max = 0.100
  preview_coarsen_region_min = 0.100
  preview_coarsen_region_max = 1.0e30
  allow_runtime_redistribution = .false.
/

C=======================================================================
C   IBM CONTROL
C-----------------------------------------------------------------------
C   enabled:
C       true  = enable immersed-boundary geometry and wall treatment.
C       false = skip IBM mesh, IBM hooks, and IBM wall treatment.
C   geometry:
C       Primary geometry path relative to EXEC; Geometry/ is the clean input
C       folder.  The current GTMC case uses a watertight STL as the
C       authoritative fluid-domain surface.
C   solid_model:
C       true keeps CAD/STL interior as the solid model flag.
C       false inverts the legacy flag convention after mesh construction.
C   orthogonality:
C       true  = compute IBM cuts/normals from CAD/STL intersections.
C   read_mesh_cache/write_mesh_cache:
C       Mesh-1 writes per-rank IBM cache files under imbmesh/ from the
C       integrated C++ geometry service before Fortran startup continues.
C       Keep read_mesh_cache=true so the solver uses that single marker owner;
C       keep write_mesh_cache=false so legacy scanning does not overwrite it.
C   fix_holes:
C       Enable the IBM hole-repair pass.
C   spray_mesh:
C       true keeps IBM spray blocking flags; false treats spray space as open.
C   ray_diagnostic_direction:
C       Optional ray diagnostic direction only: 1=x, 2=y, 3=z.
C       It is used only when write_preview_diagnostics or focused normal
C       diagnostics need raw ray data.  It is not used as the authoritative
C       fluid/solid marker algorithm.
C       For the current Geometry/gtmc13.STL route, use the Y-axis diagnostic
C       ray to avoid reviewing Z-line scan artifacts as solver markers.
C   normal_mode:
C       0 = keep only fluid/solid marker initialization.
C       1 = use one-layer marker topology to build wall normals and distance
C           cheaply; this is the default for generated STEP meshes.
C       2 = additionally call the legacy per-point CAD/STL normal scan.
C           This is much slower and should be used only for focused checks.
C   wall_damping:
C       Enable near-wall IBM damping for stability.
C   wall_target_cfl/wall_max_multiplier:
C       Parameters for the damping strength and upper bound.
C=======================================================================
&ibm_control
  enabled = .true.
  geometry = 'Geometry/gtmc13.STL'
  solid_model = .false.
  orthogonality = .true.
  read_mesh_cache = .true.
  write_mesh_cache = .false.
  fix_holes = .false.
  spray_mesh = .false.
  ray_diagnostic_direction = 2
  normal_mode = 1
  wall_damping = .true.
  wall_target_cfl = 0.01
  wall_max_multiplier = 20.0
/

C=======================================================================
C   IBM GEOMETRY SERVICE
C-----------------------------------------------------------------------
C   enabled:
C       true exposes unified IBM geometry queries to solver modules.
C   source:
C       stl means the geometry service is built from the watertight STL
C       triangles directly.  Patch STL hooks are reserved for future GUI
C       boundary binding, but current boundary matching is coordinate based.
C   export_legacy_arrays:
C       true keeps existing legacy IBM arrays valid during migration.
C   interface_marker:
C       Visit/diagnostic marker for IBM interface cells.
C   signed_distance/wall_normal/wall_distance/closest_point:
C       Geometry fields to compute and expose through the service layer.
C=======================================================================
&ibm_geometry_service
  enabled = .true.
  source = 'stl'
  service_owner = 'coast_ibm_geometry'
  export_legacy_arrays = .true.
  interface_marker = 1.5
  signed_distance = .true.
  wall_normal = .true.
  wall_distance = .true.
  closest_point = .true.
/

C=======================================================================
C   MESH GEOMETRY
C-----------------------------------------------------------------------
C   Geometry list and interpretation used by the integrated generator.
C   geometry_format:
C       auto = infer from extension; stl = watertight triangle mesh used as
C              the current authoritative fluid-domain surface; step/sat are
C              optional CAD inputs for future preprocessing but not this run.
C   geometry_units:
C       Unit of coordinates stored in the geometry file.  gtmc_bak.stl is in
C       millimeters, so use 'mm' to convert the generated mesh to SI m.
C   cad_tessellation_deflection:
C       CAD-only controls retained for future STEP preprocessing; they are not
C       used when geometry_format='stl'.
C   cad_tessellation_angle:
C       STEP angular deflection in radians for curved surfaces.
C   sat_file_1:
C       Optional compatibility file for future ACIS/SAT conversion tests.
C       Optional compatibility file retained for future CAD preprocessing.
C   geometry_margin:
C       Optional outward expansion applied to the geometry-derived domain.
C   geometry_inset:
C       Optional inward shrink applied after unit conversion.  Use a small
C       positive value so the generated background grid lies just inside the
C       watertight STL fluid domain and external inlet/outlet faces remain open.
C   geometry_inset_x/y/z:
C       Optional direction-specific inward shrink.  If omitted or negative,
C       that direction falls back to geometry_inset.  Use a larger z inset
C       when inlet/outlet STL lips should protrude beyond the computational
C       low-z/high-z planes without changing the radial x/y domain.
C=======================================================================
&mesh_geometry
  geometry_count = 1
  geometry_file_1 = 'Geometry/gtmc13.STL'
  geometry_format = 'stl'
  geometry_units = 'mm'
  cad_tessellation_deflection = 0.1
  cad_tessellation_angle = 0.35
  sat_file_1 = 'Geometry/jsy_gtmc13.SAT'
  stl_count = 1
  stl_file_1 = 'Geometry/gtmc13.STL'
  stl_units = 'mm'
  normal_policy = 'auto_fix'
  geometry_margin = 0.0
  geometry_inset = 0.0005
  geometry_inset_x = 0.0005
  geometry_inset_y = 0.0005
  geometry_inset_z = 0.0015
/

C=======================================================================
C   MESH DOMAIN
C-----------------------------------------------------------------------
C   auto_from_geometry:
C       true  = derive the generated background-grid bounds directly from the
C               CAD/STL geometry bounding box after unit conversion.
C       false = use the manual fallback bounds below.
C   For this watertight STL fluid domain, the generated domain follows the
C   STL bounding box after unit conversion and the geometry_inset above.
C   Internal physical inlet planes are handled by forced decomposition planes.
C=======================================================================
&mesh_domain
  auto_from_geometry = .true.
  xmin = -0.05050
  xmax =  0.05050
  ymin = -0.05050
  ymax =  0.05050
  zmin = -0.02950
  zmax =  0.29450
/

C=======================================================================
C   MESH RESOLUTION
C-----------------------------------------------------------------------
C   Base spacing, refined spacing, growth control, and optional focus regions.
C   focus_region_N_* entries are generic axis-aligned refinement windows.  A
C   spacing value only affects an axis when it is smaller than the base spacing,
C   so a region can refine x/y while leaving z on the normal STL policy.
C   当前算例重点加密：
C       1) Y < 0.04 m 的近入口/旋流区域保持更密的 y 向分辨率；
C       2) -0.03 < X < 0.03、Y < 0.04、-0.03 < Z < 0.03 的中心柱状近似区域
C          使用 0.35~0.40 mm 级别三向分辨率，以降低初始化和计算耗时。
C=======================================================================
&mesh_resolution
  base_dx = 0.001
  base_dy = 0.001
  base_dz = 0.001
  min_dx = 0.00040
  min_dy = 0.00040
  min_dz = 0.00040
  max_growth_ratio = 1.15
  focus_region_count = 2
  focus_region_1_enabled = .true.
  focus_region_1_xmin = -1.0e30
  focus_region_1_xmax =  1.0e30
  focus_region_1_ymin = -1.0e30
  focus_region_1_ymax =  0.040
  focus_region_1_zmin = -1.0e30
  focus_region_1_zmax =  1.0e30
  focus_region_1_dx = 0.00100
  focus_region_1_dy = 0.00040
  focus_region_1_dz = 0.00100
  focus_region_2_enabled = .true.
  focus_region_2_xmin = -0.030
  focus_region_2_xmax =  0.030
  focus_region_2_ymin = -1.0e30
  focus_region_2_ymax =  0.040
  focus_region_2_zmin = -0.030
  focus_region_2_zmax =  0.030
  focus_region_2_dx = 0.00040
  focus_region_2_dy = 0.00040
  focus_region_2_dz = 0.00040
/

C=======================================================================
C   MESH IBM MARKERS
C-----------------------------------------------------------------------
C   Marker and refinement settings for IBM-aware generated meshes.
C   marker_mode:
C       fluid_volume = CAD/B-rep entity volume is the solver fluid domain.
C                      Cells in the CAD entity are marked 1.0 (fluid); blank
C                      or non-model regions outside the CAD entity are marked
C                      0.0 (solid).  The generator does not thicken the wall
C                      by expanding cut cells to neighboring cells.
C       solid_body   = reserved for imported solid-body obstacles.
C       thin_wall    = old alias.  It is parsed as fluid_volume and should not
C                      be used in new cases.
C   opening_cad_face_*:
C       Reserved for CAD/B-rep runs.  STL main-route cases must keep this
C       disabled; boundary openings are selected by block/external coordinates
C       in boundary_conditions.d.
C   opening_band_cells:
C       Reserved for CAD/B-rep runs.
C=======================================================================
&mesh_ibm
  marker_mode = 'fluid_volume'
  interface_band_cells = 3
  wall_refine_distance = 0.004
  opening_cad_face_count = 0
  opening_cad_face_1 = 0
  opening_band_cells = 0
  solid_marker = 0.0
  fluid_marker = 1.0
  interface_marker = 1.5
/

C=======================================================================
C   MESH DECOMPOSITION
C-----------------------------------------------------------------------
C   MPI block-decomposition controls. target_ranks should match the intended
C   mpirun rank count for generated Decomp output.
C   Direct mesh 候选由 mesh5_auto_refine.d 搜索 rank；目标每块 3~4 万流体网格。
C   本 namelist 的 target_ranks 保持当前 solver 兼容默认值，active 替换由主 agent 验收。
C   forced_x/y/z_plane_*:
C       Optional physical/internal coordinate planes that must coincide with a
C       generated block face.  For the STL GTMC case, y=-0.002 m is kept as a
C       decomposition-aligned plane through the methane-ring region.  The active
C       methane inlet itself is selected in boundary_conditions.d from the IBM
C       wall surface, not from a block-plane radius shortcut.
C=======================================================================
&mesh_decomposition
  target_ranks = 176
  forced_x_plane_count = 0
  forced_x_plane_1 = 0.0
  forced_y_plane_count = 1
  forced_y_plane_1 = -0.002
  forced_z_plane_count = 0
  forced_z_plane_1 = 0.0
  method = 'weighted_blocks'
  block_shape = 'auto'
  weight_solid = 0.25
  weight_fluid = 1.0
  weight_interface = 4.0
  weight_refined = 2.0
/

C=======================================================================
C   MESH-5 AUTO REFINE / DIRECT REGRID CONTROL
C-----------------------------------------------------------------------
C   这些设置替代旧 mesh5_auto_refine.d，统一管理自动加密、直接建网格、
C   分块数量、MPI -np 覆盖和换网格重启动。旧文件只保留兼容。
C=======================================================================
&mesh5_auto_refine
  enabled = .true.
  direct_mesh_generation_enabled = .true.
  on_restart = .true.
  candidate_generation = 'balanced_repartition'
  split_candidate = .false.
  overwrite = .true.
  allow_mpirun_np_override = .true.
  geometry_weight = 0.25
  vorticity_weight = 0.25
  reaction_weight = 0.25
  focus_region_weight = 0.15
  centerline_weight = 0.10
  top_fraction = 0.05
  min_fluid_fraction = 0.02
  use_block_stats = .true.
  block_stats_file = 'monitor/mesh5_block_stats.latest'
  block_stats_require_identity_match = .true.
  field_sample_stride = 4
  focus_region_count = 1
  focus_region_1_enabled = .true.
  focus_region_1_xmin = -0.030
  focus_region_1_xmax =  0.030
  focus_region_1_ymin = -1.0e30
  focus_region_1_ymax =  0.040
  focus_region_1_zmin = -0.030
  focus_region_1_zmax =  0.030
  focus_region_1_dx = 0.000375
  focus_region_1_dy = 0.000375
  focus_region_1_dz = 0.000375
  focus_region_1_weight = 1.0
  centerline_refine_enabled = .true.
  centerline_axis = 'y'
  centerline_x = 0.0
  centerline_z = 0.0
  centerline_ymin = -1.0e30
  centerline_ymax = 0.040
  centerline_radius = 0.004
  refinement_ratio = 2
  refine_block_fraction = 0.05
  target_rank_count = 0
  max_target_rank_count = 0
  target_min_spacing = 0.00050
  direct_target_min_spacing_candidates = '0.00050 0.00045 0.00040'
  direct_rank_candidates = '128 144 160 176 192 224 256'
  target_fluid_cells_per_rank_min = 30000
  target_fluid_cells_per_rank_max = 40000
  direct_total_cell_imbalance_max = 2.00
  direct_max_total_cells_per_rank = 150000
  partition_alignment = 'strict_aligned'
  startup_remap_parallel_workers = 32
  allow_nonmatching_interfaces = .false.
  initialization_speed_policy = 'direct_start_no_restart_remap'
  startup_speed_policy = 'direct_start_no_restart_remap'
  compute_speed_policy = 'prefer_fast_runtime'
  balance_tolerance = 0.20
/
