C-----------------------------------------------------------------------
C   RUN CONTROL - IGNITION DEBUG / Flame A: CH4 1.1e-3 kg/s = 1.10 g/s, outlet -2
C-----------------------------------------------------------------------
false                           /use if number blocks > number of cores
C-----------------------------------------------------------------------
C   INPUT/OUTPUT DIRECTORIES:
C-----------------------------------------------------------------------
/Decomp/
/Restart/
/Restart/
C-------------------------------------------------------------------
C   COMMAND PARAMETERS
C   Restart may be remapped automatically when mpirun -np differs from active mesh.
true                            /form
true true                  /restart, write to restart
true                            /restart_regrid_replace_mesh
10000                            /lstep
500                              /stepsave : write restart file interval
500                              /stepplot : write plot file interval
C-----------------------------------------------------------------------
C   LES CONTROL - LARGE EDDY SIMULATION
C-----------------------------------------------------------------------
vreman                          /dyn_stress_piomelli,dyn_stress_lilly smagorinsky,dyn_energy
false                           /dyn_restart_stress
0.12                            /smagorinsky constant Cs
false false                    /turbstat,turbread
false                           /reserved legacy flag; keep false
C-----------------------------------------------------------------------
C... Some miscellaneous variables
C-----------------------------------------------------------------------
2                               /itnum
10000000                        /integration time
10000000                        /nskip
C-----------------------------------------------------------------------
C... CFL variables
C-----------------------------------------------------------------------
0.2 0.3 0.25                    /cflmin,cflmax,cfl_ok
C-----------------------------------------------------------------------
C... Wall clock execution time in hours
C-----------------------------------------------------------------------
200                             /TEXEC
C-----------------------------------------------------------------------
C   PHYSICS CONTROL - PHYSICAL PROPERTIES
C-----------------------------------------------------------------------
1.18 0.663 1.0E-5 1.0e+05       /rhoair, rhojet, visco, pressure
C-----------------------------------------------------------------------
C   Variable
C-----------------------------------------------------------------------
  50    1.0e-04                 /u-vel 1 icycl(),tol()
  50    1.0e-04                 /v-vel 2 icycl(),tol()
  50    1.0e-04                 /w-vel 3 icycl(),tol()
  500   1.0e-04                 /dp    4 icycl(),tol()
  20    1.0e-03                 /f     5 icycl(),tol()
  20    1.0e-04                 /h     6 icycl(),tol()
C-----------------------------------------------------------------------
C... Combustion variables
C-----------------------------------------------------------------------
methane                         /fuel
arm2                            /reaction mechanism
! fuel/mechanism is loaded here; burn and PDF switches are set below
0  0                            /CO2_content,H2_content - Volume fraction
!
true false vode                 /burn,chemkin format,solver
C-----------------------------------------------------------------------
C... PDF equation variables
C-----------------------------------------------------------------------
true                            /solve for pdf
1                               /number of stochastic fields
true true                  /read_pdf,write_pdf
true                            /stochastic noise reduction
  10    1.0e-04                 /icycl(),tol()
C-----------------------------------------------------------------------
C   Species output: mass fraction or mole fraction
C-----------------------------------------------------------------------
mass_fraction                   /mole_fraction; mass_fraction
C-----------------------------------------------------------------------
C   Global heat release rate
C-----------------------------------------------------------------------
false                           /read global heat release rate: true/false
C-----------------------------------------------------------------------
C   Radiative Heat Transfer
C-----------------------------------------------------------------------
false                           /Include radiate heat transfer: true/false
C-----------------------------------------------------------------------
C   Ignition
C-----------------------------------------------------------------------
false                           /Ignite mixture: true/false
C-----------------------------------------------------------------------
C   Phase Averaging
C-----------------------------------------------------------------------
false false                     /phase averaging; read restart file: true/false
400  0.2872750                  /frequency from PSD; phase averaging start time
C-----------------------------------------------------------------------
C... Compressible flow
C-----------------------------------------------------------------------
true                            /compressible flow
C-----------------------------------------------------------------------
C... Effective boundary
C-----------------------------------------------------------------------
0.28 0.005266                   /Sigma, Characteristic length

C-----------------------------------------------------------------------
C... Micro-mixing model
C... cd_mode: manual, dynamic, local_dynamic
C-----------------------------------------------------------------------
TCR dynamic 2.0                  /micro_mixing_model, cd_mode, cd_value

C=======================================================================
C   OUTPUT CONTROL
C-----------------------------------------------------------------------
C   rank_info:
C       true  = write per-rank Info/info.NNN files for detailed debugging.
C       false = suppress per-rank Info files; recommended for production.
C   parallel_info:
C       true  = write per-rank Info/parallel_init.NNN files.
C       false = suppress parallel-init detail unless debugging MPI layout.
C   log_dir:
C       Directory for lightweight logs created by the runtime wrapper.
C   info_dir:
C       Directory used only when debug_mode enables Info output.
C   screen_file:
C       Main concise screen summary file.
C=======================================================================
&output_control
  rank_info = .false.
  parallel_info = .false.
  log_dir = '.'
  info_dir = 'Info'
  screen_file = 'screen'
/

C=======================================================================
C   TIME CONTROL
C-----------------------------------------------------------------------
C   time_step_cap_enabled:
C       true  = limit dt by time_step_max even if CFL permits a larger step.
C       false = use CFL and solver constraints only.
C   time_step_max:
C       Maximum allowed dt in seconds when the cap is enabled.
C   time_step_growth_limit:
C       Maximum allowed ratio dt_new/dt_old when CFL asks for a larger
C       time step. 1.20 means dt can grow by at most 20% per step.
C       Use a large value only when deliberately allowing abrupt dt jumps.
C=======================================================================
&time_control
  time_step_cap_enabled = .true.
  time_step_max = 9.9e-06
  time_step_growth_limit = 1.20
/

C=======================================================================
C   FLOW CONTROL
C-----------------------------------------------------------------------
C   mach_velocity_limit_enabled:
C       true  = apply high-Mach limiter/protection logic.
C       false = disable this limiter; not recommended for compressible cases.
C   mach_velocity_limit:
C       Upper Mach threshold used by the limiter.
C   high_mach_tvd_threshold:
C       Threshold for switching high-Mach transport protection.
C=======================================================================
&flow_control
  mach_velocity_limit_enabled = .true.
  mach_velocity_limit = 0.95
  high_mach_tvd_threshold = 0.60
/

C=======================================================================
C   DEBUG CONTROL
C-----------------------------------------------------------------------
C   debug_mode:
C       false = production mode. Suppress hook/Info/debug-log output and
C               skip debug-only reporting work where possible.
C       true  = enable selected debug_* channels below.
C   debug_hooks:
C       Enable low-level hook/adapter/ABI debug messages.
C   debug_io:
C       Enable input parsing diagnostics.
C   debug_boundary:
C       Enable boundary patch matching diagnostics.
C   debug_ibm:
C       Enable IBM geometry and wall hook diagnostics.
C   debug_spray:
C       Enable spray module debug files/messages.
C=======================================================================
&debug_control
  debug_mode = .false.
  debug_hooks = .false.
  debug_io = .false.
  debug_boundary = .true.
  debug_ibm = .false.
  debug_spray = .false.
/

C=======================================================================
C   CHEMISTRY ACCELERATION CONTROL - Flame A 闭环
C-----------------------------------------------------------------------
C   active closure 默认使用 chemistry_acceleration cache：
C       最终 Flame A 稳定性验收使用本 cache 路径。off 只作为详细化学
C       对比基准，见 EXEC/chemistry_accel_variants/input.off.append。
C   performance_monitor on:
C       写 EXEC/monitor/chemistry_accel.dat、timing.dat 和 rank balance。
C   cache 安全策略：
C       命中缓存/离线表后，只有物种非负、有限值和质量闭合检查通过才应用；
C       低温低活性区可用零增量快速返回，强反应区回退详细化学。
C   initial guess 安全策略：
C       只把上一次成功详细化学增量作为 VODE warm-start 候选；候选必须通过
C       温差、物种差、非负、有限值和质量闭合检查，失败立即回退原始初值。
C=======================================================================
chemistry_acceleration cache
performance_monitor on
chemistry_cache_size 32768
chemistry_cache_tolerance 40.0
chemistry_cache_species_tolerance 5.0e-5
chemistry_cache_density_tolerance 5.0e-2
chemistry_cache_dt_tolerance 2.0e-9
chemistry_cache_min_temperature 900.0
chemistry_cache_low_activity_bypass true
chemistry_cache_low_activity_temperature 850.0
chemistry_cache_mass_tolerance 5.0e-3
chemistry_cache_negative_tolerance 1.0e-12
chemistry_cache_max_delta 0.20
chemistry_cache_report_frequency 25
chemistry_vode_initial_step_fraction 0.20
chemistry_vode_max_internal_steps 0
chemistry_initial_guess_enabled true
chemistry_initial_guess_mode warm_start
chemistry_initial_guess_vode_step_fraction 0.35
chemistry_initial_guess_temperature_delta_limit 40.0
chemistry_initial_guess_species_delta_limit 5.0e-4
chemistry_initial_guess_mass_tolerance 5.0e-3
chemistry_initial_guess_negative_tolerance 1.0e-12
chemistry_initial_guess_fallback_to_detail_on_reject true
chemistry_initial_guess_report_frequency 25
C chemistry_acceleration table
C chemistry_table_file Chemistry/cache_table.dat
