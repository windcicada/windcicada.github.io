# COAST VisIt/VTK 输出控制文件。
# 常用设置：
# - default true：保留默认字段，适合调试和正式后处理。
# - vtk_diag_level 1：输出常用燃烧/流动/IBM 诊断；数值越大文件越大。
# - write_flow_diag：控制涡量、Q 准则、应变率等流场结构字段。
# - write_front_structure：控制燃烧前缘和燃烧模式字段。
# - write_tcr_diag / write_iem_diag：控制 TCR、PDF 和微混合诊断字段。
#
# 每行格式：
#   字段名 true/false
# true 表示输出该字段，false 表示关闭该字段。字段名必须和 VTK 文件中的
# SCALARS 或 VECTORS 名称完全一致。
#
# default true:
#   未在本文件列出的字段沿用程序默认行为输出。推荐保持 true，因为组分
#   质量分数/摩尔分数等字段会随化学机理变化，无法在这里预先列全。
# default false:
#   只输出本文件显式写成 true 的字段。用于最小化输出文件体积。
default true
#
# 诊断级别：
#   0 = 只输出主程序原有基础量。
#   1 = 增加燃烧进度、前缘结构、流场结构、IBM 标记等常用诊断。
#   2 = 增加 TCR/PDF/微混合诊断。
#   3 = 增加逐组分调试诊断，文件会明显变大。
vtk_diag_level 1
#
# 诊断模块总开关：
#   write_tcr_diag          控制 TCR kappa/Da/eta 和 TCR PDF 方差输出。
#   write_iem_diag          控制 IEM PDF 方差和 Micro_mixing_CD 输出。
#   write_front_structure   控制火焰前缘/燃烧模式输出。
#   write_flow_diag         控制涡量、Q 准则、应变率等流场结构输出。
write_tcr_diag true
write_iem_diag true
write_front_structure true
write_flow_diag true

# 01_ 流动速度和运动学量。
# 01_Velocity 是三分量矢量；01_Velocity_U/V/W 是便于单独查看的标量分量。
# 速度大小不再单独输出，建议在 VisIt 中用表达式从 01_Velocity 计算。
01_Velocity true
01_Velocity_U true
01_Velocity_V true
01_Velocity_W true
01_Mach_number true
01_Vorticity_x true
01_Vorticity_y true
01_Vorticity_z true
01_Vorticity_magnitude true
01_Q_criterion true
01_Strain_rate_magnitude true

# 02_ 热力学、压力和能量量。
# 02_Static_pressure 是求解器静压 p。
# 02_Total_pressure 是由静压、密度、速度和可压缩关系估算的总压。
# 02_Pressure_mean 是多时间步统计平均静压；不是瞬时压力。
02_Density true
02_Density_mean true
02_Static_pressure true
02_Total_pressure true
02_Pressure_mean true
02_Temperature true
02_Temperature_mean true
02_Temperature_rms true
02_Enthalpy true
02_Enthalpy_mean true
02_Radiative_heat_transfer true
02_Radiation_mean true

# 03_ 组分和混合分数。
# 03_Y_<species> 是组分质量分数，03_X_<species> 是组分摩尔分数。
# <species> 来自化学机理文件；例如 03_Y_O2、03_X_CH4。
# 03_Mixture_fraction 是输出时由当前组分场计算的瞬时混合分数。
# 03_Mixture_fraction_mean 是 statistics.F90 中随时间统计的混合分数平均值。
03_Mixture_fraction true
03_Mixture_fraction_mean true
03_Mole_number true

# 04_ 燃烧进度、热释放和火焰结构。
# 04_Progress_variable 是当前 LES 网格平均瞬态进度变量。
# 04_Progress_variable_c_dot 是进度变量源项。
# 04_Combustion_mode_flag 用于区分局部燃烧模式。
# 04_Front_structure_mode 用于展示火焰前缘结构分类。
04_Progress_variable true
04_Progress_variable_c_dot true
04_Heat_release_rate true
04_Heat_release_rate_mean true
04_u_prime_over_S_L true
04_l_t_over_delta true
04_Karlovitz_number true
04_Combustion_mode_flag true
04_Front_structure_mode true

# 05_ 湍流、统计量和扩散量。
# 05_U/V/W_mean 是速度时间平均。
# 05_U/V/W_rms 是速度脉动均方根，替代旧版本的 Var_U/VAR_V/Var_W 中间量。
05_U_mean true
05_V_mean true
05_W_mean true
05_U_rms true
05_V_rms true
05_W_rms true
05_SGS_kinetic_energy true
05_Dissipation_rate true
05_Diffusivity true
05_Diffusivity_sgs true

# 06_ TCR、PDF、微混合和反应调试诊断。
# 06_TCR_kappa/Da/eta 来自 TCR 模型。
# 06_Micro_mixing_CD 是唯一物理微混合 C_D；旧 IEM_CD/TCR_CD 不再重复输出。
# 06_PDF_var_* 分别表示微混合前、TCR 后、IEM 后的 PDF 方差及差值。
06_TCR_kappa true
06_TCR_Da true
06_TCR_eta true
06_Micro_mixing_CD true
06_PDF_var_before_mix true
06_PDF_var_after_TCR true
06_PDF_var_after_IEM true
06_PDF_var_diff_TCR_minus_IEM true
06_RRmix_Oxygen true
06_RRmix_Radical true

# 07_ IBM 几何标记。
# 07_IBM_cell_type：二值 IBM 标记；0.0 表示固体，1.0 表示流体。
# 内部 interface band 只用于求解器诊断，Visit 输出中不再使用 1.5。
07_IBM_cell_type true

# 08_ 喷雾诊断。
08_Spray_SMD true
08_Spray_Temperature true
08_Spray_number_density true

# 09_ 坐标和调试辅助量。默认保留，排查 formation_rates 时有用。
09_coord_R true
09_coord_X true
