
kerosene
ELEMENTS
 O   H   C   N
END
SPECIES
H2          H2O         CO          CO2         O2          N2          C12H23
END
REACTIONS
END
