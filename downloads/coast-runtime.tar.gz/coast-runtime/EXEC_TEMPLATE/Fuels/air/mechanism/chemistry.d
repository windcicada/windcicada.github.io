Air
ELEMENTS
c h n o 
END

SPECIES
O2          N2          
END         			
REACTIONS
END
