! Connaire, M. O., Curran, H J., Simmie, J. M., Pitz, W. J. and Westbrook, C.K., 
! "A Comprehensive Modeling Study of Hydrogen Oxidation", 
! International Journal of Chemical Kinetics, 36:603-622, 2004: UCRL-JC-152569.
! UCRL-WEB-208393
! Review and release date: December 3, 2004.
! 11/19/04 version 1b: WJP: eliminated efficiences for co, co and hydrocarbon
! species.   These caused errors from the Chemkin interpretor.
! 4/16/04 version 1a
!
ELEMENTS
H C O N AR
END
SPECIES
H           H2          O             O2          OH              
H2O         N2          HO2           H2O2        AR              
END
REACTIONS                            cal/mole
   H+O2 = O+OH    1.915E+14   0.00  1.644E+04
             rev /  5.481E+11   0.39 -2.930E+02 /
   O+H2 = H+OH    5.080E+04   2.67  6.292E+03
             rev /  2.667E+04   2.65  4.880E+03 /
   OH+H2 = H+H2O   2.160E+08   1.51  3.430E+03
             rev /  2.298E+09   1.40  1.832E+04 /
   O+H2O = OH+OH   2.970E+06   2.02  1.340E+04
             rev /  1.465E+05   2.11 -2.904E+03 /
   H2+M = H+H+M      4.577E+19  -1.40  1.044E+05
             rev /  1.146E+20  -1.68  8.200E+02 /
   H2/2.5/ H2O/12.0/
   O2+M = O+O+M      4.515E+17  -0.64  1.189E+05
             rev /  6.165E+15  -0.50  0.000E+00 /
   H2/2.5/ H2O/12.0/ AR/0.83/
   OH+M = O+H+M      9.880E+17  -0.74  1.021E+05
             rev /  4.714E+18  -1.00  0.000E+00 /
   H2/2.5/ H2O/12.0/ AR/0.75/
   H2O+M = H+OH+M      1.912E+23  -1.83  1.185E+05
             rev /  4.500E+22  -2.00  0.000E+00 /
   H2/0.73/ H2O/12.0/ AR/0.38/
   H+O2(+M) = HO2(+M) 1.475E+12 0.60 0.000E+00
!            rev / 3.090E+12 0.53 4.887E+04 /
           low / 3.4820E+16 -4.1100E-01 -1.1150E+03 /
   troe/0.5  1.0000E-30  1.0000E+30  1.0000E+100 /
   H2/1.3/ H2O/14.0/ AR/0.67/
   HO2+H = H2+O2   1.660E+13   0.00  8.230E+02
             rev /  3.164E+12   0.35  5.551E+04 /
   HO2+H = OH+OH   7.079E+13   0.00  2.950E+02
             rev /  2.027E+10   0.72  3.684E+04 /
   HO2+O = OH+O2   3.250E+13   0.00  0.000E+00
             rev /  3.252E+12   0.33  5.328E+04 /
   HO2+OH = H2O+O2   2.890E+13   0.00 -4.970E+02
             rev /  5.861E+13   0.24  6.908E+04 /
   H2O2+O2 = HO2+HO2      4.634E+16  -0.35  5.067E+04
             rev /  4.200E+14   0.00  1.198E+04 /
   DUPLICATE
   H2O2+O2 = HO2+HO2      1.434E+13  -0.35  3.706E+04
             rev /  1.300E+11   0.00 -1.629E+03 /
   DUPLICATE
   H2O2(+M) = OH+OH(+M) 2.951E+14   0.00  4.843E+04
!          rev / 3.656E+08   1.14 -2.584E+03 /
           low / 1.202E+17  0.00 45500. /
       troe /0.5 1.0e-30 1.0e+30 1.0e+100/
       H2/2.5/ H2O/12.0/ AR/0.64/
   H2O2+H = H2O+OH   2.410E+13   0.00  3.970E+03
             rev /  1.269E+08   1.31  7.141E+04 /
   H2O2+H = H2+HO2   6.025E+13   0.00  7.950E+03
             rev /  1.041E+11   0.70  2.395E+04 /
   H2O2+O = OH+HO2   9.550E+06   2.00  3.970E+03
             rev /  8.660E+03   2.68  1.856E+04 /
   H2O2+OH = H2O+HO2      1.000E+12   0.00  0.000E+00
             rev /  1.838E+10   0.59  3.089E+04 /
   DUPLICATE
   H2O2+OH = H2O+HO2      5.800E+14   0.00  9.557E+03
             rev /  1.066E+13   0.59  4.045E+04 /
   DUPLICATE
END
