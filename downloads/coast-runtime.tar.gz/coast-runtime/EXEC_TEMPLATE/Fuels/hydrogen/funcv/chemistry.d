!*********************************************************************** 
hydrogen
ELEMENTS
 O   H   N  
END
SPECIES
H2          H           O2          OH          H2O         HO2         H2O2        
O           N2
END
REACTIONS
END


