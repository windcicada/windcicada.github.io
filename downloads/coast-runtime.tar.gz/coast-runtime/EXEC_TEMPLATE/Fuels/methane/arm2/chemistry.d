!***********************************************************************
!
!  15-Step Reduced Chemistry Based on GRI3.0 Detailed CH4 Mechanism.
! 
!  C.J. Sung, C.K. Law, and J.-Y. Chen,"Augmented Reduced 
!  Mechanisms for NO Emission in Methane Oxidation", Combustion
!  & Flame 125:906-919 (2001).
! 
!*********************************************************************** 
! ----------------------------------------------------------------------
methane
ELEMENTS
 O   H   C   N  
END
SPECIES
H2          H           O2          OH          H2O         HO2         H2O2        
CH3         CH4         CO          CO2         CH2O        C2H2        C2H4        
C2H6        NH3         NO          HCN         N2                                                                          
END
REACTIONS
END


