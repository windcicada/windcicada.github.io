! A 28-species reduced mechanism for ethanol/air with NO formation
!
! References:
!    Zhang H., Hawkes E.R., Kook S., Luo Z., Lu T.F., 
!    "Computational investigations of the effects of thermal stratification in an ethanol-fuelled HCCI engine," 
!    Fuel, submitted.
!
!    Bhagatwala A., Chen J.H., Lu T.F., 
!    �Direct numerical simulations of HCCI/SACI with ethanol,� 
!    Combust. Flame, 161 (7) 1826-1841, 2014.
!
ethanol
ELEMENTS
c h n o 
END

SPECIES
H           H2          O           O2   
OH          H2O         HO2         H2O2    
CO          CO2         CH2O        HO2CHO
O2CHO       CH3O2H      CH3O2       CH4
CH3         C2H5        C2H4        C2H3    
CH3CHO      C2H5OH      O2C2H4OH    N
NO          NO2         N2O         N2
END         			
REACTIONS
END
