ELEMENTS
H O N 
END
SPECIES
H2      NH3     NO      N2O     O2      H       O       OH      HO2
H2O     H2O2    NO2     HNO     N       NNH     NH2     NH      H2NO
N2
END
REACTIONS          
!
!**************H2 CHEMistry***************
H+O2<=>OH+O                              3.520e+16   -0.700  17069.79
H2+O<=>OH+H                              5.060e+04    2.670   6290.63
H2+OH<=>H2O+H                            1.170e+09    1.300   3635.28
H2O+O<=>2 OH                             7.000e+05    2.330  14548.28
2 H+M<=>H2+M                             1.300e+18   -1.000      0.00
H2/2.50/ H2O/12.00/
H+OH+M<=>H2O+M                           4.000e+22   -2.000      0.00
H2/2.50/ H2O/12.00/ 
2 O+M<=>O2+M                             6.170e+15   -0.500      0.00
H2/2.50/ H2O/12.00/
H+O+M<=>OH+M                             4.710e+18   -1.000      0.00
H2/2.50/ H2O/12.00/
H+O2(+M)<=>HO2(+M)                       4.650e+12    0.440      0.00
H2/2.50/ H2O/16.00/
     LOW  /  5.750e+19   -1.400      0.00   /
     TROE /  0.5          1e-30      1e+30  /
HO2+H<=>2 OH                             7.080e+13    0.000    294.93
HO2+H<=>H2+O2                            1.660e+13    0.000    822.90
HO2+H<=>H2O+O                            3.100e+13    0.000   1720.84
HO2+O<=>OH+O2                            2.000e+13    0.000      0.00
HO2+OH<=>H2O+O2                          7.000e+12    0.000  -1094.65
DUPLICATE
HO2+OH<=>H2O+O2                          4.500e+14    0.000  10929.73
DUPLICATE                           
2 OH(+M)<=>H2O2(+M)                      9.550e+13   -0.270      0.00
H2/2.50/ H2O/6.00/ H2O2/6.00/
     LOW  /  2.760e+25   -3.200      0.00   /
     TROE /  0.57         1e+30      1e-30  /
2 HO2<=>H2O2+O2                          1.030e+14    0.000  11042.07              
DUPLICATE
2 HO2<=>H2O2+O2                          1.940e+11    0.000  -1408.94 
DUPLICATE  
H2O2+H<=>HO2+H2                          2.300e+13    0.000   7950.05
H2O2+H<=>H2O+OH                          1.000e+13    0.000   3585.09
H2O2+OH<=>H2O+HO2                        1.740e+12    0.000   1434.03
DUPLICATE
H2O2+OH<=>H2O+HO2                        7.590e+13    0.000   7272.94
DUPLICATE
H2O2+O<=>HO2+OH                          9.630e+06    2.000   3991.40
!
!******************N**************************************************
H2NO+HO2=HNO+H2O2                    2.9E4   2.69  -1600
H2NO+O=HNO+OH                        3.0E07  2.0   2000 ! GLA/MIL98 JAM est
H2NO+O2=HNO+HO2                      3.0E12  0.0  25000 ! MIL/GLA99 JAM est
NH3+M=NH2+H+M                        2.2E16   0   93451.24 ! GLA/MIL98 DAV/HAN90
NH3+H=NH2+H2                         6.4E05  2.39 10181.64 ! GLA/MIL98 MIC/SUT86
NH3+O=NH2+OH                         9.4E06  1.94  6465.11 ! GLA/MIL98 SUT/KLE90
NH3+OH=NH2+H2O                       2.04E06 2.04   566.44 ! GLA/MIL98 SAL/HAN84
NH2+H=NH+H2                          4.0E13   0    3652.01 ! GLA/MIL98 DAV/HAN90
NH2+N =N2+H+H                        7.0E13   0       0 ! GLA/MIL98 WHY/PHI83
NH2+O=HNO+H                          6.6E14 -0.5      0 ! GLA/MIL98 DRA/WAG84,JAM est
NH2+OH=NH+H2O                        4.0E06  2.0   1001.43 ! GLA/MIL98 JAM est
NH2+NO=N2+H2O                        2.8E20 -2.654   1258 ! MIL/GLA99 MIL/GLA99
NH2+NO=NNH+OH			     3.10E13  -0.48  1180
NH2+O2=H2NO+O                        2.5E11  0.48 29586 ! DB  96 UPDATE 
NH+H=N+H2                            1E14   0       0 ! 
NH+O=NO+H                            9.2E13   0       0 ! GLA/MIL98 CEC94
NH+OH=HNO+H                          4.0E13   0       0 ! GLA/MIL98 JAM est
NH+OH=N+H2O                          5.0E11  0.5   2000.48 ! GLA/MIL98 JAM est 
NH+O2=HNO+O                          4.6E05  2.0   6500.96 ! GLA/MIL98 MIL/MEL92
NH+NO=N2O+H                          1.8E14 -0.351 -244 ! pw 1.3.12 Klip
NH+NO=N2+OH                          2.2E13 -0.23     0 ! GLA/MIL98 MIL/MEL92
NNH(+M)=N2+H(+M)                     6.5E07  0.0      0 ! MIL/GLA99 MIL/GLA99
     LOW  /  5.0E13       0.000      0.00   /
NNH+H=N2+H2                          1.0E14   0       0 ! GLA/MIL98 JAM est
NNH+O=N2O+H                          1.0E14   0       0 ! GLA/MIL98 JAM est
NNH+OH=N2+H2O                        5.0E13   0       0 ! GLA/MIL98 JAM est
NNH+O2=N2+HO2                        2.0E14   0       0 ! GLA/MIL98 MIL/GLA96
!*************************NO2 reactiONs***********************
!! NOX CHeMiStry frOM SivaraMakriSHNaN et al. PHyS. CHeM. CHeM. PHyS., 2007, 9, 42304244
N2+O = N+NO                          1.470e+13   0.3    75286.81   !(92MiC/liM   )
NO+HO2 = NO2+OH                      2.100e+12   0.00    -480.4   !(glarbOrg94  )
H+NO(+M)<=>HNO(+M)                       1.500e+15   -0.400	 0.00
     LOW  /  2.300e+14    0.206     -1554.97 /
O2/1.50/ H2/2.00/ H2O/10.00/
NO2+H = NO+OH                        3.5e+14     0.00     1500.96   ! kO/fONtijN
!NO2+O = NO+O2                       1.000e+13   0.00     600.0   !(glarbOrg94  ) original value
NO2+O=NO+O2                          1.00E+13    0.00     599.9 !           Konnov
NO2+M = NO+O+M                       1.100e+16   0.00   65965.58   !(Mb89        )
H2O/16.25/ 
HNO+OH = NO+H2O                      3.600e+13   0.00       0.0   !(Mb89        )
HNO+H = NO+H2                        4.400e+11   0.72     650.1   !(glarbOrg94  )
N+O2 = NO+O                          6.400e+09   1.00    6285.85   !(Mb89        )
N+OH = NO+H                          3.800e+13   0.00       0.0   !(glarbOrg94  )
N2O+OH = N2+HO2                      2.000E+13   0.00   40000.0
N2O(+M)<=>N2+O(+M)                       8.000e+11    0.000  62619.50
     LOW  /  2.000e+14    0.000      56644.36 / 
N2O+O=NO+NO                          9.15E+13   0.00      27693       ! 61       MeagHer J. PHys. cHem. a, 2000, 104(25), p 6003.
N2O+H=N2+OH                          3.31E+10   0.00       5090       ! 64       BaulcH
DUPLICATE
N2O+H=N2+OH                          7.83E+14   0.00      19390       ! 65       BaulcH
DUPLICATE
! ENd NOx CHeMiStry*****************************************************
END

