!Combustion chemistry of ammonia/hydrogen mixtures: Jet-stirred reactor measurements and comprehensive kinetic modeling
!Xiaoyuan Zhang, Shamjad P. Moosakutty, Rajitha P. Rajan, Mourad Younes, S. Mani Sarathy
!Contanct: xiaoyuan.zhang@kaust.edu.sa

ELEMENTS
O H N C AR HE
END

SPECIES

AR      N2      H       H2      HE      AR
O       OH      H2O     HO2     H2O2    O2    OH*                                
N       NH      NH2     NH3     NNH     N2H2
N2H3    N2H4    H2NN    NO      N2O     NO2
HNO     HON     HONO    H2NO    HNOH    NH2OH
HNO2    HONO2   NO3     HNO3
CO      CO2     CH4     C2H6
END


REACTIONS


!************************ H2/CO mechanism**************************************

!======================                                                                                                                                                      
!H2-O2 Chain Reactions                                                                                                                                                       
!======================                                                                                                                                                      
                                                                                                                                                                             
! Hong et al., Proc. Comb. Inst. 33:309-316 (2011)                                                                                                                           
H+O2=O+OH                            1.0E14   0.000   15286                                                                                                    
                                                                                                                                                                             
! Baulch et al., J. Phys. Chem. Ref. Data, 21:411 (1992)                                                                                                                     
O+H2=OH+H                            3.8E12   0.000    7948
 DUPLICATE                                                  
O+H2=OH+H                            8.8E14   0.000   19175  
 DUPLICATE                                                                                                                                                               
                                                                                                                                                                             
! Michael and Sutherland, J. Phys. Chem. 92:3853 (1988)                                                                                                                      
OH+H2=H+H2O                          2.2E08   1.510    3430                                                                                                                           
                                                                                                                                                                                                                                                                                                                                                         
! M. Sangwan, L. N. Krasnoperov, The Journal of Physical Chemistry A 116 (2012) 11817?1822.                                                                                  
OH+OH=O+H2O                          2.0E07   1.651     631 !   
 DUPLICATE
OH+OH=O+H2O                          2.6E11  -0.057    -827 ! 
 DUPLICATE
! HH: Refitted (400-3000 K) for better stability of the solvers (avoiding negative 'A') 16-04-08                                                                                                                                                               
                                                                                                                                                                             
!============================                                                                                                                                                
!H2-O2 Dissociation Reactions                                                                                                                                                
!============================                                                                                                                                                
                                                                                                                                                                             
! Tsang and Hampson, J. Phys. Chem. Ref. Data, 15:1087 (1986)                                                                                                                
H2+M=H+H+M                           4.6E19  -1.400  104380                                                                                                                          
   H2/2.5/ H2O/12/                                                                                                                                                           
   CO/1.9/ CO2/3.8/                                                                                                                                                          
   AR/0.0/ HE/0.0/                                                                                                                                                           
                                                                                                                                                                             
! Tsang and Hampson, J. Phys. Chem. Ref. Data, 15:1087 (1986)                                                                                                                
H2+AR = H+H+AR                              	5.8E18  -1.100  104380                                                                                                    
H2+HE = H+H+HE                              	5.8E18  -1.100  104380                                                                                                    
                                                                                                                                                                             
! Tsang and Hampson, J. Phys. Chem. Ref. Data, 15:1087 (1986)                                                                                                                
!O+O+M = O2+M                                	6.165E+15 -0.50  0.000E+00 
O+O+M=O2+M                           1.9E13   0.000   -1788                                                                                                    
   H2/2.5/ H2O/12/                                                                                                                                                           
   AR/0.0/ HE/0.0/                                                                                                                                                           
   CO/1.9/ CO2/3.8/                                                                                                                                                          
                                                                                                                                                                             
! Tsang and Hampson, J. Phys. Chem. Ref. Data, 15:1087 (1986)                                                                                                                
O+O+AR = O2+AR                              	1.886E+13  0.00 -1.788E+03                                                                                                     
O+O+HE = O2+HE                              	1.886E+13  0.00 -1.788E+03                                                                                                     
                                                                                                                                                                             
! Tsang and Hampson, J. Phys. Chem. Ref. Data, 15:1087 (1986)                                                                                                                
H+O+M=OH+M                           4.7E18  -1.000       0                                                                                                     
   H2/2.5/  H2O/12/                                                                                                                                                          
   AR/0.75/ HE/0.75/                                                                                                                                                         
   CO/1.9/  CO2/3.8/                                                                                                                                                         
                                                                                                                                                                           
! Srinivasan and Michael, Int. J. Chem. Kinetic. 38 (2006)                                                                                                                   
! Rate constant is for Ar with efficiencies from Michael et al., J. Phys. Chem. A, 106 (2002)                                                                                
H2O+M = H+OH+M                       6.1E27  -3.322  120790                                                                                                    
   H2/3.0/  H2O/0.0/                                                                                                                                                         
   HE/1.10/ N2/2.00/                                                                                                                                                         
   O2/1.5/                                                                                                                                                                   
! Efficiencies for CO and CO2 taken from Li et al., Int. J. Chem. Kinet. 36:566-575 (2004)                                                                                   
   CO/1.9/ CO2/3.8/                                                                                                                                                          
                                                                                                                                                                             
! Srinivasan and Michael, Int. J. Chem. Kinetic. 38 (2006)                                                                                                                   
H2O+H2O = H+OH+H2O                   1.0E26  -2.440  120180                                                                                                    
                                                                                                                                                                             
!=================================                                                                                                                                           
! Formation and consumption of HO2                                                                                                                                           
!=================================                                                                                                                                           
                                                                                                                                                                             
! High-pressure limit from Troe, Proc. Comb. Inst. 28:1463-1469 (2000)                                                                                                       
! Low-pressure  limit from Michael et al., J. Phys. Chem. A 106:5297-5313                                                                                                    
! Centering factors from Fernandes et al., Phys. Chem. Chem. Phys. 10:4313-4321 (2008)                                                                                       
!=================================================================================                                                                                           
! MAIN BATH GAS IS N2 (comment this reaction otherwise)                                                                                                                      
                                                                                                                                                                            
H+O2(+M)=HO2(+M)                     4.7E12   0.440       0 !
 LOW/6.366E20 -1.72  5.248E02/
 TROE/0.5  1E-30  1E30/                                                                                                                                                 
   H2/2.0/ H2O/14/ O2/0.78/ CO/1.9/ CO2/3.8/ AR/0.67/ HE/0.8/              

!=================================================================================
! MAIN BATH GAS IS AR OR HE (comment this reaction otherwise)
!H+O2(+M)=HO2(+M)                     4.7E12   0.440       0 !
! LOW/9.042E19 -1.50  4.922E02/
! TROE/0.5 1E-30  1E30/
!   H2/3.0/ H2O/21/ O2/1.1/ CO/2.7/ CO2/5.4/ HE/1.2/ N2/1.5/ 

!=================================================================================                                                                                           
                                                                                                                                                                             
! Michael et al., Proc. Comb. Inst. 28:1471 (2000)                                                                                                                           
!HO2+H = H2+O2                                 	3.659E+06  2.09 -1.451E+03                                                                                                   
!Scaled by 0.75                                                                                                  
HO2+H=H2+O2                          2.8E06   2.090   -1451                                                                                                                                                                             
! Mueller et al., Int. J. Chem. Kinetic. 31:113 (1999)                                                                                                                       
HO2+H=OH+OH                          7.1E13   0.000     295
HO2+H=H2O+O                          1.4E12   0.000       0 ! 
! Baulch DL Bowman CT Cobos CJ Cox RA Just Th Kerr JA Pilling MJ Stocker D Troe J Tsang W Walker RW Warnatz J JPCRD 34:757-1397 2005                                                                                                                                                                             

! Fernandez-Ramos and Varandas, J. Phys. Chem. A 106:4077-4083 (2002)                                                                                                        
!HO2+O = O2+OH                               	4.750E+10  1.00 -7.2393E+02                                                                                                    
!Scaled by 0.60                                                                                                                                                              
HO2+O=O2+OH                          2.9E10   1.000    -724                                                                                                    
                                                                                                                                                                             
! M. P. Burke, S. J. Klippenstein, L. B. Harding, Proceedings of the Combustion Institute 34 (2013) 547?55.                                                                  
HO2+OH = H2O+O2 				                1.9E20  -2.490     584                                                                                                                           
    DUPLICATE                                                                                                                                                                
HO2+OH = H2O+O2 			                    1.2E09   1.240   -1310                                                                                                                     
    DUPLICATE                                                                                                                                                                
               
!M. Burke, S. Klippenstein, Nature Chemistry, 9, 1078 C1082 (2017)
H+O2+H = OH+OH                                  4.00E+22   -1.835  800
H+O2+O = OH+O2                                  7.35E+22   -1.835  800
H+O2+OH = H2O+O2                                2.56E+22   -1.835  800  
HO2+HO2 = H2O2+O2                           	1.2E09   0.7712  -1825                                                                                                       
   DUPLICATE                                                                                                                                                                 
HO2+HO2 = H2O2+O2        			1.3E12   0.295    7397                   	                                                                                                   
   DUPLICATE                                                                                                                                                                 
                                                                                                                                                                             
! Troe, Combust. Flame,  158:594-601 (2011)                                                                                                                                  
! Rate constant is for Ar                                                                                                                                                    
H2O2(+M) = OH+OH(+M)            			2.0E12   0.900   48749                                                                                                            
   LOW/2.5E24  -2.300   48749/                                                                                                                                            
   TROE/0.43 1E-30 1E30/                                                                                                                                                    
   H2O/7.5/ CO2/1.6/                                                                                                                                                         
   N2/1.5/  O2/1.2/                                                                                                                                                          
   HE/0.65/ H2O2/7.7/                                                                                                                                                        
! Efficiencies for H2 and CO taken from Li et al., Int. J. Chem. Kinet. 36:566-575 (2004)                                                                                    
   H2/3.7/ CO/2.8/                                                                                                                                                           
                                                                                                                                                                             
! Tsang and Hampson, J. Phys. Chem. Ref. Data, 15:1087 (1986)                                                                                                                
H2O2+H = H2O+OH                             	2.4E13   0.000    3970                                                                                                     
H2O2+H = HO2+H2                             	4.8E13   0.000    7950                                                                                                     
H2O2+O = OH+HO2                             	9.6E06   2.000    3970                                                                                                     
                                                                                                                                                                             
! Hong et al., J. Phys. Chem. A  114 (2010) 5718?727                                                                                                                         
H2O2+OH = HO2+H2O                           	1.7E12   0.000     318                                                                                                     
   DUPLICATE                                                                                                                                                                 
H2O2+OH = HO2+H2O                           	7.6E13   0.000    7270                                                                                                     
   DUPLICATE                                                                                                                                                                 


!!***********************************THE REACTIONS OF NH3***********************************
!-----------------------N/N2 REACTIONS-----------------------------------------
!------------------------------------------------------------------------------
 N2+M=N+N+M                                      1.890E+18   -0.85   2.250E+05 ! Lamoureux 2016
 H2O/16.25/ CO/1.875/ CO2/3.75/ CH4/16.25/ C2H6/16.25/                         !
 N+O+M=NO+M                                      7.600E+14   -0.10  -1.770E+03 ! Lamoureux 2016
 H2O/16.25/ CO/1.875/ CO2/3.75/ CH4/16.25/ C2H6/16.25/                         !
 N+NO2=N2O+O                                     1.800E+12   0.00    0.000E+00 ! Lamoureux 2016
 N+O2=NO+O                                       5.841E+09   1.01    6.202E+03 ! Baulch 2005 A/6.400E+09 error (+/-0.2-0.5) 280-1500 K also used by Lamoureux 2016/Vandooren 1994 
 N+OH=NO+H                                       1.084E+14  -0.20    0.000E+00 ! Baulch 2005 A/1.084E+14 error (+/-0.1-0.4) 100-2500 K
 N+NO=N2+O                                       3.200E+13   0.00    0.000E+00 ! Baulch 2005 A/2.100E+13 error (+/-0.3) 210-3700 K also used by Tian 2009/KLIMIC2011
!------------------------------------------------------------------------------
!---------------NH REACTIONS---------------------------------------------------!
!------------------------------------------------------------------------------
!C.-X. Yao, P.-Y. Zhang, Z.-X. Duan, G.-J. Zhao, Theoretical Chemistry Accounts 133 (2014) 1489.  
 NH+H=N+H2                                       1.650E+11	 0.71	 9.31E+02
!R. Guadagnini, G.C. Schatz, S.P. Walch, J. Chem. Phys. 102 (1995) 784-791. 
 NH+O=NO+H                                       4.820E+13	 0.023	 9.50E+01
 NH+O=N+OH                                       2.070E+10	 0.622	-3.58E+02
!
!S.J. Klippenstein, et al., JPCA 113 (2009) 10241-10259.
 NH+OH=HNO+H                                     3.25E+14  -0.376     -46
 NH+OH=N+H2O                                     1.59E+07   1.733     -576
!
!O. Elishav, Progress and Prospective of Nitrogen-Based Alternative Fuels, Chemical Reviews 120 (2020) 5352-5436.
 NH+O2=HNO+O                                     3.32E+09	1.034	1.142E+04
!H.J. R  mming, Proc. Combust. Inst. 26 (1996) 559-566. 
 NH+O2=NO+OH                                     4.50E+08	0.79	1.195E+03

!Klippenstein et al J Phys Chem A 113 10241-10259 (2009)
 NH+NH=>N2+H2				                     6.260E+12   -0.036   -160.9   !High-Pressure rate, dissociation of N2H2 (10%)
 NH+NH=>N2+H+H				                     5.634E+13   -0.036   -160.9   !High-Pressure rate, dissociation of N2H2 (90%)
! 
 NH+N=N2+H                                       3.000E+13   0.00    0.000E+00 ! KLIMIC2011 cited Skreiberg 2004
!Baulch DL Bowman CT Cobos CJ Cox RA Just Th Kerr JA Pilling MJ Stocker D Troe J Tsang W Walker RW Warnatz J JPCRD 34:757-1397 2005 
 NH+NO=N2O+H                                     2.70E+15  -0.780      20
 NH+NO=N2+OH                                     6.80E+14  -0.780      20
!Harrison JA Whyte AR Phillips LF CPL 129:346 1986
 NH+NO2=N2O+OH                                   4.100E+12   0.00    0.000E+00
 NH+NO2=HNO+NO                                   5.900E+12   0.00    0.000E+00
! 
 NH+HONO=NH2+NO2                                 1.000E+13   0.00    0.000E+00 ! KLIMIC2011
 NH+N2O=N2+HNO                                   2.000E+12   0.00    6.000E+03 ! Duynslaegher 2012
!------------------------------------------------------------------------------
!----------------------NH2 REACTIONS-------------------------------------------
!------------------------------------------------------------------------------
!J. Deppe, Berichte der Bunsengesellschaft f  r physikalische Chemie 102 (1998) 1474-1485.
 NH2+M=NH+H+M                                     1.2E+15     0.00   76002.75
 
!Y. Li, S.M. Sarathy, Int. J. Hydrogen Energy 45 (2020) 23624-23637.
 NH2+H=NH+H2                                      1.09E+05    2.59     1812.3264
 
!S. Inomata, N. Washida, J. Phys. Chem. A 103 (1999) 5023-5031.
 NH2+O=NH+OH              7.23E+12	0	0.00E+00
 
!Sumathi, R., et al. J Phys Chem A, 102(18), 3175-3183. (1998)
NH2+O=HNO+H				 .1500E+16   -.547    836.7
 DUPLICATE
NH2+O=HNO+H				 .7730E+14   -.277    646.4
 DUPLICATE 

!Y. Li, S.M. Sarathy, Int. J. Hydrogen Energy 45 (2020) 23624-23637.
 NH2+OH=NH+H2O                                    4.04E+04    2.52      -616.032
!Y. Song, H. Hashemi, J.M. Christensen, C. Zou, P. Marshall, P. Glarborg, Ammonia oxidation at high pressure and intermediate temperatures, Fuel 181 (2016) 358-365. 
 NH2+HO2=H2NO+OH                                 5.000E+13   0.00    0.000E+00    

!J.E. Chavarrio, M. Monge-Palacios, X. Zhang, S.M. Sarathy, Probing the gas-phase oxidation of ammonia - I: Addressing uncertainties with theoretical calculations, Combust. Flame, (2021) submitted.
 NH2+HO2 = NH3+O2        2.18E+06	2.08E+00	-4.76E+03

!S.J. Klippenstein, L.B. Harding, P. Glarborg, J.A. Miller, The role of NNH in NO formation and control, Combustion and Flame 158 (2011) 774-789. 
 NH2+O2=H2NO+O                                   2.60E+11	0.4872	2.91E+04  !2.60E+11
 NH2+O2=HNO+OH                                   2.90E-02   3.7640  18185 

!P. Dransfeld and H. Gg. Wagner Zeitschrift f  r Physikalische Chemie, 153 (1987) 89. 
 NH2+N=N2+H+H                                    6.900E+13   0.00    0.000E+00 

!S.J. Klippenstein, L.B. Harding, P. Glarborg, J.A. Miller, Combustion and Flame 158 (2011) 774-789.
NH2+NO=NNH+OH                        3.1E13   -0.48    1180
NH2+NO=N2+H2O                        1.3E16   -1.25       0
 DUP
NH2+NO=N2+H2O                       -3.1E13   -0.48    1180
 DUP

!P. Glarborg, J.A. Miller, B. Ruscic, S.J. Klippenstein, Prog. Energy Combust. Sci. 67 (2018) 31-68
 NH2+NO2=H2NO+NO                                 8.600E11   0.110   -1186
 NH2+NO2=N2O+H2O                                 2.200E11   0.110   -1186
 
!S. Xu, M.C. Lin, Int J Chem Kinet 41: 667 677, 2009. 550-3000 K
 NH2+HNO=NH3+NO                                  5.9E02   2.950   -3469
 
!S. Xu, M.C. Lin, Int J Chem Kinet 41: 678 688, 2009. 650-3000 K
 NH2+HONO=NH3+NO2                                4.84E+00	 3.36	 -4.58E+03
!
 NH+NH=NH2+N                                     5.700E-01   3.88    3.420E+02 ! KLIMIC2009, 300-2500 K
 NH2+NH2=NH3+NH                                  5.636E+00   3.53    5.526E+02 ! KLIMIC2009 300-2500 K
 NH2+NH=NH3+N                                    9.574E+03   2.46    1.073E+02 ! KLIMIC2009 200-2500 K
 
!------------------------------------------------------------------------------
!---------------------N2H2 REACTIONS-------------------------------------------
!------------------------------------------------------------------------------

!Dean AM Bozzelli JW (Gardiner WC) Gas Phase Combustion Chemistry, Springer 2000
 N2H2+M=NNH+H+M                                  1.900E+27  -3.05    6.610E+04 ! M=N2
 H2O/7/

!Y. Li, S.M. Sarathy, Int. J. Hydrogen Energy 45 (2020) 23624-23637.
 N2H2+H=NNH+H2                                     4.82E+08    1.76      739.2384

 N2H2+O=NH2+NO                                   1.000E+13   0.00    0.000E+00 ! SKR/GLA04 JAM est   KLIMIC2011

!Y. Li, S.M. Sarathy, Int. J. Hydrogen Energy 45 (2020) 23624-23637.
 N2H2+O=NNH+OH                                    1.11E+08    1.62       804.816

!P. Raghunath, et al.,Chapter Seven - Ab Initio Chemical Kinetics of Key Processes in the Hypergolic Ignition of Hydrazine and Nitrogen Tetroxide, in: J.R. Sabin (Ed.), Advances in Quantum Chemistry, Academic Press2014, pp. 253-301.
 N2H2+OH=NNH+H2O                                 6.74E+03	  2.80	  -5.07E+02

 N2H2+NO=N2O+NH2                                 4.000E+12   0.00    1.192E+04 ! SKR/GLA04 DEA/BOZ00 KLIMIC2011
 
!P. Raghunath, et al.,Chapter Seven - Ab Initio Chemical Kinetics of Key Processes in the Hypergolic Ignition of Hydrazine and Nitrogen Tetroxide, in: J.R. Sabin (Ed.), Advances in Quantum Chemistry, Academic Press2014, pp. 253-301.  
 N2H2+NO2=NNH+HONO                               1.25E+00	 3.80	 1.04E+04

 N2H2+NH=NNH+NH2                                 2.400E+06   2.00   -1.192E+03 ! SKR/GLA04 DEA/BOZ00 KLIMIC2011
 
!P. Di  vart, L. Catoire, Contributions of Experimental Data Obtained in Concentrated Mixtures to Kinetic Studies: Application to Monomethylhydrazine Pyrolysis, The Journal of Physical Chemistry A 124 (2020) 6214-6236.
 N2H2+NH2=NNH+NH3                                 2.71E+05	2.226	-1.03E+03

!SJ Klippenstein LB Harding B Ruscic R Sivaramakrishnan NK Srinivasan M-C Su JV Michael JPCA 113 (2009) 10241-10259. 
 NH2+NH=N2H2+H                                   1.300E+14  -0.272  -7.700E+01     !4.300E+14
 
!SJ Klippenstein LB Harding B Ruscic R Sivaramakrishnan NK Srinivasan M-C Su JV Michael JPCA 113 (2009) 10241-10259.
 NH2+NH2=N2H2+H2                                  1.7E08     1.620   11783
 
 N2H2+HO2=NNH+H2O2                               1.000E+13   0.00    1.987E+03 ! Allen 1997 cited Hanson 1984 
!------------------------------------------------------------------------------
!--------------------------N2H4 REACTIONS--------------------------------------!
!------------------------------------------------------------------------------
 NH2+NH2(+M)=N2H4(+M)                            5.600E+14  -0.414   6.600E+01 ! KLIMIC09
 LOW /1.6E+34 -5.49 1.987E+03/                                                 !
 TROE /0.31 1.0E-30 1.0E+30 1.0E+30/                                           !
 AR/0.59/N2/1/O2/0.69/NH3/4.87/                                                !P. Glarborg et al., J. Phys. Chem. A 125 (2021) 1505   1516
!P. Raghunath, Comp. Theor. Chem. 1046, 73-80, 2014. 1 atm
 N2H4=N2H2+H2                                    5.19E+38	-7.84	6.71E+04
 N2H4=N2H3+H                                     2.74E+39	-7.69	8.37E+04                                  

!N. Kanno, T. Kito, Theoretical study on the hydrogen abstraction reactions from hydrazine derivatives by H atom, International Journal of Chemical Kinetics 52 (2020) 548-555. 
 N2H4+H=N2H3+H2                                  2.76E+05	2.56	1.22E+03

!Vaghjiani GL IJCK 33:354-362 2001
 N2H4+OH=N2H3+H2O                                  1.3E13      0.000    -318  

!Q.S. Li, X.A.F. Zhang, Direct dynamics study on the hydrogen abstraction reactions N2H4+R->N2H3+RH (R=NH2,CH3),J. Chem. Phys. 125 064304 2006
 N2H4+NH2=N2H3+NH3                                 7.6E-1   4.000    4048 ! 

 N2H4+N2H2=N2H3+N2H3                             2.500E+10   0.50    2.980E+4  ! Allen 1997
 N2H4+NH=N2H3+NH2                                1.000E+12   0.00    1.990E+03 ! Allen 1997
 N2H4+O=N2H2+H2O                                 4.400E+11   0.00   -1.270E+03 ! SKR/GLA04 VAG96 KLIMIC2011
 N2H4+O=N2H3+OH                                  6.700E+08   1.50    2.851E+03 ! SKR/GLA04 DEA/BOZ00 KLIMIC2011
 
!P. Raghunath and Y.H. Lin and M.C. Lin, Comp. Theor. Chem. 1046, 73-80, 2014
 N2H4+NO=N2H3+HNO                     6.0E01   3.160   30845 ! 
 N2H4+NO2=N2H3+HONO                   8.2E01   3.130    8860 ! 
 N2H4+NO2=N2H3+HNO2                   2.4E-2   4.140    7946 ! 
 
!---------------------------N2H3 REACTIONS-------------------------------------! 
!P. Divart, L. Catoire, Contributions of Experimental Data Obtained in Concentrated Mixtures to Kinetic Studies: Application to Monomethylhydrazine Pyrolysis, The Journal of Physical Chemistry A 124 (2020) 6214-6236.
 N2H3(+M)=N2H2+H(+M)                             1.28E+11	0.819	4.81E+04 !1.28E+11
 LOW /3.84E+40	-6.88	5.45E+04/                                            !3.84E+40 
 TROE/8.42E-01	80000	2.80E+01	7298/                        
 AR/1/N2/2/
 N2H3+H=N2H2+H2                                  7.476E+03  2.796  4.68E+03
 N2H3+H=H2NN+H2                                  6.243E+06	1.89	2.47E+02

 N2H3+H=NH3+NH                                   1.000E+11   0.00    0.000E+00 ! Allen 1997 also used by Coppens 2007
 N2H3+O=N2H2+OH                                  1.700E+08   1.50   -6.460E+02 ! SKR/GLA04 cited DEA/BOZ2000
 N2H3+O=NH2+HNO                                  3.000E+13   0.00    0.000E+00 ! SKR/GLA04 cited DEA/BOZ2000
 N2H3+O=>NH2+NO+H                                3.000E+13   0.00    0.000E+00 ! SKR/GLA04 cited DEA/BOZ2000
 N2H3+OH=N2H2+H2O                                1.200E+06   2.00   -1.192E+03 ! SKR/GLA04 cited DEA/BOZ2000
 N2H3+OH=H2NN+H2O                                3.000E+13   0.00    0.000E+00 ! SKR/GLA04 cited DEA/BOZ2000
 N2H3+OH=NH3+HNO                                 1.000E+12   0.00    1.500E+04 ! SKR/GLA04 cited JAM est
 N2H3+HO2=N2H2+H2O2                              1.400E+04   2.69   -1.600E+03 ! SKR/GLA04 cited DEA/BOZ2000
 N2H3+HO2=N2H4+O2                                9.200E+05   1.94    2.126E+03 ! SKR/GLA04 cited DEA/BOZ2000

!P. Di  vart, L. Catoire, Contributions of Experimental Data Obtained in Concentrated Mixtures to Kinetic Studies: Application to Monomethylhydrazine Pyrolysis, The Journal of Physical Chemistry A 124 (2020) 6214-6236.
 N2H3+NH2=N2H2+NH3                               6.08E-01	3.574	1.19E+03
 N2H3+NH2=H2NN+NH3                               1.11E+01	3.08	2.11E+02
!
 N2H3+NH=N2H2+NH2                                2.000E+13   0.00    0.000E+00 ! SKR/GLA04 JAM est
 N2H3+N2H2=N2H4+NNH                              1.000E+13   0.00    9.940E+03 ! Allen 1997
 N2H3+N2H3=NH3+NH3+N2                            3.000E+12   0.00    0.000E+00 ! Coppens 2007 3.000E+12
 N2H2+N2H2=N2H3+NNH                              1.000E+13   0.00    9.935E+03 ! Allen 1997 cited Hanson 1984
!-----------------------------H2NN REACTIONS-----------------------------------!
 NH2+NH2=H2NN+H2                                 7.200E+04   1.88    8.802E+03 ! KLIMIC09
 H2NN=NNH+H                                      3.400E+26  -4.83    4.622E+04 ! SKR/GLA2004 cited DEA/BOZ2000 1 ATM also used by KLIMIC2011
 H2NN+H=NNH+H2                                   4.800E+08   1.50   -8.940E+02 ! SKR/GLA2004 cited DEA/BOZ2000  also used by KLIMIC2011
 H2NN+H=N2H2+H                                   7.000E+13   0.00    0.000E+00 ! SKR/GLA2004 cited DEA/BOZ2000  also used by KLIMIC2011
 H2NN+O=NNH+OH                                   3.300E+08   1.50   -8.940E+02 ! SKR/GLA2004 cited DEA/BOZ2000  also used by KLIMIC2011
 H2NN+O=NH2+NO                                   7.000E+13   0.00    0.000E+00 ! SKR/GLA2004 cited DEA/BOZ2000  also used by KLIMIC2011
 H2NN+OH=NNH+H2O                                 2.400E+06   2.00   -1.192E+03 ! SKR/GLA2004 cited DEA/BOZ2000  also used by KLIMIC2011
 H2NN+OH=>NH2+NO+H                               2.000E+12   0.00    0.000E+00 ! SKR/GLA2004 cited DEA/BOZ2000  also used by KLIMIC2011
 H2NN+HO2=>NH2+NO+OH                             9.000E+12   0.00    0.000E+00 ! SKR/GLA2004 cited DEA/BOZ2000  also used by KLIMIC2011
 H2NN+HO2=NNH+H2O2                               2.900E+04   2.69   -1.600E+03 ! SKR/GLA2004 cited DEA/BOZ2000  also used by KLIMIC2011
 H2NN+O2=NH2+NO2                                 1.500E+12   0.00    5.961E+03 ! SKR/GLA2004 cited DEA/BOZ2000  also used by KLIMIC2011
 H2NN+NH2=NNH+NH3                                1.800E+06   1.94   -1.152E+03 ! SKR/GLA2004 cited DEA/BOZ2000  also used by KLIMIC2011
!------------------------------------------------------------------------------
!-------------------------HNOH REACTIONS---------------------------------------
!------------------------------------------------------------------------------
!Dean AM Bozzelli JW (Gardiner WC) Gas Phase Combustion Chemistry, Springer 2000
 H2NO+M=HNOH+M                                   1.100E+29  -4.00    4.400E+04 ! Skreiberg 2004 cited DEN/BOZ2000 also used by KLIMIC2011 also used by Tian 2009/Zhang 2011
 H2O/10.0/                                                                     !
 HNOH+M=HNO+H+M                                  2.000E+24  -2.80    5.893E+04 ! Skreiberg 2004 cited DEN/BOZ2000 also used by Tian 2009/Zhang 2011
 H2O/10.0/                                                                     !
 HNOH+H=NH2+OH                                   4.000E+13   0.00    0.000E+00 ! Skreiberg 2004 cited DEN/BOZ2000 also used by Tian 2009/Zhang 2011
 HNOH+H=HNO+H2                                   4.800E+08   1.50    3.780E+02 ! Skreiberg 2004 cited DEN/BOZ2000 also used by Tian 2009/Zhang 2011
 HNOH+O=HNO+OH                                   7.000E+13   0.00    0.000E+00 ! Skreiberg 2004 cited DEN/BOZ2000 also used by Tian 2009/Zhang 2011
 DUPLICATE                                                                     !
 HNOH+O=HNO+OH                                   3.300E+08   1.50   -3.580E+02 ! Skreiberg 2004 cited DEN/BOZ2000 also used by Tian 2009/Zhang 2011
 DUPLICATE                                                                     !
 HNOH+OH=HNO+H2O                                 2.400E+06   2.00   -1.192E+03 ! Skreiberg 2004 cited DEN/BOZ2000 also used by Tian 2009/Zhang 2011
 HNOH+HO2=HNO+H2O2                               2.900E+04   2.70   -1.600E+03 ! Skreiberg 2004 cited DEN/BOZ2000 also used by Tian 2009/Zhang 2011
 HNOH+O2=HNO+HO2                                 3.000E+12   0.00    2.500E+04 ! Skreiberg 2004 cited cited Miller 1999 also used by Tian 2009/Zhang 2011
 HNOH+NH2=N2H3+OH                                1.000E+01   3.50   -4.670E+02 ! Skreiberg 2004 cited DEN/BOZ2000 also used by Tian 2009/Zhang 2011
 HNOH+NH2=H2NN+H2O                               8.800E+16  -1.10    1.113E+03 ! Skreiberg 2004 cited DEN/BOZ2000 also used by Tian 2009/Zhang 2011
 HNOH+NH2=NH3+HNO                                1.800E+06   1.90   -1.152E+03 ! Skreiberg 2004 cited DEN/BOZ2000 also used by Tian 2009/Zhang 2011
 HNOH+NO2=HONO+HNO                               6.000E+11   0.00    2.000E+03 ! Skreiberg 2004 cited Miller 1999 also used by Tian 2009/Zhang 2011
!------------------------------------------------------------------------------
!---------------------------NH2OH REACTIONS------------------------------------
!------------------------------------------------------------------------------
 NH2OH(+M)=NH2+OH(+M)                            1.400E+20  -1.310   6.408E+04 ! KLIMIC09 ! 300-2500 K
 LOW /5.40E+37 -5.96 6.678E+04/                                                !          ! 450-2500 K
 TROE/0.35 1E-30 1E+30 1E+30/                                                  !
 NH2OH+H=HNOH+H2                                 4.800E+08   1.50    6.249E+03 ! KLIMIC09 DB HTRANS
 NH2OH+H=H2NO+H2                                 2.400E+08   1.50    5.067E+03 ! KLIMIC09 DB HTRANS
 NH2OH+O=HNOH+OH                                 3.300E+08   1.50    3.865E+03 ! KLIMIC09 DB HTRANS
 NH2OH+O=H2NO+OH                                 1.700E+08   1.50    3.010E+03 ! KLIMIC09 DB HTRANS
 NH2OH+OH=HNOH+H2O                               1.500E+04   2.61   -3.537E+03 ! KLIMIC09
 NH2OH+OH=H2NO+H2O                               1.500E+05   2.28   -1.296E+03 ! KLIMIC09
 NH2OH+NH2=HNOH+NH3                              1.100E-01   4.00   -9.700E+01 ! KLIMIC09
 NH2OH+NH2=H2NO+NH3                              9.500E+00   3.42   -1.013E+03 ! KLIMIC09
 NH2OH+NH=HNOH+NH2                               2.900E-03   4.40    1.564E+03 ! KLIMIC09
 NH2OH+NH=H2NO+NH2                               1.500E-03   4.60    2.424E+03 ! KLIMIC09
 NH2OH+HO2=HNOH+H2O2                             2.900E+04   2.69    9.557E+03 ! KLIMIC09 DB HTRANS
 NH2OH+HO2=H2NO+H2O2                             1.400E+04   2.69    6.418E+03 ! KLIMIC09 DB HTRANS
 HNOH+HNO=NH2OH+NO                               1.000E+12   0.00    3.000E+03 ! Coppens 2007 also used by Mevel 2009/Konnov 2009
!-------------------------------------------------------------------------------
!-----------------------NH3 REACTIONS-------------------------------------------!
!-------------------------------------------------------------------------------

!D.F. Davidson, K. Kohse-H  inghaus, A.Y. Chang, R.K. Hanson, IJCK 22 (1990) 513-535.
 NH3+M<=>NH2+H+M                        2.2E16   0   93470
                                        
!T.L. Nguyen, J.F. Stanton, Ab initio thermal rate coefficients for H + NH3 = H2 + NH2, International Journal of Chemical Kinetics 51 (2019) 321-328. 
 NH3+H=NH2+H2             2.89E+06	2.23	1.04E+04
 
!Stagni, A. et al. React. Chem. Eng. doi:10.1039/C9RE00429G(2020). !ZXY_Stagni, A. et al. React. Chem. Eng. doi:10.1039/C9RE00429G(2020).  
 NH3+OH=H2O+NH2		     1.559E+05   2.372    118.9 
 NH3+HO2=NH2+H2O2        1.173E+00   3.839  17260.0
 NH3+O=NH2+OH			 4.430E+02   3.180   6739.9
 
 NH3+NH2=N2H3+H2                                 1.000E+11   0.50   2.160E+04  ! Coppens 2007
!
!------------------------------------------------------------------------------
!--------------------NNH REACTIONS---------------------------------------------
!------------------------------------------------------------------------------

!H. Koizumi , G.C. Schatz , S.P. Walch , J. Chem. Phys. 95 (1991) 4130   4135. 
NNH=N2+H                                          3.30E+08   0.0    0.0

!J.A. Miller, C.T. Bowman, Prog. Energy Combust. Sci. 15 (1989) 287-338.
 NNH+H=N2+H2                                     1.000E+14   0.00   0.000E+00
 NNH+OH=N2+H2O                                   5.000E+13   0.00   0.000E+00
 NNH+NO=N2+HNO                                   5.000E+12   0.00   0.000E+00  !5.000E+13  ZXY_modified_20200903
 NNH+NH=N2+NH2                                   5.000E+13   0.00   0.000E+00
 NNH+NH2=N2+NH3                                  5.000E+13   0.00   0.000E+00
!S.J. Klippenstein, et al., Combust. Flame 158 (2011) 774-789.
 NNH+O=N2O+H                                     1.870E+14  -0.274 -2.200E+01
 NNH+O=NH+NO                                     5.180E+11   0.388 -4.090E+02
 NNH+O=N2+OH                                     1.200E+13   0.145 -2.170E+02
 NNH+O2=N2+HO2                                   5.600E+14  -0.385     -13

 NNH+NNH=N2H2+N2                                 1.000E+13   0.00   9.935E+03  ! Allen 1997 cited Hanson 1984
!-----------------------------------------------------------------------------
!-------------------------HNO REACTIONS --------------------------------------
!-----------------------------------------------------------------------------

!Stagni, A. et al. React. Chem. Eng. doi:10.1039/C9RE00429G(2020).
 HNO=H+NO				 	.18259e+21  -3.008  47880.0 
! PLOG /		      0.100  	 			        .20121e+20  -3.021  47792.0   /
! PLOG /		      1.000		 			.18259e+21  -3.008  47880.0   /
! PLOG /		      10.00		 			.12762e+22  -2.959  48100.0   /
! PLOG /		      100.0		 			.56445e+22  -2.855  48459.0   /
! PLOG /		      1000.		 			.97111e+22  -2.642  48940.0   / 

!S. Inomata, J. Phys. Chem. A, 103 (1999) 5023-5031.
 HNO+O=NO+OH                                     2.300E+13   0.00   0.000E+00
 
!M.R. Soto, J. Chem. Phys. 97 (1992) 7287-7296.
 HNO+H=NO+H2                                     4.400E+11   0.72   6.500E+02
 
!J.A. Miller, C.T. Bowman, Prog. Energ. Combust. Sci. 15 (1989) 287-338. 
 HNO+OH=NO+H2O                                   3.600E+13   0.00   0.000E+00
 
!A.M. Dean, J.W. Bozzelli, Springer New York, New York, NY, 2000, pp. 125-341. 
 HNO+O2=NO+HO2                                   2.000E+13   0.00   1.600E+04
 
 HNO+N=NO+NH                                     1.000E+13   0.00   1.990E+03 ! Klaus 1997 also used by Lamoureux 2016/Mathieu 2015
 HNO+N=N2O+H                                     5.000E+10   0.50   3.000E+03 ! Coppens 2007/Konnov 2009
 HNO+NH=NH2+NO                                   5.000E+11   0.50   0.000E+00 ! Coppens 2007 also used by Konnov 2009

!Diau, E.W.; Halbgewachs, M.J.; Smith, A.R.; Lin, M.C.  Int. J. Chem. Kinet. 27 867-881 (1995)
 HNO+NO=N2O+OH                                   8.510E+12    0.00  29610.0
 
!Mebel, A.M.; Lin, M.C.; Morokuma, K. Int. J. Chem. Kinet. 30 729-736 (1998) 
 HNO+NO2=HONO+NO                                 4.400E+04   2.60   4.040E+03  
 
!Tsang, W.; Herron, J.T. J. Phys. Chem. Ref. Data 20 609-663 (1991)
 HNO+HNO=N2O+H2O                                 9.000E+08   0.00   3.100E+03

!----------------------------------------------------------------------------
!-------------------------HON REACTIONS--------------------------------------
!----------------------------------------------------------------------------
 HON+M=NO+H+M                                    5.100E+19  -1.73  1.604E+04 ! Mathieu 2015 cited Dean and Bozzelli 2000 M=N2
 AR/0.7/  H2O/7.0/  CO2/2.0/                                                 !
 HON+H=HNO+H                                     2.400E+13   0.00  0.000E+00 ! Mathieu 2015 cited Dean and Bozzelli 2000
 HON+H=OH+NH                                     1.000E+13   0.00  0.000E+00 ! Mathieu 2015 cited Dean and Bozzelli 2000
 HON+O=OH+NO                                     7.000E+13   0.00  0.000E+00 ! Mathieu 2015 cited Dean and Bozzelli 2000
 HON+OH=HONO+H                                   4.000E+13   0.00  0.000E+00 ! Mathieu 2015 cited Dean and Bozzelli 2000
 HON+O2=NO2+OH                                   1.000E+12   0.00  4.968E+03 ! Mathieu 2015 cited Dean and Bozzelli 2000
!-----------------------------------------------------------------------------
!-------------------------NO REACTIONS----------------------------------------
!-----------------------------------------------------------------------------
 NO+OH(+M)=HONO(+M)                              1.100E+14  -0.30    0.000E+00 ! Rasmussen ;IJCK 40: 454 C480,2008 cited FUL/TRO98 also used by KLIMIC2011/Mendiara 2009
 LOW / 3.392E+23 -2.51  0.000E+00/                                             ! FUL/TRO98
 TROE/0.75  1.0E-30  1.0E+30  1.0E+30/                                         ! FUL/TRO98 [M=He,T=400K]

 NO+HO2=NO2+OH                                   2.100E+12   0.00   -4.800E+02 ! Baulch 2005 A/2.100E+12s error (+/-0.15) 200-2000K also used by Mueller 1999/Dayma 2007/Mendiara 2009
!------------------------------------------------------------------------------
!------------------------NO2 REACTIONS-----------------------------------------
!------------------------------------------------------------------------------
 NO2+H2=HONO+H                                   1.300E+04   2.76    2.977E+04 ! Rasmussen ;IJCK 40: 454 C480,2008 cited PAR/LIN98 also used by KLIMIC2011/Mendiara 2009
 NO2+H2=HNO2+H                                   2.400E+00   3.73    3.240E+04 ! Rasmussen ;IJCK 40: 454 C480,2008 (ab initio CBS-QB3) calculation also used by KLIMIC2011/Mendiara 2009

! Ko T Fontijn A JPC 95:3984-3987 1991 
 NO2+H=NO+OH                                     1.300E+14   0.00     362      !
 NO2+O=NO+O2                                     1.100E+14  -0.50    0.000E+00 ! Bemand 1974 also used by Mueller 1999/KLIMIC2011/Lamoureux 2016
 NO+O(+M)=NO2(+M)                                2.950E+14  -0.40    0.000E+00 ! Baulch 2005 error (+/-0.3) 200-2200
 LOW/3.336E+20  -1.60    0.000E+00/                                            ! A/3.336E+20 error (+/-0.3) M=N2
 TROE/0.80 1.0E-30  1.0E+30  1.0E+30/                                          ! Fc(+/-0.2)
 H2/1.0/H2O/6.40/CO2/1.50/O2/0.45/N2/0.40/AR/0.35/HE/0.35/CO/0.75/CH4/3.0/C2H6/3.0/ ! Griffith & Barnard
 NO2+OH(+M)=HONO2(+M)                            3.000E+13   0.00    0.000E+00 ! Rasmussen;IJCK 40: 454 C480,2008 also used by Mendiara 2009/KLIMIC2011 
 LOW/ 2.938E+25 -3.00  0.000E+00 /                                             !
 TROE /0.40  1.0E-30  1.0E+30  1.0E+30/                                        !
 NO2+NO2=NO+NO+O2                                4.500E+12   0.00    2.760E+04 ! Rasmussen;IJCK 40: 454 C480,2008 cited PAR/LIN98 also used by Lamoureux 2016
 NO2+HO2=HONO+O2                                 1.910E+00   3.32    3.044E+03 ! Rasmussen;IJCK 40: 454 C480,2008 (ab initio CBS-QB3) calculation also used by KLIMIC2011/Tian 2009/Zhang2011/Mendiara 2009 
 NO2+HO2=HNO2+O2                                 1.850E+01   3.26    4.983E+03 ! Rasmussen;IJCK 40: 454 C480,2008 (ab initio CBS-QB3) calculation also used by KLIMIC2011
!-------------------------------------------------------------------------------
!-----------------------N2O REACTIONS-------------------------------------------
!-------------------------------------------------------------------------------
 N2O(+M)=N2+O(+M)                                1.300E+12   0.00    6.257E+04 ! R?hrig 1996 also used by Tian 2009/Zhang 2011/KLIMIC2011
 LOW / 4.00E+14  0.000   5.660E+04/                                            !
 N2/ 1.7/ O2/ 1.4/ CO2/ 3.0 / H2O / 12.0/                                      ! 

 N2O+H=N2+OH                                     2.530E+10   0.00    4.550E+03 ! Powell 2010 modified the rate of Baulch 2005
 DUPLICATE                                                                     !
 N2O+H=N2+OH                                     5.000E+14   0.00    1.810E+04 !
 DUPLICATE                                                                     !
 N2O+O=NO+NO                                     9.200E+13   0.00    2.767E+04 ! Baulch 2005 A/9.200E+13 error(+/-0.2-0.4) 1000-4000K
 N2O+O=N2+O2                                     3.700E+12   0.00    1.593E+04 ! Baulch 2005 A/3.700E+12 error(+/-0.2-0.5) 1000-2500K
 N2O+OH=N2+HO2                                   1.300E-02   4.70    3.656E+04 ! Mebel et al.;IJCK 1996, 28, 693 C703 also used by Tian 2009/KLIMIC2011/Zhang 2011
 N2O+NO=NO2+N2                                   5.300E+05   2.20    4.628E+04 ! Mebel et al.;IJCK 1996, 28, 693 C703 also used by Tian 2009/KLIMIC2011/Zhang 2011
 N2O+N=N2+NO                                     1.000E+13   0.00    1.987E+04 ! Mathieu 2015
 N2O+H=N2+OH*                                    1.600E+14   0.00    5.030E+04 ! Hidaka 1985 error (1.6+/-1) ! The Journal of Physical Chemistry, Vol. 89, No. 23, 1985
!------------------------------------------------------------------------------
!----------------------H2NO REACTIONS------------------------------------------
!------------------------------------------------------------------------------
!Dean AM Bozzelli JW (Gardiner WC) Gas Phase Combustion Chemistry, Springer 2000
 H2NO+M=HNO+H+M                           2.800E+24  -2.80    6.491E+04 
 H2O/10.0/                                                                     
 H2NO+H=HNO+H2                            4.800E+08   1.500   1559.8
 H2NO+H=NH2+OH                            4.000E+13   0.000      0.0 
 H2NO+O=HNO+OH                            3.300E+08   1.500    486.8
 H2NO+OH=HNO+H2O                      	  2.400E+06   2.000   1192.2
 H2NO+NH2=HNO+NH3	                      1.800E+06   1.940   -580.0
 H2NO+HO2=HNO+H2O2                        2.900E+04   2.69    -1600
 
!P. Glarborg, J.A. Miller, B. Ruscic, S.J. Klippenstein, Prog. Energy Combust. Sci. 67 (2018) 31-68.
 H2NO+O2=HNO+HO2                                 2.300E+02   2.994   16500        !

!A El Bakali L Pillier P Desgroux B Lefort L Gasnot JF Pauwels I Da Costa Fuel 85 896-909 (2006)
 H2NO+NO=HNO+HNO                                 2.000E+04   2.00    1.300E+04 

!P. Glarborg, et al., Int. J. Chem. Kinet. 1995 (27):1207-20 
 H2NO+NO2=HONO+HNO                               6.000E+11   0.00    2.000E+03
!-----------------------------------------------------------------------------
!-------------------------HONO REACTIONS--------------------------------------! 
!-----------------------------------------------------------------------------
 HONO+O=NO2+OH                                   1.200E+13   0.00    6.000E+03 ! Rasmussen; IJCK 40, 454 C480 cited GLA/MIL98also used by Lamoureux 2016
 HONO+H=HNO+OH                                   5.600E+10   0.90    5.000E+03 ! Skreiberg 2004 cited Hsu 1997 also used by KLIMIC2011/Lamoureux 2016
 HONO+H=NO+H2O                                   8.100E+06   1.90    3.850E+03 ! Skreiberg 2004 cited Hsu 1997 also used by KLIMIC2011/Lamoureux 2016
 HONO+OH=NO2+H2O                                 1.700E+12   0.00   -5.200E+02 ! Rasmussen; IJCK 40, 454 C480 cited BUR/RAV92 also used by KLIMIC2011 Lamoureux 2016
 HONO+NO2=HONO2+NO                               2.000E+11   0.00    3.270E+04 ! Rasmussen; IJCK 40, 454 C480 cited PAR/LIN98
 HONO+HONO=NO+NO2+H2O                            3.500E-01   3.64    1.214E+04 ! Rasmussen; IJCK 40, 454 C480 cited MEB/MEL98
!------------------------------------------------------------------------------
!------------------------HNO2 REACTIONS----------------------------------------!
!------------------------------------------------------------------------------
 HNO2(+M)=HONO(+M)                               2.500E+14   0.00    3.230E+04 ! Rasmussen; IJCK 40, 454 C480 (ab initio CBS-QB3) calculation
 LOW /  3.100E+18   0.0   3.150E+04 /                                          !
 TROE /1.149  1E-30  3.125E+03  1E+30 /                                        !
 HNO2+O=NO2+OH                                   1.700E+08   1.50    2000.0    ! Rasmussen; IJCK 40, 454 C480 cited DEA/BOZ00 also used by KLIMIC2011
 HNO2+OH=NO2+H2O                                 4.000E+13   0.00    0.000E+00 ! Rasmussen; IJCK 40, 454 C480 (ab initio CBS-QB3) calculation also used by Mendiara 2009/Klippenstein 2011
!------------------------------------------------------------------------------
!--------------------------HONO2 REACTIONS-------------------------------------
!------------------------------------------------------------------------------
 HONO2+H=H2+NO3                                  5.600E+08   1.50    16400.0   ! Rasmussen; IJCK 40, 454 C480 cited BOU/LIN97 also used by KLIMIC2011
 HONO2+H=H2O+NO2                                 6.100E+01   3.30    6285.0    ! Rasmussen; IJCK 40, 454 C480 cited BOU/LIN97 also used by KLIMIC2011
 HONO2+H=OH+HONO                                 3.800E+05   2.30    6976.0    ! Rasmussen; IJCK 40, 454 C480 cited BOU/LIN97 also used by KLIMIC2011
 HONO2+OH=H2O+NO3                                1.000E+10   0.00   -1240.0    ! Rasmussen; IJCK 40, 454 C480 cited LAM/BEN84 also used by KLIMIC2011
!------------------------------------------------------------------------------
!---------------------------NO3 REACTIONS-------------------------------------- 
!------------------------------------------------------------------------------
 NO2+O(+M)=NO3(+M)                               3.500E+12   0.20    0.000E+00 ! Mendiara 2009
 LOW / 2.500E+20 -1.50  0.000E+00 /                                            ! M=N2
 TROE /0.71  1.0E-30  1700.0  1.0E+30/                                         ! Fc=0.71*exp(-T/1700)
 NO2+NO2=NO3+NO                                  9.60E+09    0.70    2.090E+04 ! Mendiara and Glarborg 2009
 NO3+H=NO2+OH                                    6.00E+13    0.00    0.000E+00 ! Mendiara and Glarborg 2009
 NO3+O=NO2+O2                                    1.00E+13    0.00    0.000E+00 ! Mendiara and Glarborg 2009
 NO3+OH=NO2+HO2                                  1.40E+13    0.00    0.000E+00 ! Mendiara and Glarborg 2009
 NO3+HO2=NO2+O2+OH                               1.50E+12    0.00    0.000E+00 ! Mendiara and Glarborg 2009
 NO3+NO2=NO+NO2+O2                               5.00E+10    0.00    2.940E+03 ! Mendiara and Glarborg 2009
 NO3+NO3=NO2+NO2+O2                              5.12E+11    0.00    4.870E+03 ! Coppens 2007
 NO3+HO2=HNO3+O2                                 5.55E+11    0.00    0.000E+00 ! Coppens 2007
!-------------------------HNO3 REACTIONS---------------------------------------
 NO2+OH(+M)=HNO3(+M)                             2.410E+13   0.00    0.000E+00 ! Coppens 2007
 LOW / 6.42E+32 -5.49 2350.0 /                                                 !
 TROE /1.0 10.0 1168.0 /                                                       !
 H2O/10.0/ O2/2.0/ AR/0.75/ H2/2.0/ CO2/0.0/                                   !
 NO2+OH(+CO2)=HNO3(+CO2)                         2.410E+13   0.00    0.000E+00 ! Coppens 2007
 LOW / 5.80E+32 -5.4 2186.0 /                                                  !
 TROE /1.0 10.0 1168.0 /                                                       !
 NO+HO2+M=HNO3+M                                 1.500E+24  -3.50    2.200E+03 ! Coppens 2007 also used by Konnov 2009
 HNO3+H=H2+NO3                                   5.560E+08   1.53    1.640E+04 ! Coppens 2007 also used by Konnov 2009
 HNO3+H=H2O+NO2                                  6.080E+01   3.29    6.290E+03 ! Coppens 2007 also used by Konnov 2009
 HNO3+H=OH+HONO                                  3.820E+05   2.30    6.980E+03 ! Coppens 2007 also used by Konnov 2009
 HNO3+OH=NO3+H2O                                 1.030E+10   0.00   -1.240E+03 ! Coppens 2007 also used by Konnov 2009
 HNO3+NH2=NH3+NO3                                1.030E+21  -3.85    1.910E+02 ! Coppens 2007 also used by Konnov 2009
 DUPLICATE                                                                     !
 HNO3+NH2=NH3+NO3                                3.080E+01   3.22   -1.390E+02 !
 DUPLICATE
END




