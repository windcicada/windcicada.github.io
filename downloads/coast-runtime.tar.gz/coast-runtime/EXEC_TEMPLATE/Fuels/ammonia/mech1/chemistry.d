! Reduced Mechanism based in Okafor et al. Combust. Flame 2018 with updates （！for NH3/CH4/O2/Ar flames）

ELEMENTS
O  H  N AR
END
SPECIES
H2      H       O       O2      OH      H2O     HO2     H2O2    
C       CH      CH2     CH2(S)  CH3     CH4     CO      CO2     
HCO     CH2O    CH2OH   CH3O    CH3OH   C2H2    C2H3    C2H4
C2H5    C2H6    HCCO    N       NH      NH2     NH3     N2H2  
NNH     NO      NO2     N2O     HNO     HCN     N2      N2H3
CH2CHO	AR


END

REACTIONS
O+H2<=>H+OH                              3.870E+04    2.700    6260.00 !GRI Mech 3.0
O+HO2<=>OH+O2                            2.000E+13     .000        .00 !GRI Mech 3.0
O+CH3<=>H+CH2O                           5.540E+13     .050    -136.00 !HARDING et al.
O+CH4<=>OH+CH3                           1.020E+09    1.500    8600.00 !GRI Mech 3.0
O+CH2O<=>OH+HCO                          6.2600E+09   1.150    2260.00 !CURRAN FIT TO NIST DATABASE/ARAMCO Mech 2.0
O+CH3O<=>OH+CH2O                         1.000E+13     .000        .00 !GRI Mech 3.0
O+C2H2<=>H+HCCO                          1.350E+07    2.000    1900.00 !GRI Mech 3.0
H+O2+M<=>HO2+M                           2.800E+18    -.860        .00 !GRI Mech 3.0
O2/ .00/ H2O/ .00/ CO/ .75/ CO2/1.50/ C2H6/1.50/ N2/ .00/ AR/ .00/ 
H+2O2<=>HO2+O2                           2.080E+19   -1.240        .00 !GRI Mech 3.0
H+O2+H2O<=>HO2+H2O                       11.26E+18    -.760        .00 !GRI Mech 3.0
H+O2+N2<=>HO2+N2                         2.600E+19   -1.240        .00 !GRI Mech 3.0
H+O2+AR<=>HO2+AR                         7.000E+17    -.800        .00 !GRI Mech 3.0
H+O2<=>O+OH                              1.040E+14     .000   15286.00 !Hong et al. 
H+OH+M<=>H2O+M                           2.200E+22   -2.000        .00 !GRI Mech 3.0
H2/ .73/ H2O/3.65/ CH4/2.00/ C2H6/3.00/ AR/ .38/ 
H+HO2<=>O2+H2                            4.480E+13     .000    1068.00 !GRI Mech 3.0
H+HO2<=>2OH                              0.840E+14     .000     635.00 !GRI Mech 3.0
H+CH<=>C+H2                              1.650E+14     .000        .00 !GRI Mech 3.0
2CH3<=>C2H5+H                            3.160e+13     .000   14698.85 !Kim & Michael
H+CH3(+M)<=>CH4(+M)                      1.270e+16    -.630    382.89  !GRI Mech 2.11
H2/2.00/ H2O/6.00/ CO/1.50/ CO2/2.00/ CH4/2.00/ AR/0.70/ 
     LOW  /  2.470e+33   -4.760   2440.01 /
     TROE/   0.783       74      2941      6964 /
H+CH4<=>CH3+H2                           6.600E+08    1.620   10840.00 !GRI Mech 3.0
H+HCO<=>H2+CO                            1.210E+14     .000        .00 !Tsang & Hampson 
H+CH2O(+M)<=>CH3O(+M)                    5.400E+11     .454    2600.00 !GRI Mech 3.0
     LOW  /  2.200E+30   -4.800   5560.00/
     TROE/   .7580   94.00  1555.00  4200.00 /
H2/2.00/ H2O/6.00/ CH4/2.00/ CO/1.50/ CO2/2.00/ C2H6/3.00/ 
H+CH2O<=>HCO+H2                          5.740E+07    1.900    2742.00 !GRI Mech 3.0
H+CH2OH<=>OH+CH3                         1.650E+11     .650    -284.00 !GRI Mech 3.0
H+CH2OH<=>CH2(S)+H2O                     3.280E+13    -.090     610.00 !GRI Mech 3.0
H+CH3O<=>OH+CH3                          1.500E+12     .500    -110.00 !GRI Mech 3.0
H+CH3O<=>CH2(S)+H2O                      2.620E+14    -.230    1070.00 !GRI Mech 3.0
H+CH3OH<=>CH3O+H2                        4.200E+06    2.100    4870.00 !GRI Mech 3.0
H+C2H2(+M)<=>C2H3(+M)                    5.600E+12     .000    2400.00 !GRI Mech 3.0
     LOW  /  3.800E+40   -7.270   7220.00/
     TROE/   .7507   98.50  1302.00  4167.00 /
H2/2.00/ H2O/6.00/ CH4/2.00/ CO/1.50/ CO2/2.00/ C2H6/3.00/ AR/ .70/ 
H+C2H3<=>H2+C2H2                         3.000E+13     .000        .00 !GRI Mech 3.0
H+C2H4(+M)<=>C2H5(+M)                    0.540E+12     .454    1820.00 !GRI Mech 3.0
     LOW  /  0.600E+42   -7.620   6970.00/
     TROE/   .9753  210.00   984.00  4374.00 /
H2/2.00/ H2O/6.00/ CH4/2.00/ CO/1.50/ CO2/2.00/ C2H6/3.00/ AR/ .70/ 
H+C2H4<=>C2H3+H2                         1.325E+06    2.530   12240.00 !GRI Mech 3.0
OH+H2<=>H+H2O                            2.160E+08    1.510    3430.00 !GRI Mech 3.0
2OH(+M)<=>H2O2(+M)                       7.400E+13    -.370        .00 !GRI Mech 3.0
     LOW  /  2.300E+18    -.900  -1700.00/
     TROE/   .7346   94.00  1756.00  5182.00 /
H2/2.00/ H2O/6.00/ CH4/2.00/ CO/1.50/ CO2/2.00/ C2H6/3.00/ AR/ .70/ 
2OH<=>O+H2O                              3.570E+04    2.400   -2110.00 !GRI Mech 3.0
OH+HO2<=>H2O+O2                          7.000E+12    0.000   -1092.96 !hong pci 2013
DUP 
OH+HO2<=>H2O+O2                          4.500E+14    0.000   10929.60 !hong pci 2013
DUP 
OH+H2O2<=>HO2+H2O                        1.700E+18     .000   29410.00 !GRI Mech 3.0
OH+CH3(+M)<=>CH3OH(+M)                   2.790E+18   -1.430    1330.00 !GRI Mech 3.0
     LOW  /  4.000E+36   -5.920   3140.00/
     TROE/   .4120  195.0  5900.00  6394.00/ 
H2/2.00/ H2O/6.00/ CH4/2.00/ CO/1.50/ CO2/2.00/ C2H6/3.00/ 
OH+CH3<=>CH2+H2O                         5.600E+07    1.600    5420.00 !GRI Mech 3.0
OH+CH3<=>CH2(S)+H2O                      6.440E+17   -1.340    1417.00 !GRI Mech 3.0
OH+CH4<=>CH3+H2O                         1.000E+08    1.600    3120.00 !GRI Mech 3.0
CO+OH<=>CO2+H                            7.015E+04    2.053    -355.70 !JOSHI AND WANG
DUP 
CO+OH<=>CO2+H                            5.757E+12   -0.664     331.80 !JOSHI AND WANG
DUP 
OH+HCO<=>H2O+CO                          5.000E+13     .000        .00 !GRI Mech 3.0
OH+CH2O<=>HCO+H2O                        3.430E+09    1.180    -447.00 !GRI Mech 3.0
OH+C2H4<=>C2H3+H2O                       3.600E+06    2.000    2500.00 !GRI Mech 3.0
OH+C2H6<=>C2H5+H2O                       3.540E+06    2.120     870.00 !GRI Mech 3.0
2HO2<=>O2+H2O2                           1.300E+11     .000   -1630.00 !GRI Mech 3.0
 DUPLICATE
2HO2<=>O2+H2O2                           4.200E+14     .000   12000.00 !GRI Mech 3.0
 DUPLICATE
HO2+CH3<=>O2+CH4                         1.000E+12     .000        .00 !GRI Mech 3.0
HO2+CH3<=>OH+CH3O                        3.870E+13     .000        .00 !GRI Mech 3.0
HO2+CO<=>OH+CO2                          1.500E+14     .000   23600.00 !GRI Mech 3.0
CH+O2<=>O+HCO                            6.710E+13     .000        .00 !GRI Mech 3.0
CH+H2<=>H+CH2                            1.080E+14     .000    3110.00 !GRI Mech 3.0
CH+H2O<=>H+CH2O                          5.710E+12     .000    -755.00 !GRI Mech 3.0
CH2+O2=>OH+H+CO                          5.000E+12     .000    1500.00 !GRI Mech 3.0
CH2(S)+N2<=>CH2+N2                       1.500E+13     .000     600.00 !GRI Mech 3.0
CH2(S)+O2<=>H+OH+CO                      2.800E+13     .000        .00 !GRI Mech 3.0
CH2(S)+O2<=>CO+H2O                       1.200E+13     .000        .00 !GRI Mech 3.0
CH2(S)+H2<=>CH3+H                        7.000E+13     .000        .00 !GRI Mech 3.0
CH2(S)+H2O(+M)<=>CH3OH(+M)               4.820E+17   -1.160    1145.00 !GRI Mech 3.0
     LOW  /  1.880E+38   -6.360   5040.00/
     TROE/   .6027  208.00  3922.00  10180.0 /
H2/2.00/ H2O/6.00/ CH4/2.00/ CO/1.50/ CO2/2.00/ C2H6/3.00/ 
CH2(S)+H2O<=>CH2+H2O                     3.000E+13     .000        .00 !GRI Mech 3.0
CH2(S)+CO2<=>CO+CH2O                     1.400E+13     .000        .00 !GRI Mech 3.0
CH3+O2<=>O+CH3O                          3.560E+13     .000   30480.00 !GRI Mech 3.0
CH3+O2<=>OH+CH2O                         2.310E+12     .000   20315.00 !GRI Mech 3.0
2CH3(+M)<=>C2H6(+M)                      6.770E+16   -1.180     654.00 !GRI Mech 3.0
    LOW  /  3.400E+41   -7.030   2762.00/
   TROE/   .6190  73.20  1180.00  9999.00 /
H2/2.00/ H2O/6.00/ CH4/2.00/ CO/1.50/ CO2/2.00/ C2H6/3.00/ AR/ .70/ 
CH3+HCO<=>CH4+CO                         2.648E+13     .000        .00 !GRI Mech 3.0
HCO+H2O<=>H+CO+H2O                       1.500E+18   -1.000   17000.00 !GRI Mech 3.0
HCO+M<=>H+CO+M                           1.870E+17   -1.000   17000.00 !GRI Mech 3.0
H2/2.00/ H2O/ .00/ CH4/2.00/ CO/1.50/ CO2/2.00/ C2H6/3.00/ 
HCO+O2<=>HO2+CO                          13.45E+12     .000     400.00 !GRI Mech 3.0
C2H3+O2<=>HCO+CH2O                       4.580E+16   -1.390    1015.00 !GRI Mech 3.0
HCCO+O2<=>OH+2CO                         3.200E+12     .000     854.00 !GRI Mech 3.0
O+C2H4<=>H+CH2CHO                        6.700E+06    1.830     220.00 !GRI Mech 3.0
CH2+O2=>2H+CO2                           5.800E+12     .000    1500.00 !GRI Mech 3.0
CH2+O2<=>O+CH2O                          2.400E+12     .000    1500.00 !GRI Mech 3.0
C2H3+O2<=>O+CH2CHO                       3.030E+11     .290      11.00 !GRI Mech 3.0
N+NO<=>N2+O                              2.700E+13     .000     355.00 !GRI Mech 3.0
N+O2<=>NO+O                              9.000E+09    1.000    6500.00 !GRI Mech 3.0
N+OH<=>NO+H                              3.360E+13     .000     385.00 !GRI Mech 3.0
N2O+O<=>N2+O2                            1.400E+12     .000   10810.00 !GRI Mech 3.0
N2O+H<=>N2+OH                            3.870E+14     .000   18880.00 !GRI Mech 3.0
N2O+OH<=>N2+HO2                          2.000E+12     .000   21060.00 !GRI Mech 3.0
N2O(+M)<=>N2+O(+M)                       7.910E+10     .000   56020.00 !GRI Mech 3.0
     LOW  /  6.370E+14     .000  56640.00/
H2/2.00/ H2O/6.00/ CH4/2.00/ CO/1.50/ CO2/2.00/ C2H6/3.00/ AR/ .625/ 
HO2+NO<=>NO2+OH                          2.110E+12     .000    -480.00 !GRI Mech 3.0
NO+O+M<=>NO2+M                           1.060E+20   -1.410        .00 !GRI Mech 3.0
H2/2.00/ H2O/6.00/ CH4/2.00/ CO/1.50/ CO2/2.00/ C2H6/3.00/ AR/ .70/ 
NO2+O<=>NO+O2                            3.900E12      .000    -240.00 !GRI Mech 3.0
NO2+H<=>NO+OH                            1.320E14      .000     360.00 !GRI Mech 3.0
NH+H=N+H2                            	 3.0E13       0.000       0.00 ! SKR/GLA04 DAV/HAN90,rv/Tian Mech
NH+O=NO+H                            	 9.2E13       0.000       0.00 ! SKR/GLA04 CEC94/Tian Mech
NH+OH=HNO+H                          	 2.0E13       0.000       0.00 ! SKR/GLA04 JAM est/Tian Mech
NH+OH=N+H2O                          	 5.0E11       0.500    2000.00 ! SKR/GLA04 JAM est/Tian Mech
NH+O2=HNO+O                          	 4.6E05       2.000    6500.00 ! SKR/GLA04 MIL/MEL92/Tian Mech
NH+O2=NO+OH                          	 1.3E06       1.500     100.00 ! SKR/GLA04 MIL/MEL92/Tian Mech
NH+NO=N2O+H                              1.8E14      -0.351    -244.00 ! Klippenstein et al
NH+NO=N2+OH                          	 2.2E13      -0.230       0.00 ! SKR/GLA04 MIL/MEL92/Tian Mech
NH2+H=NH+H2                         	 7.2E05       2.320     799.00 ! SKR/GLA04 LIN/PAG95/Tian Mech
NH2+O=HNO+H                         	 6.6E13       0.000       0.00 !           INO/WAS99,DRA/WAG84,ADA/PHI94/Tian Mech 
NH2+OH=NH+H2O                       	 4.0E06       2.000    1000.00 ! SKR/GLA04 JAM est/Tian Mech
NH2+HO2=NH3+O2                      	 9.2E05       1.940   -1152.00 ! SKR/GLA04 DEA/BOZ00/Tian Mech
NH2+NH2=NH3+NH                      	 5.0E13       0.000   10000.00 ! SKR/GLA04 DAV/HAN90/Tian Mech
NH2+NH=N2H2+H                       	 5.0E13       0.000       0.00 ! SKR/GLA04 JAM est/Tian Mech
NH2+N=N2+H+H                        	 7.0E13       0.000       0.00 ! SKR/GLA04 WHY/PHI83/Tian Mech
NH2+NO=N2+H2O                       	 2.8E20      -2.654    1258.00 ! SKR/GLA04 MIL/GLA99/Tian Mech
NH2+NO=NNH+OH                       	 2.3E10       0.425    -814.00 ! SKR/GLA04 MIL/GLA99/Tian Mech
NH2+NO2=N2O+H2O                     	 1.6E16      -1.440     268.00 ! SKR/GLA04 PAR/LIN97/Tian Mech
NNH=N2+H                            	 6.5E07       0.000       0.00 ! SKR/GLA04 MIL/GLA99/Tian Mech
NNH+O=N2O+H                         	 1.0E14       0.000       0.00 ! SKR/GLA04 JAM est/Tian Mech
NNH+O=NH+NO                         	 5.0E13       0.000       0.00 ! SKR/GLA04 MIL/MEL92/Tian Mech
NNH+O2=N2+HO2                       	 2.0E14       0.000       0.00 ! SKR/GLA04 MIL/GLA99/Tian Mech
NNH+O2=N2+H+O2                      	 5.0E13       0.000       0.00 ! SKR/GLA04 MIL/GLA99 /Tian Mech
H+NO+M<=>HNO+M                           4.480E+19   -1.320     740.00 !GRI Mech 3.0
H2/2.00/ H2O/6.00/ CH4/2.00/ CO/1.50/ CO2/2.00/ C2H6/3.00/ AR/ .70/
HNO+H<=>H2+NO                            9.000E+11     .720     660.00 !GRI Mech 3.0
HNO+OH<=>NO+H2O                          1.300E+07    1.900    -950.00 !GRI Mech 3.0
HNO+O2<=>HO2+NO                          1.000E+13     .000   13000.00 !GRI Mech 3.0
NH3+H<=>NH2+H2                           5.400E+05    2.400    9915.00 !GRI Mech 3.0
NH3+M=NH2+H+M                        	 6.6E17        .000   97300.00 !Cardelino et al.   
NH3+OH=NH2+H2O                           2.0E06       2.040     566.00 !GRI Mech 3.0
NH3+O<=>NH2+OH                           9.400E+06    1.940    6460.00 !GRI Mech 3.0
NH+CO2<=>HNO+CO                          1.000E+13     .000   14350.00 !GRI Mech 3.0
N2H3+M=N2H2+H+M                          2.000E+16      0.0   37000.00 !Nakamura
N2H3+H=N2H2+H2                      	 2.4E08       1.500     -10.00 ! SKR/GLA04 DEA/BOZ00/Tian Mech 
N2H3+HO2=N2H2+H2O2                  	 1.4E04       2.690   -1600.00 ! SKR/GLA04 DEA/BOZ00/Tian Mech 
N2H2+H=NNH+H2                       	 8.5E04       2.630     230.00 ! SKR/GLA04 LIN/PAG96/Tian Mech
N2H2+O=NNH+OH                       	 3.3E08       1.500     497.00 ! SKR/GLA04 DEA/BOZ00/Tian Mech 
N2H2+OH=NNH+H2O                     	 5.9E01       3.400    1360.00 ! SKR/GLA04 LIN/PAG96/Tian Mech
HCN+O<=>NH+CO                            5.070E+03    2.640    4980.00 !GRI Mech 3.0
CH+N2<=>HCN+N                            3.120E+09    0.880   20130.00 !GRI Mech 3.0
CH+NO<=>HCN+O                            4.100E+13     .000        .00 !GRI Mech 3.0
CH3+NO<=>HCN+H2O                         9.600E+13     .000   28800.00 !GRI Mech 3.0
END

!References
![1] G.P. Smith, D.M. Golden, M. Frenklach, N.W. Moriarty, B. Eiteneer, M. Goldenberg, et al., 
!    GRI Mech 3.0. Gas Research Institute, available at <http://www.me.berkeley.edu/gri_mech/>.
![2] Z. Tian, Y. Li, L. Zhang, P. Glarborg, F. Qi, An experimental and kinetic modelling study 
!    of premixed NH3/CH4/O2/Ar flames at low pressure, Combust. Flame 156 (2009) 1413?1426.
![3] Z. Hong, D.F. Davidson, E.A. Barbour, R.K. Hanson, A new shock tube study of the 
!    H + O2?= OH + O reaction rate using tunable diode laser absorption of H2O near 2.5? mm 
!    Proc. Combust. Inst. 33 (2011) 309?316.
![4] L. B. Harding, S. J. Klippenstein, Y. Georgievskii, Reactions of oxygen atoms with hydrocarbon 
!     radicals: A priori kinetic predictions for the CH3+O, C2H5+ O, and C2H3+ O reactions, Proc. Combust. Inst. 30 (2005) 985?992.
![5] W.K. Metcalfe, S.M. Burke, S.S. Ahmed, H.J. Curran, A hierarchical and comparative kinetic 
!     modelling study of C1 - C2 hydrocarbon and oxygenated fuels, Int. J. Chem. Kinet. 45 (2013) 638-675. 
![6] K. P. Kim, J. V. Michael, The thermal reactions of CH3, Symp. Combust. 25 (1994) 713?719. 
![7] C.T. Bowman, R.K. Hanson, D.F. Davidson, W.C. Gardiner, Jr., V. Lissianski, G.P. Smith, D.M. Golden, M. 
!     Frenklach and M. Goldenberg, http://www.me.berkeley.edu/gri_mech/
![8] W. Tsang, R.F. Hampson, Chemical kinetic data base for combustion chemistry. Part I. Methane and 
!     related compounds, J. Phys. Chem. Ref. Data, 15 (1986) 1087-1279.
![9] Z. Hong, K. Y. Lam, R. Sur, S. Wang, D. F. Davidson, R. K. Hanson, On the rate constants of OH + HO2and 
!     HO2+HO2: A comprehensive study of H2O2thermal decomposition using multi-species laser absorption, Proc. Combust. Inst. 34 (2013) 565?571.
![10] A. V. Joshi, H. Wang, Master equation modelling of wide range temperature and pressure dependence of CO + OH → products, Int. J. Chem. Kinet. 38 (2006) 57?73. 
![11] B. H. Cardelino, C. E. Moore, C. A. Cardelino, S. D. McCall, D. O. Frazier, K. J. Bachmann, Semiclassical calculation of reaction rate constants 
!       for homolytical dissociation reactions of interest in organometallic vapor-phase epitaxy (OMVPE), J. Phys. Chem. A 107 (2003) 3708?3718.
![12] S. J. Klippenstein, L. B. Harding, P. Glarborg, J. A. Miller, The role of NNH in NO formation and control, Combust. Flame 158 (2011) 774?789
