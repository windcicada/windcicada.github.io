!Combustion chemistry of ammonia/hydrogen mixtures: Jet-stirred reactor measurements and comprehensive kinetic modeling
!Xiaoyuan Zhang, Shamjad P. Moosakutty, Rajitha P. Rajan, Mourad Younes, S. Mani Sarathy
!Contanct: xiaoyuan.zhang@kaust.edu.sa

ELEMENTS
O H N C AR HE
END

SPECIES

AR      N2      H       H2      HE      AR
O       OH      H2O     HO2     H2O2    O2    OH*                                
CO      CO2     CH4     C2H6
END


REACTIONS


!************************ H2/CO mechanism**************************************

!======================                                                                                                                                                      
!H2-O2 Chain Reactions                                                                                                                                                       
!======================                                                                                                                                                      
                                                                                                                                                                             
! Hong et al., Proc. Comb. Inst. 33:309-316 (2011)                                                                                                                           
H+O2=O+OH                            1.0E14   0.000   15286                                                                                                    
                                                                                                                                                                             
! Baulch et al., J. Phys. Chem. Ref. Data, 21:411 (1992)                                                                                                                     
O+H2=OH+H                            3.8E12   0.000    7948
 DUPLICATE                                                  
O+H2=OH+H                            8.8E14   0.000   19175  
 DUPLICATE                                                                                                                                                               
                                                                                                                                                                             
! Michael and Sutherland, J. Phys. Chem. 92:3853 (1988)                                                                                                                      
OH+H2=H+H2O                          2.2E08   1.510    3430                                                                                                                           
                                                                                                                                                                                                                                                                                                                                                         
! M. Sangwan, L. N. Krasnoperov, The Journal of Physical Chemistry A 116 (2012) 11817?1822.                                                                                  
OH+OH=O+H2O                          2.0E07   1.651     631 !   
 DUPLICATE
OH+OH=O+H2O                          2.6E11  -0.057    -827 ! 
 DUPLICATE
! HH: Refitted (400-3000 K) for better stability of the solvers (avoiding negative 'A') 16-04-08                                                                                                                                                               
                                                                                                                                                                             
!============================                                                                                                                                                
!H2-O2 Dissociation Reactions                                                                                                                                                
!============================                                                                                                                                                
                                                                                                                                                                             
! Tsang and Hampson, J. Phys. Chem. Ref. Data, 15:1087 (1986)                                                                                                                
H2+M=H+H+M                           4.6E19  -1.400  104380                                                                                                                          
   H2/2.5/ H2O/12/                                                                                                                                                           
   CO/1.9/ CO2/3.8/                                                                                                                                                          
   AR/0.0/ HE/0.0/                                                                                                                                                           
                                                                                                                                                                             
! Tsang and Hampson, J. Phys. Chem. Ref. Data, 15:1087 (1986)                                                                                                                
H2+AR = H+H+AR                              	5.8E18  -1.100  104380                                                                                                    
H2+HE = H+H+HE                              	5.8E18  -1.100  104380                                                                                                    
                                                                                                                                                                             
! Tsang and Hampson, J. Phys. Chem. Ref. Data, 15:1087 (1986)                                                                                                                
!O+O+M = O2+M                                	6.165E+15 -0.50  0.000E+00 
O+O+M=O2+M                           1.9E13   0.000   -1788                                                                                                    
   H2/2.5/ H2O/12/                                                                                                                                                           
   AR/0.0/ HE/0.0/                                                                                                                                                           
   CO/1.9/ CO2/3.8/                                                                                                                                                          
                                                                                                                                                                             
! Tsang and Hampson, J. Phys. Chem. Ref. Data, 15:1087 (1986)                                                                                                                
O+O+AR = O2+AR                              	1.886E+13  0.00 -1.788E+03                                                                                                     
O+O+HE = O2+HE                              	1.886E+13  0.00 -1.788E+03                                                                                                     
                                                                                                                                                                             
! Tsang and Hampson, J. Phys. Chem. Ref. Data, 15:1087 (1986)                                                                                                                
H+O+M=OH+M                           4.7E18  -1.000       0                                                                                                     
   H2/2.5/  H2O/12/                                                                                                                                                          
   AR/0.75/ HE/0.75/                                                                                                                                                         
   CO/1.9/  CO2/3.8/                                                                                                                                                         
                                                                                                                                                                           
! Srinivasan and Michael, Int. J. Chem. Kinetic. 38 (2006)                                                                                                                   
! Rate constant is for Ar with efficiencies from Michael et al., J. Phys. Chem. A, 106 (2002)                                                                                
H2O+M = H+OH+M                       6.1E27  -3.322  120790                                                                                                    
   H2/3.0/  H2O/0.0/                                                                                                                                                         
   HE/1.10/ N2/2.00/                                                                                                                                                         
   O2/1.5/                                                                                                                                                                   
! Efficiencies for CO and CO2 taken from Li et al., Int. J. Chem. Kinet. 36:566-575 (2004)                                                                                   
   CO/1.9/ CO2/3.8/                                                                                                                                                          
                                                                                                                                                                             
! Srinivasan and Michael, Int. J. Chem. Kinetic. 38 (2006)                                                                                                                   
H2O+H2O = H+OH+H2O                   1.0E26  -2.440  120180                                                                                                    
                                                                                                                                                                             
!=================================                                                                                                                                           
! Formation and consumption of HO2                                                                                                                                           
!=================================                                                                                                                                           
                                                                                                                                                                             
! High-pressure limit from Troe, Proc. Comb. Inst. 28:1463-1469 (2000)                                                                                                       
! Low-pressure  limit from Michael et al., J. Phys. Chem. A 106:5297-5313                                                                                                    
! Centering factors from Fernandes et al., Phys. Chem. Chem. Phys. 10:4313-4321 (2008)                                                                                       
!=================================================================================                                                                                           
! MAIN BATH GAS IS N2 (comment this reaction otherwise)                                                                                                                      
                                                                                                                                                                            
H+O2(+M)=HO2(+M)                     4.7E12   0.440       0 !
 LOW/6.366E20 -1.72  5.248E02/
 TROE/0.5  1E-30  1E30/                                                                                                                                                 
   H2/2.0/ H2O/14/ O2/0.78/ CO/1.9/ CO2/3.8/ AR/0.67/ HE/0.8/              

!=================================================================================
! MAIN BATH GAS IS AR OR HE (comment this reaction otherwise)
!H+O2(+M)=HO2(+M)                     4.7E12   0.440       0 !
! LOW/9.042E19 -1.50  4.922E02/
! TROE/0.5 1E-30  1E30/
!   H2/3.0/ H2O/21/ O2/1.1/ CO/2.7/ CO2/5.4/ HE/1.2/ N2/1.5/ 

!=================================================================================                                                                                           
                                                                                                                                                                             
! Michael et al., Proc. Comb. Inst. 28:1471 (2000)                                                                                                                           
!HO2+H = H2+O2                                 	3.659E+06  2.09 -1.451E+03                                                                                                   
!Scaled by 0.75                                                                                                  
HO2+H=H2+O2                          2.8E06   2.090   -1451                                                                                                                                                                             
! Mueller et al., Int. J. Chem. Kinetic. 31:113 (1999)                                                                                                                       
HO2+H=OH+OH                          7.1E13   0.000     295
HO2+H=H2O+O                          1.4E12   0.000       0 ! 
! Baulch DL Bowman CT Cobos CJ Cox RA Just Th Kerr JA Pilling MJ Stocker D Troe J Tsang W Walker RW Warnatz J JPCRD 34:757-1397 2005                                                                                                                                                                             

! Fernandez-Ramos and Varandas, J. Phys. Chem. A 106:4077-4083 (2002)                                                                                                        
!HO2+O = O2+OH                               	4.750E+10  1.00 -7.2393E+02                                                                                                    
!Scaled by 0.60                                                                                                                                                              
HO2+O=O2+OH                          2.9E10   1.000    -724                                                                                                    
                                                                                                                                                                             
! M. P. Burke, S. J. Klippenstein, L. B. Harding, Proceedings of the Combustion Institute 34 (2013) 547?55.                                                                  
HO2+OH = H2O+O2 				                1.9E20  -2.490     584                                                                                                                           
    DUPLICATE                                                                                                                                                                
HO2+OH = H2O+O2 			                    1.2E09   1.240   -1310                                                                                                                     
    DUPLICATE                                                                                                                                                                
               
!M. Burke, S. Klippenstein, Nature Chemistry, 9, 1078 C1082 (2017)
H+O2+H = OH+OH                                  4.00E+22   -1.835  800
H+O2+O = OH+O2                                  7.35E+22   -1.835  800
H+O2+OH = H2O+O2                                2.56E+22   -1.835  800  
HO2+HO2 = H2O2+O2                           	1.2E09   0.7712  -1825                                                                                                       
   DUPLICATE                                                                                                                                                                 
HO2+HO2 = H2O2+O2        			1.3E12   0.295    7397                   	                                                                                                   
   DUPLICATE                                                                                                                                                                 
                                                                                                                                                                             
! Troe, Combust. Flame,  158:594-601 (2011)                                                                                                                                  
! Rate constant is for Ar                                                                                                                                                    
H2O2(+M) = OH+OH(+M)            			2.0E12   0.900   48749                                                                                                            
   LOW/2.5E24  -2.300   48749/                                                                                                                                            
   TROE/0.43 1E-30 1E30/                                                                                                                                                    
   H2O/7.5/ CO2/1.6/                                                                                                                                                         
   N2/1.5/  O2/1.2/                                                                                                                                                          
   HE/0.65/ H2O2/7.7/                                                                                                                                                        
! Efficiencies for H2 and CO taken from Li et al., Int. J. Chem. Kinet. 36:566-575 (2004)                                                                                    
   H2/3.7/ CO/2.8/                                                                                                                                                           
                                                                                                                                                                             
! Tsang and Hampson, J. Phys. Chem. Ref. Data, 15:1087 (1986)                                                                                                                
H2O2+H = H2O+OH                             	2.4E13   0.000    3970                                                                                                     
H2O2+H = HO2+H2                             	4.8E13   0.000    7950                                                                                                     
H2O2+O = OH+HO2                             	9.6E06   2.000    3970                                                                                                     
                                                                                                                                                                             
! Hong et al., J. Phys. Chem. A  114 (2010) 5718?727                                                                                                                         
H2O2+OH = HO2+H2O                           	1.7E12   0.000     318                                                                                                     
   DUPLICATE                                                                                                                                                                 
H2O2+OH = HO2+H2O                           	7.6E13   0.000    7270                                                                                                     
   DUPLICATE                                                                                                                                                                 



END




