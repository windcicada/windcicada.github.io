
!****************************************************************************
! 
!  A chemkin compatible reduced mechanism for methanol, which is consistent 
!  with the reduced mechanism reported by R.P. Lindstedt and M.P. Meyer.
!  http://www.sandia.gov/TNF/chemistry.html 
!
!****************************************************************************
 
methanol
ELEMENTS
 C   H   O   N  
END
SPECIES
H           O           OH          O2          H2          H2O         HO2         
CO          CO2         CH2O        CH4         CH3         C2H2        C2H4        
C2H6        CH3OH       H2O2        N2                                                      
END
REACTIONS
END

