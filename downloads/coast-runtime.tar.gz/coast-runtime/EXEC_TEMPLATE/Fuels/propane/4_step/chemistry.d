

propane
ELEMENTS
 O   H   C   N  
END
SPECIES
H2          H2O         CO          CO2         O2          N2          C3H8                                                                   
END
REACTIONS
END
