He-Air
ELEMENTS
c h n o he
END

SPECIES
O2          N2          He
END
REACTIONS
END
