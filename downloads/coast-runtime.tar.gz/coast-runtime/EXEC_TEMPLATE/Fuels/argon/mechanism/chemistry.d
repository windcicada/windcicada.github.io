Ar-Air
ELEMENTS
c h n o
END

SPECIES
O2          N2          AR
END
REACTIONS
END
