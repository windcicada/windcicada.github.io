!***********************************************************************
!                                                                      
!  A 22-Species Reduced Mechanism for C2H4-air
!
!  Z. Luo, C.S. Yoo, E.S. Richardson, J.H. Chen, C.K. Law, and T.F. Lu, 
!  "Chemical explosive mode analysis for a turbulent lifted ethylene jet 
!  flame in highly-heated coflow," 
!  Combustion and Flame, 
!  doi:10.1016/j.combustflame.2011.05.023, 2011.
!                                                                      
!***********************************************************************
ethylene
ELEMENTS
O	H	C	N
AR	
END

SPECIES
H2	    H	        O	    O2
OH	    H2O	        HO2	    H2O2
CH3	    CH4	        CO	    CO2
CH2O	    C2H2	C2H4	    C2H6
HCCO	    CH2CO	CH3CHO	    aC3H5
C3H6	N2              
    	
END

REACTIONS
END

END         			
REACTIONS
END
