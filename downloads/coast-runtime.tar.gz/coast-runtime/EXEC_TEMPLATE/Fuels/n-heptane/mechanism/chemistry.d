n-heptane
ELEMENTS
 O   H   C   N  
END
SPECIES
N2          O2          H           OH          H2          H2O         HO2         
H2O2        CO          CO2         C2H2        CH3         C2H4        CH2O    
CH4         C3H4        C3H6        C4H8        C6H12       C7H16       C7H15O2     
OC7H13              
END
REACTIONS
END
