# COAST 边界条件设置文件。
# 常用设置请优先看这里；单位采用 SI：速度 m/s、温度 K、压力 Pa、质量流量 kg/s。
#
# 【进口】
# - main_air / main_air_outer：空气进口，常调 U fixedValue 的 y 分量。
# - methane_ring：甲烷环形进口，常调 massFlowRate；本轮点火调试总燃料流量为 1.1e-3 kg/s = 1.10 g/s。
# - 进口 targetMarker 保持 -1，走当前稳定的固定进口路径。
#
# 【出口】
# - outlet：燃烧室高 y 出口；当前 targetMarker 保持 -2。
# - 之前测试中 -60 特征出口在该算例上不如 -2 稳定，除非专门验证，不建议改回 -60。
#
# 【壁面】
# - external_adiabatic_walls：外部绝热壁。
# - external_isothermal_walls：可选等温壁，当前允许为空。
# - ibm_wall_function：IBM 几何壁面函数和阻尼设置。
version 1;

patch main_air
{
  # Main air inlet on the low-y external STL inlet face.
  # This is legacy-GTMC equivalent to inprofile.F90:
  # - bind the inlet by side, axial coordinate, and radius
  # - keep targetMarker -1 so boundary3 uses the fixed-inflow path
  # - set the inner-air velocity, then let main_air_outer override r > 0.03

  # kind selects the boundary patch class: inlet, outlet, or wall.
  kind inlet;
  # type selects the inlet schema. fixedVelocityInlet imposes U, T, p, and composition.
  type fixedVelocityInlet;
  # enabled keeps this patch active without deleting it from the case file.
  enabled true;
  # The current STL GTMC mesh uses y as the axial flow direction.  The
  # patchGeometry selector binds the inlet to the low-y geometry patch;
  # side west selects the generated low-y grid face.
  allowEmpty false;
  # priority controls overlap order. Methane ring priority 20 overrides this broad air patch.
  priority 10;

  # selector identifies the legacy faces that receive this patch.
  selector
  {
    # source externalBoundary means a physical outside boundary.
    source externalBoundary;
    # patchGeometry gives the geometry-owned inlet patch.  It is used only
    # for boundary labeling; the full STL remains the fluid-domain geometry.
    patchGeometry 'Geometry/patches/air_inlet_ymin.stl';
    # side west is the generated low-y external boundary.
    side west;
    # marker any is allowed here because source externalBoundary rejects
    # internal block interfaces marked -100.
    marker any;
    # The main-air core applies for r <= 0.03 on the selected STL inlet face.
    region cylinderRing;
    axis y;
    center (0 0);
    radiusRange (0.0 0.03);
    axialCoordinate y;
    # Keep the axial range unbounded for externalBoundary/side selectors.
    # The side west selector already binds the generated low-y inlet face;
    # hard-coding an old z range can make the patch empty after an STL swap.
    axialRange (-1.0e30 1.0e30);
  }

  # targetMarker is written to selected faces after the patch is applied.
  # Use -1 for the fixed-inflow legacy path. Do not use -10 here unless
  # intentionally switching this case to the characteristic/NSCBC inlet path.
  targetMarker -1;
  # U is the imposed inlet velocity vector for r <= 0.03.  The STL model
  # uses +y as the axial inflow direction.  This value targets an inner-air
  # flow of about 7.30 g/s after patch/IBM face selection.
  U fixedValue (0 7.5743 0);
  # T is the imposed inlet temperature.
  T fixedValue 295;
  # p is the inlet static/reference pressure.
  p fixedValue 100000;

  # composition uses species names from EXEC/species_manifest.d.
  composition volumeFraction
  {
    # Dry air oxidizer by volume fraction.
    O2 0.21;
    N2 0.79;
    # normalize true permits exact normalization before conversion to mass fractions.
    normalize true;
  }
}

patch main_air_outer
{
  # Higher-priority outer air annulus matching the legacy
  # merge(v_air_outer,v_air_inner,radius > 0.03) branch.

  kind inlet;
  type fixedVelocityInlet;
  enabled true;
  # Outer-annulus branch on the external low-y STL inlet boundary.
  allowEmpty false;
  priority 11;

  selector
  {
    source externalBoundary;
    # Bind the same geometry inlet patch as main_air, then split the
    # annulus by radiusRange below.
    patchGeometry 'Geometry/patches/air_inlet_ymin.stl';
    # side west is the generated low-y external boundary.
    side west;
    marker any;
    region cylinderRing;
    axis y;
    center (0 0);
    # The generated low-z external side includes additional fluid-domain
    # cross-section from the full gtmc13.STL bounds.  Keep the air inlet on the
    # physical annulus only; widening this upper radius directly increases
    # floin.  R=0.035 m gives the current clean-start air flow near 20 g/s.
    radiusRange (0.0300001 0.0350);
    axialCoordinate y;
    # Same generated external low-y inlet selector plane as main_air.
    # Keep this unbounded so the side selector, not an old coordinate range,
    # controls the inlet plane after STL geometry changes.
    axialRange (-1.0e30 1.0e30);
  }

  # Keep -1 for the fixed-inflow legacy path.
  targetMarker -1;
  # U is the imposed inlet velocity vector for r > 0.03.  This value targets
  # an outer-air flow of about 10.95 g/s, giving inner:outer = 1:1.5 and
  # total air flow about 18.25 g/s.
  U fixedValue (0 11.3409 0);
  T fixedValue 295;
  p fixedValue 100000;

  composition volumeFraction
  {
    O2 0.21;
    N2 0.79;
    normalize true;
  }
}

patch methane_ring
{
  # Methane fuel inlet.  In the STL main route the fuel injector is selected
  # from IBM-detected wall-adjacent fluid cells, not from a generated block
  # plane.  The coordinate region below only limits which IBM wall patch is
  # active; the final wall test comes from the IBM fluid/solid marker.

  # kind selects the boundary patch class.
  kind inlet;
  # type imposes the target total methane mass flow, then computes the
  # active-mesh velocity from the selected IBM inlet area and gas density.
  type massFlowInlet;
  # enabled keeps this methane inlet active.
  enabled true;
  # priority 20 applies after main_air priority 10.
  priority 20;

  allowEmpty false;
  selector
  {
    # source ibmSurface means this patch is applied only to fluid cells that
    # are adjacent to IBM solid cells.  It must not be changed to blockPlane
    # for the STL main route, otherwise the injector can drift away from the
    # geometry-defined wall.
    source ibmSurface;
    # IBM surface patches are internal geometry surfaces, so side is ignored
    # by the active application path.  Keep all for clarity.
    side all;
    # marker any lets the coordinate selector work with both direct interface
    # cells and future GUI-selected patch markers.
    marker any;
    # patchGeometry binds this IBM inlet to a geometry-owned methane patch.
    # The velocity model below still rotates the speed onto the local wall
    # normal pointing into the fluid.
    patchGeometry 'Geometry/patches/methane_ring_y.stl';
    # region cylinderRing selects the STL/IBM fuel annulus.  The injector
    # is bound to the annular wall patch at y=-0.008 m with radius
    # 0.0069 < sqrt(x**2+z**2) < 0.0081 m.  The active selector uses
    # cell-center coordinates, so the y range covers the two center layers
    # adjacent to the physical y=-0.008 m patch.
    region cylinderRing;
    axis y;
    center (0 0);
    radiusRange (0.0069 0.0081);
    axialCoordinate y;
    axialRange (-0.00825 -0.00775);
  }

  # targetMarker is written to selected methane inlet faces.
  # Keep -1 for the fixed-inflow legacy path.
  targetMarker -1;
  # massFlowRate is kg/s.  The solver converts 1.1e-3 kg/s to the velocity
  # magnitude required by the currently selected IBM annular inlet cells.
  massFlowRate fixedValue 1.1e-3;
  # U model wallNormalIntoFluid rotates the computed speed onto the IBM wall
  # normal pointing from solid into fluid.  The fixed U below is only a
  # nonzero direction seed for the mass-flow mode.
  U model wallNormalIntoFluid;
  U fixedValue (1 0 0);
  # T is the imposed methane inlet temperature.
  T fixedValue 295;
  # p is the methane inlet static/reference pressure.
  p fixedValue 100000;

  # Pure methane fuel stream.
  composition volumeFraction
  {
    CH4 1.0;
    normalize true;
  }
}

patch outlet
{
  # Robust low-Mach outlet for the current IBM/STL combustor mesh.
  # This outlet uses the legacy mass-closure marker -2 so the pressure
  # equation can balance the total inlet mass flow on the open high-z face.
  # The -60 characteristic pressure outlet is kept in the solver for future
  # cases, but it produced an outlet-plane velocity spike in this mesh.

  # kind selects the boundary patch class.
  kind outlet;
  # relaxedPressureOutlet keeps the OpenFOAM-style user schema.  With
  # targetMarker -2 below, the active numerical path is the robust
  # zero-gradient/mass-closure outlet; p/backflow values document the intended
  # reference state and remain available if the marker is changed to -60.
  type relaxedPressureOutlet;
  # enabled keeps the outlet active.
  enabled true;
  # priority controls application order among outlet patches.
  priority 10;

  # selector identifies the physical high-y STL outlet face.
  selector
  {
    # source externalBoundary limits this patch to real domain-boundary faces.
    source externalBoundary;
    # patchGeometry gives the geometry-owned outlet patch.
    patchGeometry 'Geometry/patches/outlet_ymax.stl';
    # side east is the generated high-y external boundary.
    side east;
    # marker any lets the selector override stale generated wall/outlet markers.
    # Internal block interfaces marked -100 are still rejected by source.
    marker any;
    # region all selects every cell-face on the high-z outlet face.
    region all;
  }

  # targetMarker is written to selected outlet faces.
  # Use -2 for the robust zero-gradient/mass-closure outlet on this
  # low-Mach IBM/STL combustor case.
  targetMarker -2;
  # p is the outlet static pressure.
  p fixedValue 100000;

  # backflow defines the reference state if local flow reverses at the outlet.
  backflow
  {
    # normalFraction is the retained fraction of reverse normal velocity.
    normalFraction 0.1;
    # tangentialDamping damps reverse-flow tangential velocity components.
    tangentialDamping 0.8;
    # scalarBlend blends scalars toward the reference backflow state.
    scalarBlend 0.1;
    # T is the reference backflow temperature.
    T fixedValue 295;

    # Backflow composition uses the default air oxidizer.
    composition volumeFraction
    {
      O2 0.21;
      N2 0.79;
      normalize true;
    }
  }
}

patch external_adiabatic_walls
{
  # External wall faces using zero-gradient thermal/scalar treatment.
  # This maps to the legacy -5/-50 wall path.

  # kind selects the boundary patch class.
  kind wall;
  # noSlipAdiabaticWall imposes zero wall velocity and adiabatic thermal behavior.
  type noSlipAdiabaticWall;
  # enabled keeps this wall patch active.
  enabled true;
  # priority 5 applies before the isothermal wall patch if markers are separated.
  priority 5;

  # selector finds all external boundary faces with legacy adiabatic wall markers.
  selector
  {
    # source externalBoundary limits selection to grid-boundary faces.
    source externalBoundary;
    # side all searches all external sides.
    side all;
    # markers matches legacy adiabatic or zero-gradient wall markers.
    markers (-5 -50);
    # region all selects every matched wall face.
    region all;
  }

  # targetMarker preserves the active adiabatic wall path.
  targetMarker -5;
  # U fixedValue (0 0 0) imposes no-slip stationary wall velocity.
  U fixedValue (0 0 0);
  # thermal adiabatic selects zero wall heat flux / zero-gradient thermal behavior.
  thermal adiabatic;
  # species zeroGradient keeps scalar species on the legacy zero-gradient wall path.
  species zeroGradient;
}

patch external_isothermal_walls
{
  # External fixed-temperature wall faces.
  # This maps to the legacy -4/-40 wall path and keeps wall heat-flux accounting active.

  # kind selects the boundary patch class.
  kind wall;
  # noSlipIsothermalWall imposes zero velocity and fixed wall temperature.
  type noSlipIsothermalWall;
  # enabled keeps this wall patch active.
  enabled true;
  # Current TCR mesh uses adiabatic external wall markers; fixed-temperature
  # markers are optional and can be absent.
  allowEmpty true;
  # priority 6 applies after external_adiabatic_walls.
  priority 6;

  # selector finds all external boundary faces with legacy fixed-temperature wall markers.
  selector
  {
    # source externalBoundary limits selection to grid-boundary faces.
    source externalBoundary;
    # side all searches all external sides.
    side all;
    # markers matches legacy isothermal wall markers.
    markers (-4 -40);
    # region all selects every matched wall face.
    region all;
  }

  # targetMarker preserves the active isothermal wall path.
  targetMarker -4;
  # U fixedValue (0 0 0) imposes no-slip stationary wall velocity.
  U fixedValue (0 0 0);
  # thermal isothermal selects fixed wall-temperature treatment.
  thermal isothermal;
  # T is the fixed wall temperature.
  T fixedValue 295;
  # species zeroGradient keeps scalar species on the legacy zero-gradient wall path.
  species zeroGradient;
}

patch ibm_wall_function
{
  # IBM geometry wall-function behavior.
  # The selector applies to immersed geometry wall faces, not only external grid-boundary faces.

  # kind selects the boundary patch class.
  kind wall;
  # wallFunctionAdiabaticWall selects wall-law momentum behavior with adiabatic thermal treatment.
  type wallFunctionAdiabaticWall;
  # enabled keeps this IBM wall-function patch active.
  enabled true;
  # priority 10 applies after broad external wall patches.
  priority 10;

  # selector targets all IBM surface faces.
  selector
  {
    # source ibmSurface limits selection to immersed-boundary geometry surfaces.
    source ibmSurface;
    # region all selects the full IBM surface.
    region all;
  }

  # targetMarker maps the IBM wall-function faces to the adiabatic wall marker path.
  targetMarker -5;
  # U model wallFunction delegates wall velocity treatment to wall-function logic.
  U model wallFunction;
  # thermal adiabatic selects adiabatic wall-function thermal behavior.
  thermal adiabatic;
  # species zeroGradient keeps scalar species on the legacy zero-gradient wall path.
  species zeroGradient;

  # wallFunction configures the current IBM wall damping behavior.
  wallFunction
  {
    # enabled activates wall-function treatment for this patch.
    enabled true;
    # dampingEnabled activates damping controls for stable IBM wall treatment.
    dampingEnabled true;
    # targetCfl corresponds to the current IBM wall damping target CFL.
    targetCfl 0.01;
    # maxMultiplier limits the wall damping multiplier.
    maxMultiplier 20;
  }
}
